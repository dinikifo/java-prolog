# Toulmin Argumentation Expert System

A Java-based Prolog interpreter with Toulmin argumentation support, featuring forward and backward reasoning capabilities, an embedded column-based database, and an HTN action planner—all wrapped in a modern Swing UI.

## Features

### Core Prolog Engine
- Variable standardization-apart
- Trail-based undo + choice points
- Occurs-check in unification
- First-argument indexing for efficient clause selection
- JSON ⇄ Term and JSON ⇄ Java POJO mapping

### Toulmin Argumentation Model
Implements the six components of Toulmin's argument model:
- **Claim (C)**: The conclusion being argued for
- **Data/Grounds (D)**: The evidence supporting the claim
- **Warrant (W)**: The logical connection between data and claim
- **Backing (B)**: Support for the warrant itself
- **Qualifier (Q)**: Degree of certainty (certainly, probably, possibly, etc.)
- **Rebuttal (R)**: Exceptions or conditions that defeat the claim

### Reasoning Capabilities
- **Forward Reasoning**: Given facts, derive what claims can be made
- **Backward Reasoning**: Given a claim, find what facts are needed to prove it
- **Proof Checking**: Verify if a claim can be proven with current knowledge
- **Conflict Detection**: Identify contradictions between arguments
- **Conflict Resolution**: Resolve conflicts based on argument strength

### Additional Components
- **Column-Based Database**: Embedded DB with hash indexes for efficient queries
- **HTN Planner**: Hierarchical Task Network planning with multiple strategies
- **OO Substrate**: JavaScript-like prototype object system in Prolog

## Quick Start

### Build
```bash
./build_ui.sh
```

### Run the Swing UI
```bash
java -cp out com.mycompany.prolog.ToulminExpertSystemUI
```

### Run Self-Tests
```bash
java -ea -cp out com.mycompany.prolog.MiniPrologProto --selftest
```

## UI Overview

The Swing-based UI provides seven main tabs:

1. **Knowledge Base**: Add facts and rules (inference patterns)
2. **Argument Builder**: Create Toulmin arguments with all six components
3. **Forward Reasoning**: Derive claims from existing facts
4. **Backward Reasoning**: Find required facts for a claim
5. **Conflict Analysis**: Detect and resolve argument conflicts
6. **HTN Planner**: Generate hierarchical task plans
7. **Prolog Console**: Execute direct Prolog queries

## Architecture

```
MiniPrologProto.java    - Core Prolog engine with unification, backtracking, builtins
OopPrologLib.java       - Prototype-based OO system
ColumnDbLib.java        - Column-oriented database with indexes
PlannerStrategiesLib.java - HTN planner with DFS and bounded DFS
HtnDemoLib.java         - Demo domain for planning
ToulminArgumentLib.java - Toulmin argumentation predicates
ToulminExpertSystemUI.java - Swing-based user interface
```

## Example Usage

### Adding Facts
```prolog
bird(tweety).
penguin(pingu).
healthy(tweety).
```

### Adding Rules (Warrants)
```prolog
can_fly(X) :- bird(X), healthy(X).  % certainty: 0.9
cannot_fly(X) :- penguin(X).         % certainty: 1.0
```

### Creating an Argument
- **Claim**: `can_fly(tweety)`
- **Data**: `bird(tweety)`, `healthy(tweety)`
- **Warrant**: `rule(5)` (reference to the can_fly rule)
- **Backing**: `facts([...])` (the supporting facts)
- **Qualifier**: `probably`
- **Rebuttal**: `none`

### Forward Reasoning
Given facts `[bird(tweety), healthy(tweety)]`, the system derives:
- `claim(can_fly(tweety), rule_id, 90)`
- `claim(animal(tweety), rule_id, 100)`

### Backward Reasoning
Given goal `can_fly(X)`, the system identifies required facts:
- `need(bird(X))`
- `need(healthy(X))`

## Toulmin Predicates

```prolog
% Initialize the system
toulmin_init.

% Add facts and rules
assert_fact(Id, Content).
assert_rule(Id, Head, Body, Certainty).

% Create and retrieve arguments
create_argument(Id, Claim, Data, Warrant, Backing, Qualifier, Rebuttal).
get_argument(Id, Claim, Data, Warrant, Backing, Qualifier, Rebuttal).
list_arguments(Ids).

% Forward reasoning
forward_derive(Facts, Claims).
forward_build_argument(Claim, Facts, ArgId).

% Backward reasoning
backward_derive(Claim, RequiredFacts).
can_prove(Claim, Proof).
missing_facts(Claim, Missing).

% Argument analysis
argument_strength(ArgId, Strength).
validate_argument(ArgId, Status).

% Conflict resolution
detect_conflict(ArgId1, ArgId2, Type).
resolve_conflict(ArgId1, ArgId2, Winner).
```

## HTN Planning

The system includes a parametric HTN planner with:
- **DFS Search**: Depth-first search for plan generation
- **Bounded DFS**: DFS with step limits
- **Query Caching**: Cache query results for efficiency
- **Auto-Indexing**: Automatic hash index creation

Example planning goal:
```prolog
demo_plan(cached, Plan).
```

## License

This project is provided as-is for educational and research purposes.
