#!/bin/bash

# Build script for Toulmin Expert System UI

echo "=== Building Toulmin Expert System ==="

# Clean output directory
rm -rf out
mkdir -p out

# Find all Java source files
SOURCES=$(find src -name "*.java")

echo "Compiling sources..."
javac -d out $SOURCES

if [ $? -eq 0 ]; then
    echo "Build successful!"
    echo ""
    echo "To run the application:"
    echo "  java -cp out com.mycompany.prolog.ToulminExpertSystemUI"
    echo ""
    echo "To run the Prolog self-tests:"
    echo "  java -ea -cp out com.mycompany.prolog.MiniPrologProto --selftest"
else
    echo "Build failed!"
    exit 1
fi
