package com.mycompany.prolog;

import java.util.*;
import java.util.function.*;

/**
 * MiniPrologProto — a tiny, prototype-flavored Prolog core in one file
 * with JSON <-> Term and JSON <-> Java POJO mapping built-ins.
 *
 * Usage (quick):
 *   javac -d out $(find src -name "*.java")
 *   java -cp out com.mycompany.prolog.MiniPrologProto
 *
 * Self-tests:
 *   java -ea -cp out com.mycompany.prolog.MiniPrologProto --selftest
 */
public class MiniPrologProto {

  /* =========================
   * Minimal prototype layer
   * ========================= */
  static final class Key<T> {
    final String name;
    Key(String n){ this.name=n; }
    public String toString(){ return name; }
  }
  static final class MKey<F> {
    final String name;
    MKey(String n){ this.name=n; }
    public String toString(){ return name; }
  }

  static class Obj {
    Obj proto;
    final Map<Key<?>, Object> slots = new HashMap<>();
    final Map<MKey<?>, Object> methods = new HashMap<>();

    Obj(){ this(null); }
    Obj(Obj proto){ this.proto = proto; }

    @SuppressWarnings("unchecked")
    <T> T get(Key<T> k){
      for(Obj o=this; o!=null; o=o.proto){
        if(o.slots.containsKey(k)) return (T)o.slots.get(k);
      }
      return null;
    }
    <T> void set(Key<T> k, T v){ slots.put(k, v); }

    @SuppressWarnings("unchecked")
    <F> F method(MKey<F> k){
      for(Obj o=this; o!=null; o=o.proto){
        if(o.methods.containsKey(k)) return (F)o.methods.get(k);
      }
      return null;
    }
    <F> void define(MKey<F> k, F fn){ methods.put(k, fn); }
  }

  /* =========================
   * Terms & core structures
   * ========================= */
  enum Tag { VAR, ATOM, NUM, COMP }

  // Keys for Terms
  static final Key<Tag>     K_TAG     = new Key<>("tag");
  static final Key<String>  K_NAME    = new Key<>("name");   // Atom or functor name
  static final Key<Integer> K_ARITY   = new Key<>("arity");
  static final Key<List<Obj>> K_ARGS  = new Key<>("args");

  // Var-specific keys
  static final Key<Integer> K_VID   = new Key<>("varId");
  static final Key<Obj>     K_BIND  = new Key<>("binding"); // deref target (null if unbound)

  // Clause, Predicate, Engine keys
  static final Key<Obj>       K_HEAD     = new Key<>("head");
  static final Key<List<Obj>> K_BODY     = new Key<>("body");
  static final Key<List<Obj>> K_CLAUSES  = new Key<>("clauses");

  // Engine keys
  static final Key<Deque<Obj>>         K_GOALS      = new Key<>("goals");
  static final Key<Deque<ChoicePoint>> K_CHOICES    = new Key<>("choices");
  static final Key<Trail>             K_TRAIL      = new Key<>("trail");
  static final Key<Map<String,Obj>>   K_PREDICATES  = new Key<>("predicates");

  static final Key<ArrayDeque<Integer>> K_CUT_STACK   = new Key<>("cutStack");

  // Predicate indexing (first-argument)
  static final Key<FirstArgIndex>      K_INDEX       = new Key<>("firstArgIndex");

  // Function types
  @FunctionalInterface interface TriFunction<A,B,C,R> { R apply(A a,B b,C c); }

  /* =========================
   * Trail & choice points
   * ========================= */
  static final class Trail {
    static final class Entry {
      final Obj var;
      final Obj old;
      Entry(Obj v, Obj o){ var=v; old=o; }
    }
    final ArrayDeque<Entry> stk = new ArrayDeque<>();
    int mark(){ return stk.size(); }
    void bind(Obj var, Obj to){
      stk.push(new Entry(var, var.get(K_BIND)));
      var.set(K_BIND, to);
    }
    void unwindTo(int sz){
      while(stk.size()>sz){
        Entry e=stk.pop();
        e.var.set(K_BIND, e.old);
      }
    }
  }

  static enum CpKind { CLAUSE, GOAL, BUILTIN }

  @FunctionalInterface
  interface BuiltinExec {
    // Produce the next solution for a nondet builtin; return false if no more.
    boolean next(Trail tr);
  }

  static final class ChoicePoint {
    final CpKind kind;
    final ArrayDeque<Obj> goals; // snapshot of pending goals to restore
    final int trailMark;         // trail size to rewind to
    final int cutStackSize;      // cut stack size to restore

    // For CLAUSE retry
    final List<Obj> candidates;  // candidate clause objects (original, not renamed)
    final int nextPos;           // next candidate position to try
    final int choiceBarrier;     // choice-stack depth at predicate entry (cut barrier)

    // For BUILTIN retry
    final BuiltinExec builtinExec;

    ChoicePoint(CpKind kind, ArrayDeque<Obj> goals, int trailMark, int cutStackSize,
                List<Obj> candidates, int nextPos, int choiceBarrier, BuiltinExec builtinExec){
      this.kind = kind;
      this.goals = goals;
      this.trailMark = trailMark;
      this.cutStackSize = cutStackSize;
      this.candidates = candidates;
      this.nextPos = nextPos;
      this.choiceBarrier = choiceBarrier;
      this.builtinExec = builtinExec;
    }

    static ChoicePoint clause(ArrayDeque<Obj> goals, int trailMark, int cutStackSize,
                              List<Obj> candidates, int nextPos, int choiceBarrier){
      return new ChoicePoint(CpKind.CLAUSE, goals, trailMark, cutStackSize, candidates, nextPos, choiceBarrier, null);
    }

    static ChoicePoint goal(ArrayDeque<Obj> goals, int trailMark, int cutStackSize){
      return new ChoicePoint(CpKind.GOAL, goals, trailMark, cutStackSize, null, 0, 0, null);
    }

    static ChoicePoint builtin(ArrayDeque<Obj> goals, int trailMark, int cutStackSize, BuiltinExec exec){
      return new ChoicePoint(CpKind.BUILTIN, goals, trailMark, cutStackSize, null, 0, 0, exec);
    }
  }


  /* =========================
   * Term factories
   * ========================= */
  static final Obj TERM_PROTO = new Obj();
  static final Obj VAR_PROTO  = new Obj(TERM_PROTO);
  static final Obj ATOM_PROTO = new Obj(TERM_PROTO);
  static final Obj NUM_PROTO  = new Obj(TERM_PROTO);
  static final Obj COMP_PROTO = new Obj(TERM_PROTO);

  static int VAR_COUNTER = 0;

  static Obj Var(){
    Obj o=new Obj(VAR_PROTO);
    o.set(K_TAG, Tag.VAR);
    o.set(K_VID, VAR_COUNTER++);
    o.set(K_BIND, null);
    return o;
  }
  static Obj Atom(String name){
    Obj o=new Obj(ATOM_PROTO);
    o.set(K_TAG, Tag.ATOM);
    o.set(K_NAME, name);
    return o;
  }
  static Obj Num(long n){
    Obj o=new Obj(NUM_PROTO);
    o.set(K_TAG, Tag.NUM);
    o.set(K_NAME, Long.toString(n));
    return o;
  }
  static Obj Comp(String name, Obj...args){
    Obj o=new Obj(COMP_PROTO);
    o.set(K_TAG, Tag.COMP);
    o.set(K_NAME, name);
    o.set(K_ARITY, args.length);
    o.set(K_ARGS, Arrays.asList(args));
    return o;
  }

  static String pi(String name, int arity){ return name+"/"+arity; }
  static String pi(Obj t){ return t.get(K_NAME)+"/"+t.get(K_ARITY); }

  /* =========================
   * Deref, Unify
   * ========================= */
  static Obj deref(Obj t, Trail tr){
    while(t.get(K_TAG)==Tag.VAR){
      Obj b=t.get(K_BIND);
      if(b==null) return t;
      t=b;
    }
    return t;
  }

  static boolean unify(Obj a, Obj b, Trail tr){
    a = deref(a,tr); b = deref(b,tr);
    if(a==b) return true;
    Tag ta=a.get(K_TAG), tb=b.get(K_TAG);
    if(ta==Tag.VAR){
      if(occursCheck(a, b, tr)) return false;
      tr.bind(a,b);
      return true;
    }
    if(tb==Tag.VAR){
      if(occursCheck(b, a, tr)) return false;
      tr.bind(b,a);
      return true;
    }
    if(ta!=tb) return false;
    if(ta==Tag.ATOM || ta==Tag.NUM){
      return Objects.equals(a.get(K_NAME), b.get(K_NAME));
    }
    if(ta==Tag.COMP){
      if(!Objects.equals(a.get(K_NAME), b.get(K_NAME))) return false;
      if(!Objects.equals(a.get(K_ARITY), b.get(K_ARITY))) return false;
      List<Obj> as=a.get(K_ARGS), bs=b.get(K_ARGS);
      for(int i=0;i<as.size();i++){
        if(!unify(as.get(i), bs.get(i), tr)) return false;
      }
      return true;
    }
    return false;
  }

  static boolean occursCheck(Obj var, Obj term, Trail tr){
    Set<Obj> seen = Collections.newSetFromMap(new IdentityHashMap<>());
    return occursCheck0(var, term, tr, seen);
  }
  static boolean occursCheck0(Obj var, Obj term, Trail tr, Set<Obj> seen){
    term = deref(term, tr);
    if(term == var) return true;
    if(!seen.add(term)) return false;
    Tag tt = term.get(K_TAG);
    if(tt == Tag.COMP){
      for(Obj a : term.get(K_ARGS)){
        if(occursCheck0(var, a, tr, seen)) return true;
      }
    }
    return false;
  }

  /* =========================
   * Pretty printer (Stage 1)
   * ========================= */
  static String pp(Obj t){
    IdentityHashMap<Obj,Boolean> seen = new IdentityHashMap<>();
    return pp0(deref(t, new Trail()), seen);
  }

  static String pp0(Obj t, IdentityHashMap<Obj,Boolean> seen){
    t = deref(t, new Trail());
    if(seen.put(t, Boolean.TRUE)!=null) return "<cycle>";
    Tag tag = t.get(K_TAG);
    if(tag==Tag.VAR) return "_"+t.get(K_VID);
    if(tag==Tag.ATOM || tag==Tag.NUM) return t.get(K_NAME);
    if(tag==Tag.COMP){
      String f=t.get(K_NAME);
      int ar=t.get(K_ARITY);

      // JSON string term: str(Atom("...")) -> "..."
      if("str".equals(f) && ar==1){
        String s = termToJavaString(t, new Trail());
        return "\""+Json.escape(s)+"\"";
      }

      // list sugar: "."/2 + [] -> [a,b] or [H|T]
      if(isListLike(t)) return ppList(t, seen);

      StringBuilder sb=new StringBuilder();
      sb.append(f).append('(');
      List<Obj> as=t.get(K_ARGS);
      for(int i=0;i<as.size();i++){
        if(i>0) sb.append(',');
        sb.append(pp0(as.get(i), seen));
      }
      sb.append(')');
      return sb.toString();
    }
    return "?";
  }

  static boolean isNil(Obj t){
    t = deref(t, new Trail());
    return t.get(K_TAG)==Tag.ATOM && "[]".equals(t.get(K_NAME));
  }

  static boolean isCons(Obj t){
    t = deref(t, new Trail());
    return t.get(K_TAG)==Tag.COMP && ".".equals(t.get(K_NAME)) && t.get(K_ARITY)==2;
  }

  static boolean isListLike(Obj t){
    return isNil(t) || isCons(t);
  }

  static String ppList(Obj t, IdentityHashMap<Obj,Boolean> seen){
    StringBuilder sb=new StringBuilder();
    sb.append('[');
    Obj cur = t;
    boolean first=true;
    while(true){
      cur = deref(cur, new Trail());
      if(isNil(cur)){
        sb.append(']');
        return sb.toString();
      }
      if(!isCons(cur)){
        if(!first) sb.append('|');
        sb.append(pp0(cur, seen)).append(']');
        return sb.toString();
      }
      Obj h = cur.get(K_ARGS).get(0);
      Obj tail = cur.get(K_ARGS).get(1);
      if(!first) sb.append(',');
      sb.append(pp0(h, seen));
      first=false;
      cur = tail;
    }
  }

  /* =========================
   * Clauses, Predicates, Program
   * ========================= */
  static Obj Clause(Obj head, Obj... body){
    Obj c=new Obj();
    c.set(K_HEAD, head);
    c.set(K_BODY, Arrays.asList(body));
    return c;
  }

  static Obj Predicate(Obj...clauses){
    Obj p=new Obj();
    p.set(K_CLAUSES, new ArrayList<>(Arrays.asList(clauses)));
    return p;
  }


  /* =========================
   * First-argument indexing
   * ========================= */
  static final class FirstArgIndex {
    final Map<String, List<Integer>> buckets = new HashMap<>();
    final List<Integer> varBucket = new ArrayList<>();
  }

  static String idxKey(Obj t){
    t = deref(t, new Trail());
    Tag tag = t.get(K_TAG);
    if(tag==Tag.VAR) return "*";
    if(tag==Tag.ATOM) return "A:"+t.get(K_NAME);
    if(tag==Tag.NUM) return "N:"+t.get(K_NAME);
    if(tag==Tag.COMP) return "C:"+t.get(K_NAME)+"/"+t.get(K_ARITY);
    return "*";
  }

  static void rebuildIndex(Obj pred){
    FirstArgIndex idx = pred.get(K_INDEX);
    if(idx==null){
      idx = new FirstArgIndex();
      pred.set(K_INDEX, idx);
    }
    idx.buckets.clear();
    idx.varBucket.clear();
    List<Obj> clauses = pred.get(K_CLAUSES);
    for(int i=0;i<clauses.size();i++){
      Obj h = clauses.get(i).get(K_HEAD);
      if(h.get(K_TAG)!=Tag.COMP) continue;
      if(h.get(K_ARITY)==0){
        // no first-arg indexing for 0-arity
        idx.varBucket.add(i);
        continue;
      }
      Obj a1 = h.get(K_ARGS).get(0);
      String k = idxKey(a1);
      if("*".equals(k)){
        idx.varBucket.add(i);
      } else {
        idx.buckets.computeIfAbsent(k, kk->new ArrayList<>()).add(i);
      }
    }
  }

  static List<Obj> candidatesFor(Obj pred, Obj goal, Trail tr){
    List<Obj> clauses = pred.get(K_CLAUSES);
    if(clauses==null || clauses.isEmpty()) return List.of();
    if(goal.get(K_ARITY)==0) return clauses;

    Obj a1 = goal.get(K_ARGS).get(0);
    a1 = deref(a1, tr);
    if(a1.get(K_TAG)==Tag.VAR) return clauses;

    FirstArgIndex idx = pred.get(K_INDEX);
    if(idx==null) return clauses;

    String k = idxKey(a1);
    List<Integer> fixed = idx.buckets.getOrDefault(k, List.of());
    List<Integer> vars = idx.varBucket;

    if(fixed.isEmpty() && vars.isEmpty()) return List.of();
    if(vars.isEmpty()){
      List<Obj> out = new ArrayList<>(fixed.size());
      for(int ii: fixed) out.add(clauses.get(ii));
      return out;
    }
    if(fixed.isEmpty()){
      List<Obj> out = new ArrayList<>(vars.size());
      for(int ii: vars) out.add(clauses.get(ii));
      return out;
    }

    // merge fixed + vars indices to preserve source order
    ArrayList<Obj> out = new ArrayList<>(fixed.size()+vars.size());
    int i=0,j=0;
    while(i<fixed.size() || j<vars.size()){
      int fi = i<fixed.size()? fixed.get(i) : Integer.MAX_VALUE;
      int vj = j<vars.size()? vars.get(j) : Integer.MAX_VALUE;
      if(fi<=vj){
        out.add(clauses.get(fi)); i++;
      } else {
        out.add(clauses.get(vj)); j++;
      }
    }
    return out;
  }

  static Obj Program(){
    Obj e = new Obj();
    e.set(K_PREDICATES, new HashMap<>());
    return e;
  }

  static void definePred(Obj prog, String name, int arity, Obj pred){
    prog.get(K_PREDICATES).put(pi(name, arity), pred);
    rebuildIndex(pred);
  }

  static Obj getPred(Map<String,Obj> preds, String name, int arity){
    return preds.get(pi(name, arity));
  }

  /* =========================
   * Engine
   * ========================= */
  static Obj Engine(Map<String,Obj> predicates){
    Obj e=new Obj();
    e.set(K_GOALS, new ArrayDeque<>());
    e.set(K_CHOICES, new ArrayDeque<>());
    e.set(K_TRAIL, new Trail());
    e.set(K_PREDICATES, predicates);
    e.set(K_CUT_STACK, new ArrayDeque<>());
    return e;
  }

  // Rename clause vars apart
  static Obj renameClause(Obj clause, Map<Obj,Obj> ren){
    Function<Obj,Obj> copyTerm = new Function<>(){
      public Obj apply(Obj t){
        Tag tag = t.get(K_TAG);
        if(tag==Tag.VAR){
          // IMPORTANT:
          // Some dynamic DB facts/rules may contain VAR terms that are already bound
          // (e.g., asserted from within a goal where vars were instantiated).
          // When we "freshen" a clause for resolution, we must preserve the
          // *structure* of such bound vars; otherwise renameClause would turn a
          // bound slot into a fresh unbound variable, breaking lookups (e.g. OO
          // method tables) and making dynamic facts appear to "lose" their data.

          Obj d = t;
          // Deref without a trail: follow K_BIND chain.
          while(d.get(K_TAG)==Tag.VAR && d.get(K_BIND)!=null){
            d = d.get(K_BIND);
          }
          if(d.get(K_TAG)==Tag.VAR){
            // Unbound var: rename consistently.
            return ren.computeIfAbsent(d, k->Var());
          }
          // Bound var: copy the dereferenced structure.
          return apply(d);
        }
        if(tag==Tag.ATOM || tag==Tag.NUM){ return t; }
        if(tag==Tag.COMP){
          List<Obj> as=t.get(K_ARGS);
          Obj[] ns=new Obj[as.size()];
          for(int i=0;i<as.size();i++) ns[i]=apply(as.get(i));
          return Comp(t.get(K_NAME), ns);
        }
        return t;
      }
    };
    Obj h = copyTerm.apply(clause.get(K_HEAD));
    List<Obj> body = clause.get(K_BODY);
    Obj[] nb = new Obj[body.size()];
    for(int i=0;i<body.size();i++) nb[i]=copyTerm.apply(body.get(i));
    return Clause(h, nb);
  }

  /* =========================
   * Built-ins (det + nondet)
   * ========================= */
  static final Set<String> BUILTINS_PI = Set.of(
      // JSON / POJO
      "json_parse/2",
      "json_stringify/2",
      "from_json/3",
      "to_json/2",
      // heap hygiene
      "release_ref/1",
      "clear_heap/0",
      "heap_size/1",
      // control/meta
      "call/1",
      "once/1",
      // arithmetic
      "is/2",
      "=:=/2",
      "=\\=/2",
      "</2",
      "=</2",
      ">/2",
      ">=/2",
      // aggregation
      "findall/3",
      "bagof/3",
      "setof/3",
      // dynamic DB
      "assertz/1",
      "retract/1"
  );

  static final Set<String> NONDET_BUILTINS_PI = Set.of(
      "bagof/3",
      "setof/3",
      "retract/1"
  );

  static int BUILTIN_DISPATCH_ATTEMPTS = 0;
  static int CLAUSE_ATTEMPTS = 0;


  /* =========================
   * Query / resolution
   * ========================= */
  static List<Map<Integer,Obj>> query(Obj prog, Obj goal){
    Map<String,Obj> preds = prog.get(K_PREDICATES);
    Obj engine = Engine(preds);

    List<Map<Integer,Obj>> solutions = new ArrayList<>();
    solveLoop(engine, goal, false, solutions::add);
    return solutions;
  }

  static boolean solveOnce(Obj engine, Obj goal){
    return solveLoop(engine, goal, true, null);
  }

  static boolean solveLoop(Obj engine, Obj queryGoal, boolean stopAfterFirst, Consumer<Map<Integer,Obj>> onSolution){
    Trail trail = engine.get(K_TRAIL);
    Deque<ChoicePoint> choices = engine.get(K_CHOICES);
    Deque<Obj> goals = engine.get(K_GOALS);
    ArrayDeque<Integer> cutStack = engine.get(K_CUT_STACK);
    Map<String,Obj> preds = engine.get(K_PREDICATES);

    goals.clear();
    goals.add(queryGoal);

    choices.clear();
    cutStack.clear();
    goals.clear();
    goals.add(queryGoal);

    boolean any=false;

    loop:
    while(true){
      if(goals.isEmpty()){
        any=true;

        if(onSolution!=null){
          // success: snapshot visible query variable bindings (stable across backtracking)
          Map<Integer,Obj> qvars = new LinkedHashMap<>();
          collectQueryVars(queryGoal, qvars);

          IdentityHashMap<Obj,Obj> memo = new IdentityHashMap<>();
          Set<Obj> resolving = Collections.newSetFromMap(new IdentityHashMap<>());
          Map<Integer,Obj> sol = new LinkedHashMap<>();
          for(Map.Entry<Integer,Obj> e : qvars.entrySet()){
            sol.put(e.getKey(), snapshotTerm(e.getValue(), memo, resolving));
          }
          onSolution.accept(sol);
        }

        if(stopAfterFirst) return true;
        if(!redo(engine)) break;
        continue;
      }

      Obj G = goals.pollFirst();
      if(G==null) continue;
      G = deref(G, trail);

      // Allow callables as atoms for arity-0 predicates (e.g., call(true)).
      if(G.get(K_TAG)==Tag.ATOM){
        G = Comp(G.get(K_NAME));
      }

      if(G.get(K_TAG)!=Tag.COMP){
        throw new IllegalStateException("Goal must be callable, got: "+pp(G));
      }

      String name = G.get(K_NAME);
      int ar = G.get(K_ARITY);
      String predInd = pi(name, ar);

      // Internal control goals (engine bookkeeping)
      if("__pop_cut".equals(name) && ar==0){
        if(!cutStack.isEmpty()) cutStack.pop();
        continue;
      }
      if("__cut_to".equals(name) && ar==1){
        Obj nterm = deref(G.get(K_ARGS).get(0), trail);
        if(nterm.get(K_TAG)!=Tag.NUM) throw new RuntimeException("__cut_to/1 expects integer");
        int target = (int)Long.parseLong(nterm.get(K_NAME));
        while(choices.size() > target) choices.pop();
        continue;
      }

      // Conjunction ,/2
      if(",".equals(name) && ar==2){
        Obj A = G.get(K_ARGS).get(0);
        Obj B = G.get(K_ARGS).get(1);
        goals.addFirst(B);
        goals.addFirst(A);
        continue;
      }

      // Disjunction ;/2 (also handles if-then-else as ;(->(If,Then),Else))
      if(";".equals(name) && ar==2){
        Obj A = G.get(K_ARGS).get(0);
        Obj B = G.get(K_ARGS).get(1);

        Obj Ad = deref(A, trail);
        if(Ad.get(K_TAG)==Tag.COMP && "->".equals(Ad.get(K_NAME)) && Ad.get(K_ARITY)==2){
          // If-Then-Else: (If -> Then ; Else)
          int depth = choices.size(); // before pushing Else choicepoint
          ArrayDeque<Obj> alt = new ArrayDeque<>(goals);
          alt.addFirst(B);
          choices.push(ChoicePoint.goal(alt, trail.mark(), cutStack.size()));

          Obj If = Ad.get(K_ARGS).get(0);
          Obj Then = Ad.get(K_ARGS).get(1);
          goals.addFirst(Comp("call", Then));
          goals.addFirst(Comp("__cut_to", Num(depth)));
          goals.addFirst(Comp("call", If));
          continue;
        }

        // plain disjunction: (A ; B)
        ArrayDeque<Obj> alt = new ArrayDeque<>(goals);
        alt.addFirst(B);
        choices.push(ChoicePoint.goal(alt, trail.mark(), cutStack.size()));
        goals.addFirst(A);
        continue;
      }

      // Cut !/0
      if("!".equals(name) && ar==0){
        int barrier = cutStack.isEmpty() ? 0 : cutStack.peek();
        while(choices.size() > barrier) choices.pop();
        continue;
      }

      // call/1 (meta-call)
      if("call".equals(name) && ar==1){
        Obj callee = deref(G.get(K_ARGS).get(0), trail);
        if(callee.get(K_TAG)==Tag.VAR) throw new RuntimeException("call/1: instantiation error");
        if(callee.get(K_TAG)==Tag.ATOM){
          goals.addFirst(Comp(callee.get(K_NAME)));
          continue;
        }
        if(callee.get(K_TAG)==Tag.COMP){
          goals.addFirst(callee);
          continue;
        }
        throw new RuntimeException("call/1: non-callable: "+pp(callee));
      }

      // once/1
      if("once".equals(name) && ar==1){
        int depth = choices.size();
        goals.addFirst(Comp("__cut_to", Num(depth)));
        goals.addFirst(Comp("call", G.get(K_ARGS).get(0)));
        continue;
      }

      // If-Then ->/2
      if("->".equals(name) && ar==2){
        int depth = choices.size();
        Obj If = G.get(K_ARGS).get(0);
        Obj Then = G.get(K_ARGS).get(1);
        goals.addFirst(Comp("call", Then));
        goals.addFirst(Comp("__cut_to", Num(depth)));
        goals.addFirst(Comp("call", If));
        continue;
      }

      // Negation as failure \+/1
      if("\\+".equals(name) && ar==1){
        Obj inner = G.get(K_ARGS).get(0);
        boolean ok = proveOnceSandbox(engine, inner);
        if(ok){
          if(!redo(engine)) break;
          continue;
        }
        continue;
      }

      // Core builtins: true/0, fail/0, =/2
      if("true".equals(name) && ar==0){ continue; }
      if("fail".equals(name) && ar==0){
        if(!redo(engine)) break;
        continue;
      }
      if("=".equals(name) && ar==2){
        int mark = trail.mark();
        boolean ok = unify(G.get(K_ARGS).get(0), G.get(K_ARGS).get(1), trail);
        if(ok) continue;
        trail.unwindTo(mark);
        if(!redo(engine)) break;
        continue;
      }

      // Extended builtins (det + nondet)
      if(BUILTINS_PI.contains(predInd)){
        int markBefore = trail.mark();
        int cutSizeBefore = cutStack.size();
        BuiltinExec exec = startBuiltin(engine, G, trail);
        if(exec==null){
          // shouldn't happen if BUILTINS_PI is correct
          trail.unwindTo(markBefore);
          while(cutStack.size()>cutSizeBefore) cutStack.pop();
          if(!redo(engine)) break;
          continue;
        }

        boolean ok = exec.next(trail);
        if(ok){
          if(NONDET_BUILTINS_PI.contains(predInd)){
            choices.push(ChoicePoint.builtin(new ArrayDeque<>(goals), markBefore, cutSizeBefore, exec));
          }
          continue;
        }
        trail.unwindTo(markBefore);
        while(cutStack.size()>cutSizeBefore) cutStack.pop();
        if(!redo(engine)) break;
        continue;
      }

      // User predicates
      Obj pred = getPred(preds, name, ar);
      if(pred==null){
        throw new IllegalStateException("Unknown predicate: "+predInd);
      }

      List<Obj> candidates = candidatesFor(pred, G, trail);
      if(candidates.isEmpty()){
        if(!redo(engine)) break;
        continue;
      }

      int predEntryTrailMark = trail.mark();
      int predEntryCutSize = cutStack.size();
      int predEntryChoiceDepth = choices.size();

      for(int pos=0; pos<candidates.size(); pos++){
        Obj clause = candidates.get(pos);
        Obj fresh = renameClause(clause, new IdentityHashMap<>());

        int localMark = trail.mark();
        CLAUSE_ATTEMPTS++;
        if(unify(G, fresh.get(K_HEAD), trail)){
          if(pos+1 < candidates.size()){
            ArrayDeque<Obj> goalsSnap = new ArrayDeque<>(goals);
            goalsSnap.addFirst(G); // retry this goal on backtrack
            choices.push(ChoicePoint.clause(goalsSnap, predEntryTrailMark, predEntryCutSize, candidates, pos+1, predEntryChoiceDepth));
          }

          // Push cut barrier for this predicate invocation, and ensure it is popped on normal completion.
          cutStack.push(predEntryChoiceDepth);
          List<Obj> body = fresh.get(K_BODY);
          ArrayList<Obj> body2 = new ArrayList<>(body);
          body2.add(Comp("__pop_cut"));
          for(int j=body2.size()-1;j>=0;j--) goals.addFirst(body2.get(j));
          continue loop;
        } else {
          trail.unwindTo(localMark);
        }
      }

      trail.unwindTo(predEntryTrailMark);
      while(cutStack.size()>predEntryCutSize) cutStack.pop();
      if(!redo(engine)) break;
    }

    return any;
  }

  static boolean redo(Obj engine){
    Deque<ChoicePoint> choices = engine.get(K_CHOICES);
    Trail trail = engine.get(K_TRAIL);
    ArrayDeque<Integer> cutStack = engine.get(K_CUT_STACK);

    while(!choices.isEmpty()){
      ChoicePoint cp = choices.pop();
      trail.unwindTo(cp.trailMark);
      while(cutStack.size()>cp.cutStackSize) cutStack.pop();

      engine.get(K_GOALS).clear();
      engine.get(K_GOALS).addAll(cp.goals);

      if(cp.kind==CpKind.GOAL){
        return true;
      }

      if(cp.kind==CpKind.BUILTIN){
        if(cp.builtinExec.next(trail)){
          // re-push for further solutions (if any)
          choices.push(ChoicePoint.builtin(new ArrayDeque<>(engine.get(K_GOALS)), cp.trailMark, cp.cutStackSize, cp.builtinExec));
          return true;
        }
        continue;
      }

      // CLAUSE retry
      Obj goal = engine.get(K_GOALS).pollFirst();
      if(goal==null) continue;

      for(int pos=cp.nextPos; pos<cp.candidates.size(); pos++){
        int localMark = trail.mark();
        Obj fresh = renameClause(cp.candidates.get(pos), new IdentityHashMap<>());
        CLAUSE_ATTEMPTS++;
        if(unify(goal, fresh.get(K_HEAD), trail)){
          if(pos+1 < cp.candidates.size()){
            ArrayDeque<Obj> goalsSnap = new ArrayDeque<>(engine.get(K_GOALS));
            goalsSnap.addFirst(goal);
            choices.push(ChoicePoint.clause(goalsSnap, cp.trailMark, cp.cutStackSize, cp.candidates, pos+1, cp.choiceBarrier));
          }

          engine.get(K_CUT_STACK).push(cp.choiceBarrier);
          List<Obj> body = fresh.get(K_BODY);
          ArrayList<Obj> body2 = new ArrayList<>(body);
          body2.add(Comp("__pop_cut"));
          for(int j=body2.size()-1;j>=0;j--) engine.get(K_GOALS).addFirst(body2.get(j));
          return true;
        }
        trail.unwindTo(localMark);
      }
    }
    return false;
  }

  static void collectQueryVars(Obj t, Map<Integer,Obj> out){
    Tag tag = t.get(K_TAG);
    if(tag==Tag.VAR){
      out.putIfAbsent(t.get(K_VID), t);
      return;
    }
    if(tag==Tag.COMP){
      for(Obj a: t.get(K_ARGS)) collectQueryVars(a, out);
    }
  }

  /* =========================
   * Snapshot / reify (Stage 3)
   * ========================= */
  static Obj snapshotTerm(Obj t, IdentityHashMap<Obj,Obj> memo, Set<Obj> resolving){
    t = deref(t, new Trail());

    Obj cached = memo.get(t);
    if(cached != null) return cached;

    Tag tag = t.get(K_TAG);
    if(tag==Tag.VAR){
      return snapshotVar(t, memo, resolving);
    }
    if(tag==Tag.ATOM){
      Obj o = Atom(t.get(K_NAME));
      memo.put(t, o);
      return o;
    }
    if(tag==Tag.NUM){
      Obj o = Num(Long.parseLong(t.get(K_NAME)));
      memo.put(t, o);
      return o;
    }
    if(tag==Tag.COMP){
      Obj o = new Obj(COMP_PROTO);
      o.set(K_TAG, Tag.COMP);
      o.set(K_NAME, t.get(K_NAME));
      List<Obj> args = t.get(K_ARGS);
      o.set(K_ARITY, args.size());
      List<Obj> nargs = new ArrayList<>(Collections.nCopies(args.size(), (Obj)null));
      o.set(K_ARGS, nargs);
      memo.put(t, o); // important for sharing
      for(int i=0;i<args.size();i++){
        nargs.set(i, snapshotTerm(args.get(i), memo, resolving));
      }
      return o;
    }
    return t;
  }

  static Obj snapshotVar(Obj v, IdentityHashMap<Obj,Obj> memo, Set<Obj> resolving){
    Obj cached = memo.get(v);
    if(cached != null) return cached;

    int vid = v.get(K_VID);

    // Cycle guard for pathological graphs.
    if(resolving.contains(v)){
      Obj vs = VarSnapshot(vid);
      memo.put(v, vs);
      return vs;
    }

    resolving.add(v);
    Obj b = v.get(K_BIND);
    Obj res;
    if(b==null){
      res = VarSnapshot(vid);
    } else {
      res = snapshotTerm(deref(b, new Trail()), memo, resolving);
    }
    resolving.remove(v);
    memo.put(v, res);
    return res;
  }

  static Obj VarSnapshot(int vid){
    Obj o=new Obj(VAR_PROTO);
    o.set(K_TAG, Tag.VAR);
    o.set(K_VID, vid);
    o.set(K_BIND, null);
    return o;
  }

  /* =========================
   * Pattern freezing
   * =========================
   *
   * retract/1 is nondet and stores its pattern across calls to BuiltinExec.next().
   * We want the stored pattern to reflect any *current* bindings inside the pattern
   * term (deeply), but we must NOT replace unbound variables with fresh snapshot
   * variables. Otherwise, bindings produced by retract/1 won't propagate back to
   * the caller (e.g. retract(obj_counter(N)) would never bind N).
   */
  static Obj freezePatternTerm(Obj t, Trail tr){
    return freezePatternTerm(
        t,
        tr,
        new IdentityHashMap<>(),
        Collections.newSetFromMap(new IdentityHashMap<>())
    );
  }

  static Obj freezePatternTerm(Obj t, Trail tr, IdentityHashMap<Obj,Obj> memo, Set<Obj> resolving){
    t = deref(t, tr);

    Obj cached = memo.get(t);
    if(cached != null) return cached;

    Tag tag = t.get(K_TAG);
    if(tag==Tag.VAR){
      // Keep unbound vars as-is so any new bindings propagate to the caller.
      if(t.get(K_BIND)==null){
        memo.put(t, t);
        return t;
      }
      // Bound vars should be replaced by their (frozen) bound value.
      if(resolving.contains(t)){
        // Defensive: shouldn't happen with occurs-check, but don't loop.
        memo.put(t, t);
        return t;
      }
      resolving.add(t);
      Obj res = freezePatternTerm(t.get(K_BIND), tr, memo, resolving);
      resolving.remove(t);
      memo.put(t, res);
      return res;
    }
    if(tag==Tag.ATOM || tag==Tag.NUM){
      memo.put(t, t);
      return t;
    }
    if(tag==Tag.COMP){
      Obj o = new Obj(COMP_PROTO);
      o.set(K_TAG, Tag.COMP);
      o.set(K_NAME, t.get(K_NAME));
      List<Obj> args = t.get(K_ARGS);
      o.set(K_ARITY, args.size());
      List<Obj> nargs = new ArrayList<>(Collections.nCopies(args.size(), (Obj)null));
      o.set(K_ARGS, nargs);
      memo.put(t, o);
      for(int i=0;i<args.size();i++){
        nargs.set(i, freezePatternTerm(args.get(i), tr, memo, resolving));
      }
      return o;
    }

    memo.put(t, t);
    return t;
  }

  /* =========================
   * Lists
   * ========================= */
  static Obj listNil(){ return Atom("[]"); }
  static Obj listCons(Obj H, Obj T){ return Comp(".", H, T); }

  static Obj list(Obj...items){
    Obj t=listNil();
    for(int i=items.length-1;i>=0;i--) t=listCons(items[i], t);
    return t;
  }

  static boolean isProperList(Obj t){
    Obj cur = deref(t, new Trail());
    while(true){
      if(isNil(cur)) return true;
      if(!isCons(cur)) return false;
      cur = deref(cur.get(K_ARGS).get(1), new Trail());
    }
  }

  static List<Obj> flattenProperList(Obj list){
    List<Obj> out = new ArrayList<>();
    Obj cur = deref(list, new Trail());
    while(true){
      if(isNil(cur)) return out;
      if(!isCons(cur)) throw new RuntimeException("expected proper list, got: "+pp(list));
      out.add(cur.get(K_ARGS).get(0));
      cur = deref(cur.get(K_ARGS).get(1), new Trail());
    }
  }

  /* =========================
   * Sample program
   * ========================= */
  static void loadSampleProgram(Obj prog){
    // append([], Ys, Ys).
    Obj Y = Var();
    Obj H1 = Comp("append", listNil(), Y, Y);
    Obj C1 = Clause(H1);

    // append([H|T], Ys, [H|Zs]) :- append(T, Ys, Zs).
    Obj V_H = Var(); Obj V_T = Var(); Obj V_Ys = Var(); Obj V_Zs = Var();
    Obj HeadList = listCons(V_H, V_T);
    Obj ResList  = listCons(V_H, V_Zs);
    Obj H2 = Comp("append", HeadList, V_Ys, ResList);
    Obj B2 = Comp("append", V_T, V_Ys, V_Zs);
    Obj C2 = Clause(H2, B2);

    definePred(prog, "append", 3, Predicate(C1, C2));
  }

  /* =========================
   * JSON <-> Term and POJO built-ins
   * ========================= */
  static class Json {
    static final class P {
      final String s;
      int i=0;
      P(String s){ this.s=s; }
      char ch(){ return s.charAt(i); }
      boolean eof(){ return i>=s.length(); }
      void ws(){
        while(!eof()){
          char c=ch();
          if(c==' '||c=='\n'||c=='\r'||c=='\t') i++;
          else break;
        }
      }
    }

    static boolean ahead(P p, String w){
      int n=w.length();
      return p.i+n<=p.s.length() && p.s.regionMatches(p.i, w, 0, n);
    }

    static Obj Str(String s){ return Comp("str", Atom(s)); }

    static Obj parse(String s){
      P p=new P(s);
      p.ws();
      Obj v=parseValue(p);
      p.ws();
      if(!p.eof()) throw new RuntimeException("trailing input at "+p.i);
      return v;
    }

    static Obj parseValue(P p){
      p.ws();
      if(p.eof()) throw new RuntimeException("EOF");
      char c=p.ch();
      if(c=='"') return Str(parseString(p));
      if(c=='{') return parseObject(p);
      if(c=='[') return parseArray(p);
      if(c=='t' && ahead(p, "true")) { p.i+=4; return Atom("true"); }
      if(c=='f' && ahead(p, "false")) { p.i+=5; return Atom("false"); }
      if(c=='n' && ahead(p, "null")) { p.i+=4; return Atom("null"); }
      return parseNumber(p);
    }

    static String parseString(P p){
      if(p.eof() || p.ch()!='"') throw new RuntimeException("expected quote at "+p.i);
      p.i++;
      StringBuilder sb=new StringBuilder();
      boolean closed=false;
      while(!p.eof()){
        char c=p.ch(); p.i++;
        if(c=='"'){ closed=true; break; }
        if(c=='\\'){
          if(p.eof()) throw new RuntimeException("bad escape at "+p.i);
          char e=p.ch(); p.i++;
          switch(e){
            case '"': sb.append('"'); break;
            case '\\': sb.append('\\'); break;
            case '/': sb.append('/'); break;
            case 'b': sb.append('\b'); break;
            case 'f': sb.append('\f'); break;
            case 'n': sb.append('\n'); break;
            case 'r': sb.append('\r'); break;
            case 't': sb.append('\t'); break;
            case 'u': {
              if(p.i+4>p.s.length()) throw new RuntimeException("bad unicode escape at "+p.i);
              int cp=Integer.parseInt(p.s.substring(p.i, p.i+4),16);
              sb.append((char)cp);
              p.i+=4;
              break;
            }
            default: throw new RuntimeException("bad escape: "+e);
          }
        } else {
          // JSON disallows unescaped control chars in strings.
          if(c < 0x20) throw new RuntimeException("control char in string at "+(p.i-1));
          sb.append(c);
        }
      }
      if(!closed) throw new RuntimeException("unterminated string");
      return sb.toString();
    }

    // Stage 5: strict JSON number parsing.
    static Obj parseNumber(P p){
      int start = p.i;
      int len = p.s.length();

      if(p.ch()=='-'){
        p.i++;
        if(p.i>=len) throw new RuntimeException("bad number at "+start);
      }

      if(p.i>=len) throw new RuntimeException("bad number at "+start);
      char c = p.s.charAt(p.i);

      // int part
      if(c=='0'){
        p.i++;
        // no leading zeros (e.g., 01)
        if(p.i<len){
          char n = p.s.charAt(p.i);
          if(n>='0' && n<='9') throw new RuntimeException("leading zero at "+start);
        }
      } else if(c>='1' && c<='9'){
        while(p.i<len){
          char d = p.s.charAt(p.i);
          if(d>='0' && d<='9') p.i++;
          else break;
        }
      } else {
        throw new RuntimeException("bad number at "+start);
      }

      boolean hasDot=false, hasExp=false;

      // frac part
      if(p.i<len && p.s.charAt(p.i)=='.'){
        hasDot=true;
        p.i++;
        if(p.i>=len) throw new RuntimeException("bad fraction at "+start);
        char d = p.s.charAt(p.i);
        if(!(d>='0' && d<='9')) throw new RuntimeException("bad fraction at "+start);
        while(p.i<len){
          char dd = p.s.charAt(p.i);
          if(dd>='0' && dd<='9') p.i++;
          else break;
        }
      }

      // exp part
      if(p.i<len){
        char e = p.s.charAt(p.i);
        if(e=='e' || e=='E'){
          hasExp=true;
          p.i++;
          if(p.i>=len) throw new RuntimeException("bad exponent at "+start);
          char sgn = p.s.charAt(p.i);
          if(sgn=='+' || sgn=='-'){
            p.i++;
            if(p.i>=len) throw new RuntimeException("bad exponent at "+start);
          }
          char d0 = p.s.charAt(p.i);
          if(!(d0>='0' && d0<='9')) throw new RuntimeException("bad exponent at "+start);
          while(p.i<len){
            char dd = p.s.charAt(p.i);
            if(dd>='0' && dd<='9') p.i++;
            else break;
          }
        }
      }

      String num=p.s.substring(start, p.i);
      try{
        if(hasDot||hasExp){
          double d=Double.parseDouble(num);
          return Comp("double", Atom(Double.toString(d)));
        } else {
          long l=Long.parseLong(num);
          return Num(l);
        }
      } catch(Exception e){
        throw new RuntimeException("bad number: "+num);
      }
    }

    static Obj parseObject(P p){
      if(p.ch()!='{') throw new RuntimeException("expected { at "+p.i);
      p.i++;
      p.ws();
      if(p.eof()) throw new RuntimeException("unterminated object");
      List<Obj> kvs=new ArrayList<>();
      if(p.ch()=='}'){ p.i++; return Comp("obj", list()); }
      while(true){
        p.ws();
        String k=parseString(p);
        p.ws();
        if(p.eof() || p.ch()!=':') throw new RuntimeException("expected : at "+p.i);
        p.i++;
        Obj v=parseValue(p);
        kvs.add(Comp("kv", Atom(k), v));
        p.ws();
        if(p.eof()) throw new RuntimeException("unterminated object");
        if(p.ch()==','){ p.i++; continue; }
        if(p.ch()=='}'){ p.i++; break; }
        throw new RuntimeException("expected , or } at "+p.i);
      }
      return Comp("obj", list(kvs.toArray(new Obj[0])));
    }

    static Obj parseArray(P p){
      if(p.ch()!='[') throw new RuntimeException("expected [ at "+p.i);
      p.i++;
      p.ws();
      if(p.eof()) throw new RuntimeException("unterminated array");
      List<Obj> els=new ArrayList<>();
      if(p.ch()==']'){ p.i++; return Comp("arr", list()); }
      while(true){
        Obj v=parseValue(p);
        els.add(v);
        p.ws();
        if(p.eof()) throw new RuntimeException("unterminated array");
        if(p.ch()==','){ p.i++; continue; }
        if(p.ch()==']'){ p.i++; break; }
        throw new RuntimeException("expected , or ] at "+p.i);
      }
      return Comp("arr", list(els.toArray(new Obj[0])));
    }

    static String stringify(Obj term){
      term = deref(term, new Trail());
      Tag t = term.get(K_TAG);
      if(t==Tag.NUM) return term.get(K_NAME);

      if(t==Tag.ATOM){
        String s=term.get(K_NAME);
        if("true".equals(s)||"false".equals(s)||"null".equals(s)) return s;
        return "\"" + escape(s) + "\"";
      }

      if(t==Tag.COMP){
        String f=term.get(K_NAME);
        if("str".equals(f) && term.get(K_ARITY)==1){
          String payload = deref(term.get(K_ARGS).get(0), new Trail()).get(K_NAME);
          return "\"" + escape(payload) + "\"";
        }
        if("obj".equals(f)) return writeObject(term);
        if("arr".equals(f)) return writeArray(term);
        if("double".equals(f)) return term.get(K_ARGS).get(0).get(K_NAME);
      }

      throw new RuntimeException("Cannot stringify term: "+pp(term));
    }

    static String writeObject(Obj o){
      StringBuilder sb=new StringBuilder();
      sb.append('{');
      List<Obj> kvs = flattenList(o.get(K_ARGS).get(0));
      boolean first=true;
      for(Obj kv: kvs){
        if(!first) sb.append(',');
        first=false;

        Obj kTerm = deref(kv.get(K_ARGS).get(0), new Trail());
        String k;
        if(kTerm.get(K_TAG)==Tag.ATOM){
          k = kTerm.get(K_NAME);
        } else if(kTerm.get(K_TAG)==Tag.COMP && "str".equals(kTerm.get(K_NAME)) && kTerm.get(K_ARITY)==1){
          k = deref(kTerm.get(K_ARGS).get(0), new Trail()).get(K_NAME);
        } else {
          throw new RuntimeException("object key must be atom or str/1, got: "+pp(kTerm));
        }

        sb.append('"').append(escape(k)).append('"').append(':');
        sb.append(stringify(kv.get(K_ARGS).get(1)));
      }
      sb.append('}');
      return sb.toString();
    }

    static String writeArray(Obj a){
      StringBuilder sb=new StringBuilder();
      sb.append('[');
      List<Obj> els = flattenList(a.get(K_ARGS).get(0));
      for(int i=0;i<els.size();i++){
        if(i>0) sb.append(',');
        sb.append(stringify(els.get(i)));
      }
      sb.append(']');
      return sb.toString();
    }

    // Stage 5: escape control characters as JSON unicode escapes.
    static String escape(String s){
      StringBuilder b=new StringBuilder();
      for(int i=0;i<s.length();i++){
        char c=s.charAt(i);
        switch(c){
          case '"':  b.append("\\\""); break;
          case '\\': b.append("\\\\"); break;
          case '\b': b.append("\\b");  break;
          case '\f': b.append("\\f");  break;
          case '\n': b.append("\\n");  break;
          case '\r': b.append("\\r");  break;
          case '\t': b.append("\\t");  break;
          default:
            if(c < 0x20){
              b.append(String.format("\\\\u%04x", (int)c));
            } else {
              b.append(c);
            }
        }
      }
      return b.toString();
    }

    static List<Obj> flattenList(Obj list){
      List<Obj> out=new ArrayList<>();
      Obj t = list;
      while(true){
        t = deref(t, new Trail());
        if(t.get(K_TAG)==Tag.ATOM && "[]".equals(t.get(K_NAME))) break;
        String fun=t.get(K_NAME);
        if(!".".equals(fun)) throw new RuntimeException("expected list");
        List<Obj> args=t.get(K_ARGS);
        out.add(args.get(0));
        t = args.get(1);
      }
      return out;
    }
  }

  /* =========================
   * Java object registry (heap)
   * ========================= */
  static final Map<Integer,Object> HEAP = new HashMap<>();
  static int NEXT_ID=1;

  // Safety: restrict which Java classes can be instantiated via from_json/3.
  static final List<String> ALLOWED_CLASS_PREFIXES = List.of(
      "com.mycompany.prolog."
  );

  // Heap hygiene / safety knobs
  static final int HEAP_MAX_OBJECTS = 50_000;  // hard cap

  // Runtime configuration (override via -D... system properties)
  static boolean propBool(String key, boolean def){
    String v = System.getProperty(key);
    return (v==null) ? def : Boolean.parseBoolean(v);
  }

  // Logging: print built-in errors to stderr (and optionally stacktraces).
  static boolean PRINT_BUILTIN_ERRORS = propBool("prolog.printBuiltinErrors", true);
  static boolean PRINT_BUILTIN_STACKTRACES = propBool("prolog.printBuiltinStacktraces", false);

  // Error semantics: if true, built-in exceptions abort the query (throw).
  // If false, built-ins convert exceptions into logical failure.
  static boolean BUILTIN_EXCEPTIONS_ARE_ERRORS = propBool("prolog.builtinExceptionsAreErrors", true);

  static Obj refOf(Object o){
    if(HEAP.size() >= HEAP_MAX_OBJECTS) throw new RuntimeException("heap limit exceeded: "+HEAP_MAX_OBJECTS);
    int id=NEXT_ID++;
    HEAP.put(id, o);
    return Comp("ref", Num(id));
  }

  static Object objFromRef(Obj term){
    term = deref(term, new Trail());
    if(!(term.get(K_TAG)==Tag.COMP && "ref".equals(term.get(K_NAME)) && term.get(K_ARITY)==1)){
      throw new RuntimeException("expected ref/1");
    }
    int id=(int)Long.parseLong(term.get(K_ARGS).get(0).get(K_NAME));
    Object o=HEAP.get(id);
    if(o==null) throw new RuntimeException("dangling ref: "+id);
    return o;
  }

  static void requireAllowedClassName(String className){
    for(String p : ALLOWED_CLASS_PREFIXES){
      if(className.startsWith(p)) return;
    }
    throw new RuntimeException("Class not allowed: "+className);
  }

  static void builtinError(String builtin, Exception e){
    if(!PRINT_BUILTIN_ERRORS) return;
    System.err.println("[builtin "+builtin+"] "+e.getClass().getSimpleName()+": "+e.getMessage());
    if(PRINT_BUILTIN_STACKTRACES) e.printStackTrace(System.err);
  }

  /**
   * Extract a Java String from a term that is either Atom("...") or a JSON string term str(Atom("...")).
   */
  static String termToJavaString(Obj t, Trail trail){
    t = deref(t, trail);
    if(t.get(K_TAG)==Tag.ATOM) return t.get(K_NAME);
    if(t.get(K_TAG)==Tag.COMP && "str".equals(t.get(K_NAME)) && t.get(K_ARITY)==1){
      Obj a = deref(t.get(K_ARGS).get(0), trail);
      if(a.get(K_TAG)!=Tag.ATOM) throw new RuntimeException("str/1 must contain an atom payload");
      return a.get(K_NAME);
    }
    throw new RuntimeException("expected Atom or str/1, got: "+pp(t));
  }

  /* =========================
   * Built-in implementation (det + nondet)
   * ========================= */

  static final class NumVal {
    final boolean isFloat;
    final long i;
    final double f;
    NumVal(long i){ this.isFloat=false; this.i=i; this.f=i; }
    NumVal(double f){ this.isFloat=true; this.f=f; this.i=(long)f; }
  }

  static boolean isDoubleTerm(Obj t){
    t = deref(t, new Trail());
    return t.get(K_TAG)==Tag.COMP && "double".equals(t.get(K_NAME)) && t.get(K_ARITY)==1;
  }

  static NumVal toNumVal(Obj t, Trail trail){
    t = deref(t, trail);
    Tag tag = t.get(K_TAG);
    if(tag==Tag.NUM) return new NumVal(Long.parseLong(t.get(K_NAME)));
    if(tag==Tag.COMP && "double".equals(t.get(K_NAME)) && t.get(K_ARITY)==1){
      Obj a = deref(t.get(K_ARGS).get(0), trail);
      if(a.get(K_TAG)!=Tag.ATOM) throw new RuntimeException("double/1 payload must be atom");
      return new NumVal(Double.parseDouble(a.get(K_NAME)));
    }
    if(tag==Tag.VAR) throw new RuntimeException("instantiation error (number expected)");
    throw new RuntimeException("type error (number expected): "+pp(t));
  }

  static Obj numTerm(NumVal v){
    if(!v.isFloat) return Num(v.i);
    return Comp("double", Atom(Double.toString(v.f)));
  }

  static NumVal evalArith(Obj expr, Trail trail){
    expr = deref(expr, trail);
    Tag tag = expr.get(K_TAG);

    if(tag==Tag.NUM || isDoubleTerm(expr)) return toNumVal(expr, trail);
    if(tag==Tag.VAR) throw new RuntimeException("instantiation error (arithmetic)");
    if(tag!=Tag.COMP) throw new RuntimeException("type error (arithmetic expression): "+pp(expr));

    String f = expr.get(K_NAME);
    int ar = expr.get(K_ARITY);
    List<Obj> as = expr.get(K_ARGS);

    if("+".equals(f) && ar==2){
      NumVal a = evalArith(as.get(0), trail);
      NumVal b = evalArith(as.get(1), trail);
      if(a.isFloat || b.isFloat) return new NumVal(a.f + b.f);
      return new NumVal(a.i + b.i);
    }
    if("-".equals(f) && ar==2){
      NumVal a = evalArith(as.get(0), trail);
      NumVal b = evalArith(as.get(1), trail);
      if(a.isFloat || b.isFloat) return new NumVal(a.f - b.f);
      return new NumVal(a.i - b.i);
    }
    if("-".equals(f) && ar==1){
      NumVal a = evalArith(as.get(0), trail);
      if(a.isFloat) return new NumVal(-a.f);
      return new NumVal(-a.i);
    }
    if("*".equals(f) && ar==2){
      NumVal a = evalArith(as.get(0), trail);
      NumVal b = evalArith(as.get(1), trail);
      if(a.isFloat || b.isFloat) return new NumVal(a.f * b.f);
      return new NumVal(a.i * b.i);
    }
    if("/".equals(f) && ar==2){
      NumVal a = evalArith(as.get(0), trail);
      NumVal b = evalArith(as.get(1), trail);
      return new NumVal(a.f / b.f);
    }
    if("//".equals(f) && ar==2){
      NumVal a = evalArith(as.get(0), trail);
      NumVal b = evalArith(as.get(1), trail);
      if(b.i==0) throw new RuntimeException("division by zero");
      return new NumVal(a.i / b.i);
    }
    if("mod".equals(f) && ar==2){
      NumVal a = evalArith(as.get(0), trail);
      NumVal b = evalArith(as.get(1), trail);
      if(b.i==0) throw new RuntimeException("division by zero");
      return new NumVal(a.i % b.i);
    }

    throw new RuntimeException("unknown arithmetic functor: "+f+"/"+ar);
  }

  static List<Obj> flattenConjunction(Obj body, Trail trail){
    body = deref(body, trail);
    if(body.get(K_TAG)==Tag.ATOM && "true".equals(body.get(K_NAME))) return List.of();
    if(body.get(K_TAG)==Tag.COMP && ",".equals(body.get(K_NAME)) && body.get(K_ARITY)==2){
      List<Obj> out = new ArrayList<>();
      out.addAll(flattenConjunction(body.get(K_ARGS).get(0), trail));
      out.addAll(flattenConjunction(body.get(K_ARGS).get(1), trail));
      return out;
    }
    return List.of(body);
  }

  static Obj conjunctionFromList(List<Obj> goals){
    if(goals.isEmpty()) return Comp("true");
    Obj acc = goals.get(goals.size()-1);
    for(int i=goals.size()-2;i>=0;i--){
      acc = Comp(",", goals.get(i), acc);
    }
    return acc;
  }

  static Obj ensureCallableHead(Obj head, Trail trail){
    head = deref(head, trail);
    if(head.get(K_TAG)==Tag.ATOM) return Comp(head.get(K_NAME));
    if(head.get(K_TAG)==Tag.COMP) return head;
    if(head.get(K_TAG)==Tag.VAR) throw new RuntimeException("instantiation error (callable expected)");
    throw new RuntimeException("type error (callable expected): "+pp(head));
  }

  static final class TermKey {
    final Obj t;
    final int h;
    TermKey(Obj t){ this.t=t; this.h=termHash(t, new IdentityHashMap<>()); }
    @Override public int hashCode(){ return h; }
    @Override public boolean equals(Object o){
      if(!(o instanceof TermKey)) return false;
      return termEquals(t, ((TermKey)o).t, new IdentityHashMap<>());
    }
  }

  static boolean termEquals(Obj a, Obj b, IdentityHashMap<Obj,Obj> seen){
    if(a==b) return true;
    Obj prev = seen.get(a);
    if(prev==b) return true;
    seen.put(a, b);

    if(a==null || b==null) return false;
    if(a.get(K_TAG)!=b.get(K_TAG)) {
      // Treat double/1 as numeric for comparisons in setof; but structural equality keeps tags strict.
      return false;
    }
    Tag ta = a.get(K_TAG);
    if(ta==Tag.VAR) return Objects.equals(a.get(K_VID), b.get(K_VID));
    if(ta==Tag.NUM || ta==Tag.ATOM) return Objects.equals(a.get(K_NAME), b.get(K_NAME));
    if(ta==Tag.COMP){
      if(!Objects.equals(a.get(K_NAME), b.get(K_NAME))) return false;
      if(!Objects.equals(a.get(K_ARITY), b.get(K_ARITY))) return false;
      List<Obj> as=a.get(K_ARGS), bs=b.get(K_ARGS);
      for(int i=0;i<as.size();i++){
        if(!termEquals(as.get(i), bs.get(i), seen)) return false;
      }
      return true;
    }
    return false;
  }

  static int termHash(Obj t, IdentityHashMap<Obj,Boolean> seen){
    if(t==null) return 0;
    if(seen.put(t, Boolean.TRUE)!=null) return System.identityHashCode(t);
    Tag tag = t.get(K_TAG);
    int h = tag.hashCode();
    if(tag==Tag.VAR) return h*31 + t.get(K_VID);
    if(tag==Tag.NUM || tag==Tag.ATOM) return h*31 + t.get(K_NAME).hashCode();
    if(tag==Tag.COMP){
      h = h*31 + t.get(K_NAME).hashCode();
      h = h*31 + t.get(K_ARITY);
      for(Obj a : t.get(K_ARGS)){
        h = h*31 + termHash(a, seen);
      }
      return h;
    }
    return h;
  }

  static int stdOrderCat(Obj t){
    t = deref(t, new Trail());
    Tag tag = t.get(K_TAG);
    if(tag==Tag.VAR) return 0;
    if(tag==Tag.NUM || isDoubleTerm(t)) return 1;
    if(tag==Tag.ATOM) return 2;
    return 3; // compounds
  }

  static int termCompare(Obj a, Obj b){
    a = deref(a, new Trail());
    b = deref(b, new Trail());
    int ca = stdOrderCat(a), cb = stdOrderCat(b);
    if(ca!=cb) return Integer.compare(ca, cb);

    if(ca==0){
      return Integer.compare(a.get(K_VID), b.get(K_VID));
    }
    if(ca==1){
      NumVal na = toNumVal(a, new Trail());
      NumVal nb = toNumVal(b, new Trail());
      if(na.isFloat || nb.isFloat) return Double.compare(na.f, nb.f);
      return Long.compare(na.i, nb.i);
    }
    if(ca==2){
      return a.get(K_NAME).compareTo(b.get(K_NAME));
    }

    // compounds: arity, name, args
    int arA = a.get(K_ARITY), arB = b.get(K_ARITY);
    if(arA!=arB) return Integer.compare(arA, arB);
    int n = a.get(K_NAME).compareTo(b.get(K_NAME));
    if(n!=0) return n;
    List<Obj> as=a.get(K_ARGS), bs=b.get(K_ARGS);
    for(int i=0;i<as.size();i++){
      int c = termCompare(as.get(i), bs.get(i));
      if(c!=0) return c;
    }
    return 0;
  }

  static final class BagGroup {
    final List<Obj> freeVars;     // var objects (from the call term) in a stable order
    final List<Obj> freeVarVals;  // corresponding values (snapshots) for this group
    final Obj bagList;            // proper list of template snapshots (maybe sorted/unique)
    BagGroup(List<Obj> freeVars, List<Obj> freeVarVals, Obj bagList){
      this.freeVars=freeVars;
      this.freeVarVals=freeVarVals;
      this.bagList=bagList;
    }
  }

  static final class ExistsStrip {
    final Obj goal;
    final Set<Integer> existentialVids;
    ExistsStrip(Obj goal, Set<Integer> vids){ this.goal=goal; this.existentialVids=vids; }
  }

  static ExistsStrip stripExistentials(Obj g, Trail trail){
    Set<Integer> vids = new HashSet<>();
    Obj cur = deref(g, trail);
    while(cur.get(K_TAG)==Tag.COMP && "^".equals(cur.get(K_NAME)) && cur.get(K_ARITY)==2){
      Obj left = deref(cur.get(K_ARGS).get(0), trail);
      if(left.get(K_TAG)==Tag.VAR){
        vids.add(left.get(K_VID));
      } else if(isCons(left) || isNil(left)){
        for(Obj v : flattenProperList(left)){
          Obj vv = deref(v, trail);
          if(vv.get(K_TAG)==Tag.VAR) vids.add(vv.get(K_VID));
        }
      }
      cur = deref(cur.get(K_ARGS).get(1), trail);
    }
    return new ExistsStrip(cur, vids);
  }

  static void collectVarVidsSyntactic(Obj t, Set<Integer> vids){
    if(t==null) return;
    Tag tag = t.get(K_TAG);
    if(tag==Tag.VAR){
      vids.add(t.get(K_VID));
      return;
    }
    if(tag==Tag.COMP){
      for(Obj a : t.get(K_ARGS)) collectVarVidsSyntactic(a, vids);
    }
  }

  static void collectVarObjsByVid(Obj t, Map<Integer,Obj> vidToObj){
    if(t==null) return;
    Tag tag = t.get(K_TAG);
    if(tag==Tag.VAR){
      vidToObj.putIfAbsent(t.get(K_VID), t);
      return;
    }
    if(tag==Tag.COMP){
      for(Obj a : t.get(K_ARGS)) collectVarObjsByVid(a, vidToObj);
    }
  }

  static Obj listFromJavaList(List<Obj> items){
    Obj t = listNil();
    for(int i=items.size()-1;i>=0;i--) t = listCons(items.get(i), t);
    return t;
  }

  static Obj asGoal(Obj t, Trail trail){
    t = deref(t, trail);
    if(t.get(K_TAG)==Tag.ATOM) return Comp(t.get(K_NAME));
    if(t.get(K_TAG)==Tag.COMP) return t;
    if(t.get(K_TAG)==Tag.VAR) throw new RuntimeException("instantiation error (goal expected)");
    throw new RuntimeException("type error (goal expected): "+pp(t));
  }

  static BuiltinExec safeBuiltin(String pi, BuiltinExec inner){
    return (Trail tr) -> {
      try{
        return inner.next(tr);
      } catch(Exception e){
        builtinError(pi, e);
        if(BUILTIN_EXCEPTIONS_ARE_ERRORS){
          if(e instanceof RuntimeException) throw (RuntimeException)e;
          throw new RuntimeException(e);
        }
        return false;
      }
    };
  }

  static BuiltinExec detExec(BooleanSupplier run){
    return new BuiltinExec(){
      boolean done=false;
      @Override public boolean next(Trail tr){
        if(done) return false;
        done=true;
        return run.getAsBoolean();
      }
    };
  }

  static BuiltinExec startBuiltin(Obj engine, Obj goal, Trail trail){
    String n = goal.get(K_NAME);
    int a = goal.get(K_ARITY);
    List<Obj> as = goal.get(K_ARGS);
    String pi = pi(n, a);

    if(!BUILTINS_PI.contains(pi)) return null;
    BUILTIN_DISPATCH_ATTEMPTS++;

    // JSON / POJO / heap builtins (det)
    if("json_parse".equals(n) && a==2){
      return safeBuiltin(pi, detExec(() -> {
        String s = termToJavaString(as.get(0), trail);
        Obj term = Json.parse(s);
        return unify(as.get(1), term, trail);
      }));
    }
    if("json_stringify".equals(n) && a==2){
      return safeBuiltin(pi, detExec(() -> {
        String out = Json.stringify(deref(as.get(0), trail));
        return unify(as.get(1), Atom(out), trail);
      }));
    }
    if("from_json".equals(n) && a==3){
      return safeBuiltin(pi, detExec(() -> {
        String s = termToJavaString(as.get(0), trail);
        String cls = termToJavaString(as.get(1), trail);
        requireAllowedClassName(cls);
        try{
          Class<?> c = Class.forName(cls);
          Object o = mapJsonToPojo(Json.parse(s), c);
          return unify(as.get(2), refOf(o), trail);
        } catch(Exception e){
          throw new RuntimeException(e);
        }
      }));
    }
    if("to_json".equals(n) && a==2){
      return safeBuiltin(pi, detExec(() -> {
        Object o = objFromRef(as.get(0));
        try{
          String js = pojoToJson(o);
          return unify(as.get(1), Atom(js), trail);
        } catch(Exception e){
          throw new RuntimeException(e);
        }
      }));
    }
    if("release_ref".equals(n) && a==1){
      return safeBuiltin(pi, detExec(() -> {
        Obj r = deref(as.get(0), trail);
        if(!(r.get(K_TAG)==Tag.COMP && "ref".equals(r.get(K_NAME)) && r.get(K_ARITY)==1)){
          throw new RuntimeException("expected ref/1");
        }
        int id=(int)Long.parseLong(r.get(K_ARGS).get(0).get(K_NAME));
        HEAP.remove(id);
        return true;
      }));
    }
    if("clear_heap".equals(n) && a==0){
      return safeBuiltin(pi, detExec(() -> { HEAP.clear(); return true; }));
    }
    if("heap_size".equals(n) && a==1){
      return safeBuiltin(pi, detExec(() -> unify(as.get(0), Num(HEAP.size()), trail)));
    }

    // Arithmetic (det)
    if("is".equals(n) && a==2){
      return safeBuiltin(pi, detExec(() -> {
        NumVal v = evalArith(as.get(1), trail);
        return unify(as.get(0), numTerm(v), trail);
      }));
    }
    if("=:=".equals(n) && a==2){
      return safeBuiltin(pi, detExec(() -> {
        NumVal x = evalArith(as.get(0), trail);
        NumVal y = evalArith(as.get(1), trail);
        return (x.isFloat || y.isFloat) ? Double.compare(x.f, y.f)==0 : x.i==y.i;
      }));
    }
    if("=\\=".equals(n) && a==2){
      return safeBuiltin(pi, detExec(() -> {
        NumVal x = evalArith(as.get(0), trail);
        NumVal y = evalArith(as.get(1), trail);
        return (x.isFloat || y.isFloat) ? Double.compare(x.f, y.f)!=0 : x.i!=y.i;
      }));
    }
    if("<".equals(n) && a==2){
      return safeBuiltin(pi, detExec(() -> {
        NumVal x = evalArith(as.get(0), trail);
        NumVal y = evalArith(as.get(1), trail);
        return (x.isFloat || y.isFloat) ? x.f < y.f : x.i < y.i;
      }));
    }
    if("=<".equals(n) && a==2){
      return safeBuiltin(pi, detExec(() -> {
        NumVal x = evalArith(as.get(0), trail);
        NumVal y = evalArith(as.get(1), trail);
        return (x.isFloat || y.isFloat) ? x.f <= y.f : x.i <= y.i;
      }));
    }
    if(">".equals(n) && a==2){
      return safeBuiltin(pi, detExec(() -> {
        NumVal x = evalArith(as.get(0), trail);
        NumVal y = evalArith(as.get(1), trail);
        return (x.isFloat || y.isFloat) ? x.f > y.f : x.i > y.i;
      }));
    }
    if(">=".equals(n) && a==2){
      return safeBuiltin(pi, detExec(() -> {
        NumVal x = evalArith(as.get(0), trail);
        NumVal y = evalArith(as.get(1), trail);
        return (x.isFloat || y.isFloat) ? x.f >= y.f : x.i >= y.i;
      }));
    }

    // findall/3 (det)
    if("findall".equals(n) && a==3){
      return safeBuiltin(pi, detExec(() -> {
        Obj template = as.get(0);
        Obj g = asGoal(as.get(1), trail);

        Obj sandbox = Engine(engine.get(K_PREDICATES));
        Trail tr2 = sandbox.get(K_TRAIL);
        int mark0 = tr2.mark();

        List<Obj> items = new ArrayList<>();
        solveLoop(sandbox, g, false, (sol) -> {
          IdentityHashMap<Obj,Obj> memo = new IdentityHashMap<>();
          Set<Obj> resolving = Collections.newSetFromMap(new IdentityHashMap<>());
          items.add(snapshotTerm(template, memo, resolving));
        });

        tr2.unwindTo(mark0);
        Obj lst = listFromJavaList(items);
        return unify(as.get(2), lst, trail);
      }));
    }

    // bagof/3 and setof/3 (nondet if there are free vars)
    if(("bagof".equals(n) || "setof".equals(n)) && a==3){
      boolean wantSet = "setof".equals(n);
      return safeBuiltin(pi, new BuiltinExec(){
        boolean inited=false;
        List<BagGroup> groups;
        int idx=0;

        @Override public boolean next(Trail tr){
          if(!inited){
            inited=true;
            groups = computeBagGroups(engine, as.get(0), as.get(1), wantSet, tr);
            idx=0;
          }
          while(idx < groups.size()){
            BagGroup g = groups.get(idx++);
            int mark = tr.mark();
            boolean ok = unify(as.get(2), g.bagList, tr);
            if(ok){
              for(int i=0;i<g.freeVars.size();i++){
                ok = unify(g.freeVars.get(i), g.freeVarVals.get(i), tr);
                if(!ok) break;
              }
            }
            if(ok) return true;
            tr.unwindTo(mark);
          }
          return false;
        }
      });
    }

    // assertz/1 (det)
    if("assertz".equals(n) && a==1){
      return safeBuiltin(pi, detExec(() -> {
        // Capture current bindings inside the asserted term.
        // Without this, assertz(p(X)) after X=1 would store p(_X) rather than p(1),
        // and higher-level systems (e.g. OO method tables) become unreliable.
        Obj clauseTerm = deref(as.get(0), trail);
        clauseTerm = snapshotTerm(
            clauseTerm,
            new IdentityHashMap<>(),
            Collections.newSetFromMap(new IdentityHashMap<>())
        );
        Obj head;
        List<Obj> bodyGoals = List.of();
        if(clauseTerm.get(K_TAG)==Tag.COMP && ":-".equals(clauseTerm.get(K_NAME)) && clauseTerm.get(K_ARITY)==2){
          head = ensureCallableHead(clauseTerm.get(K_ARGS).get(0), trail);
          bodyGoals = flattenConjunction(clauseTerm.get(K_ARGS).get(1), trail);
        } else {
          head = ensureCallableHead(clauseTerm, trail);
          bodyGoals = List.of();
        }
        Obj clause = Clause(head, bodyGoals.toArray(new Obj[0]));
        String ppi = pi(head.get(K_NAME), head.get(K_ARITY));
        Obj pred = engine.get(K_PREDICATES).get(ppi);
        if(pred==null){
          pred = Predicate();
          engine.get(K_PREDICATES).put(ppi, pred);
        }
        pred.get(K_CLAUSES).add(clause);
        rebuildIndex(pred);
        return true;
      }));
    }

    // retract/1 (nondet, destructive)
    if("retract".equals(n) && a==1){
      return safeBuiltin(pi, new BuiltinExec(){
        boolean inited=false;
        String ppi;
        int scan=0;
        Obj pred;
        Obj patternHead;
        Obj patternBodyOrTrue;
        boolean hasBody;

        @Override public boolean next(Trail tr){
          if(!inited){
            inited=true;
            // Freeze the retract pattern so that any *current* bindings are reflected
            // deeply, while keeping unbound vars as the original objects so retract/1
            // can bind them and propagate the binding back to the caller.
            Obj pat = freezePatternTerm(as.get(0), tr);
            hasBody = (pat.get(K_TAG)==Tag.COMP && ":-".equals(pat.get(K_NAME)) && pat.get(K_ARITY)==2);
            if(hasBody){
              patternHead = ensureCallableHead(pat.get(K_ARGS).get(0), tr);
              patternBodyOrTrue = pat.get(K_ARGS).get(1);
            } else {
              patternHead = ensureCallableHead(pat, tr);
              patternBodyOrTrue = Atom("true");
            }
            ppi = pi(patternHead.get(K_NAME), patternHead.get(K_ARITY));
            pred = engine.get(K_PREDICATES).get(ppi);
            if(pred==null) return false;
            scan=0;
          }

          List<Obj> clauses = pred.get(K_CLAUSES);
          while(scan < clauses.size()){
            Obj orig = clauses.get(scan);
            Obj fresh = renameClause(orig, new IdentityHashMap<>());
            int mark = tr.mark();

            boolean ok = unify(patternHead, fresh.get(K_HEAD), tr);
            if(ok && hasBody){
              Obj bodyConj = conjunctionFromList(fresh.get(K_BODY));
              ok = unify(patternBodyOrTrue, bodyConj, tr);
            }
            if(ok){
              // remove the ORIGINAL clause (destructive, not backtrackable)
              clauses.remove(scan);
              rebuildIndex(pred);
              return true;
            }
            tr.unwindTo(mark);
            scan++;
          }
          return false;
        }
      });
    }

    return safeBuiltin(pi, detExec(() -> false));
  }

  static List<BagGroup> computeBagGroups(Obj engine, Obj template, Obj goalWithExistentials, boolean wantSet, Trail outerTrail){
    Trail t = outerTrail;
    ExistsStrip es = stripExistentials(goalWithExistentials, t);
    Obj goal = asGoal(es.goal, t);

    // Determine free vars: vars in goal, excluding vars in template and existential vars
    Set<Integer> goalVids = new HashSet<>();
    collectVarVidsSyntactic(goal, goalVids);

    Set<Integer> tmplVids = new HashSet<>();
    collectVarVidsSyntactic(template, tmplVids);

    goalVids.removeAll(tmplVids);
    goalVids.removeAll(es.existentialVids);

    Map<Integer,Obj> vidToObj = new LinkedHashMap<>();
    collectVarObjsByVid(goal, vidToObj);

    // stable order
    List<Integer> freeVids = new ArrayList<>();
    for(int vid : vidToObj.keySet()){
      if(goalVids.contains(vid)) freeVids.add(vid);
    }
    Collections.sort(freeVids);

    List<Obj> freeVars = new ArrayList<>();
    for(int vid : freeVids) freeVars.add(vidToObj.get(vid));

    Obj sandbox = Engine(engine.get(K_PREDICATES));
    Trail tr2 = sandbox.get(K_TRAIL);
    int mark0 = tr2.mark();

    // group by free-var key
    LinkedHashMap<TermKey, List<Obj>> grouped = new LinkedHashMap<>();
    LinkedHashMap<TermKey, List<Obj>> keyToFreeVals = new LinkedHashMap<>();

    solveLoop(sandbox, goal, false, (sol) -> {
      IdentityHashMap<Obj,Obj> memo = new IdentityHashMap<>();
      Set<Obj> resolving = Collections.newSetFromMap(new IdentityHashMap<>());

      // key is list of snapshots for the free vars
      List<Obj> keyParts = new ArrayList<>();
      for(Obj fv : freeVars){
        keyParts.add(snapshotTerm(fv, memo, resolving));
      }
      Obj keyList = listFromJavaList(keyParts);
      TermKey key = new TermKey(keyList);

      Obj tpl = snapshotTerm(template, memo, resolving);
      grouped.computeIfAbsent(key, kk -> new ArrayList<>()).add(tpl);
      keyToFreeVals.putIfAbsent(key, keyParts);
    });

    tr2.unwindTo(mark0);

    if(grouped.isEmpty()){
      return List.of(); // bagof/setof fails
    }

    List<BagGroup> out = new ArrayList<>();
    for(Map.Entry<TermKey, List<Obj>> e : grouped.entrySet()){
      List<Obj> items = e.getValue();

      if(wantSet){
        items.sort(MiniPrologProto::termCompare);
        // unique
        ArrayList<Obj> uniq = new ArrayList<>();
        for(Obj it : items){
          if(uniq.isEmpty() || termCompare(uniq.get(uniq.size()-1), it)!=0){
            uniq.add(it);
          }
        }
        items = uniq;
      }

      Obj bag = listFromJavaList(items);
      List<Obj> freeVals = keyToFreeVals.get(e.getKey());
      out.add(new BagGroup(freeVars, freeVals, bag));
    }

    // For setof/3, groups should be ordered by key (standard order); bagof keeps first-seen order.
    if(wantSet && out.size()>1){
      out.sort((g1, g2) -> {
        Obj k1 = listFromJavaList(g1.freeVarVals);
        Obj k2 = listFromJavaList(g2.freeVarVals);
        return termCompare(k1, k2);
      });
    }

    return out;
  }

  static boolean proveOnceSandbox(Obj outerEngine, Obj goal){
    Obj sandbox = Engine(outerEngine.get(K_PREDICATES));
    Trail tr = sandbox.get(K_TRAIL);
    int mark0 = tr.mark();
    boolean ok = solveOnce(sandbox, asGoal(goal, tr));
    tr.unwindTo(mark0);
    return ok;
  }

  /* =========================
   * JSON term -> POJO mapping (Stage 6)
   * ========================= */
  static Object mapJsonToPojo(Obj jsonTerm, Class<?> cls) throws Exception {
    Object instance = cls.getConstructor().newInstance();
    if(!(jsonTerm.get(K_TAG)==Tag.COMP && "obj".equals(jsonTerm.get(K_NAME)))){
      throw new RuntimeException("expected JSON object");
    }

    Map<String,Obj> map=new HashMap<>();
    for(Obj kv : Json.flattenList(jsonTerm.get(K_ARGS).get(0))){
      Obj keyTerm = kv.get(K_ARGS).get(0);
      String k = termToJavaString(keyTerm, new Trail()); // accepts Atom or str/1
      map.put(k, kv.get(K_ARGS).get(1));
    }

    for(java.lang.reflect.Field f : cls.getFields()){
      int mod = f.getModifiers();
      if(java.lang.reflect.Modifier.isStatic(mod) || java.lang.reflect.Modifier.isFinal(mod)) continue;

      Obj v = map.get(f.getName());
      if(v==null) continue;

      Object jv;
      try{
        jv = convertTermToJava(v, f.getType());
      } catch(Exception ex){
        throw new RuntimeException("field "+f.getName()+": "+ex.getMessage(), ex);
      }
      f.set(instance, jv);
    }
    return instance;
  }

  static Object convertTermToJava(Obj t, Class<?> target) throws Exception {
    t = deref(t, new Trail());

    // JSON null maps to Java null for reference types.
    if(t.get(K_TAG)==Tag.ATOM && "null".equals(t.get(K_NAME))){
      if(target.isPrimitive()){
        throw new RuntimeException("null cannot be assigned to primitive "+target.getName());
      }
      return null;
    }

    if(target==String.class){
      if(t.get(K_TAG)==Tag.ATOM) return t.get(K_NAME);
      if(t.get(K_TAG)==Tag.COMP && "str".equals(t.get(K_NAME)) && t.get(K_ARITY)==1){
        return deref(t.get(K_ARGS).get(0), new Trail()).get(K_NAME);
      }
      throw new RuntimeException("need string");
    }

    if(target==int.class||target==Integer.class){
      if(t.get(K_TAG)==Tag.NUM) return (int)Long.parseLong(t.get(K_NAME));
      if(t.get(K_TAG)==Tag.COMP && "double".equals(t.get(K_NAME))) return (int)Double.parseDouble(t.get(K_ARGS).get(0).get(K_NAME));
    }
    if(target==long.class||target==Long.class){
      if(t.get(K_TAG)==Tag.NUM) return Long.parseLong(t.get(K_NAME));
    }
    if(target==double.class||target==Double.class){
      if(t.get(K_TAG)==Tag.NUM) return (double)Long.parseLong(t.get(K_NAME));
      if(t.get(K_TAG)==Tag.COMP && "double".equals(t.get(K_NAME))) return Double.parseDouble(t.get(K_ARGS).get(0).get(K_NAME));
    }
    if(target==boolean.class||target==Boolean.class){
      if(t.get(K_TAG)==Tag.ATOM){
        String s=t.get(K_NAME);
        if("true".equals(s)) return true;
        if("false".equals(s)) return false;
      }
    }

    if(target.isArray()){
      if(!(t.get(K_TAG)==Tag.COMP && "arr".equals(t.get(K_NAME)))) throw new RuntimeException("need arr");
      Class<?> et = target.getComponentType();
      List<Obj> els = Json.flattenList(t.get(K_ARGS).get(0));
      Object arr = java.lang.reflect.Array.newInstance(et, els.size());
      for(int i=0;i<els.size();i++){
        java.lang.reflect.Array.set(arr, i, convertTermToJava(els.get(i), et));
      }
      return arr;
    }

    if(t.get(K_TAG)==Tag.COMP && "obj".equals(t.get(K_NAME))){
      return mapJsonToPojo(t, target);
    }

    throw new RuntimeException("cannot map to "+target.getName());
  }

  static String pojoToJson(Object o) throws Exception {
    if(o==null) return "null";
    Class<?> c=o.getClass();
    if(c==String.class) return "\"" + Json.escape((String)o) + "\"";
    if(Number.class.isAssignableFrom(c)||c==Integer.class||c==Long.class||c==Double.class||c==Float.class) return String.valueOf(o);
    if(c==Boolean.class || c==boolean.class) return ((Boolean)o)? "true":"false";

    if(c.isArray()){
      int n=java.lang.reflect.Array.getLength(o);
      StringBuilder sb=new StringBuilder();
      sb.append('[');
      for(int i=0;i<n;i++){
        if(i>0) sb.append(',');
        sb.append(pojoToJson(java.lang.reflect.Array.get(o,i)));
      }
      sb.append(']');
      return sb.toString();
    }

    StringBuilder sb=new StringBuilder();
    sb.append('{');
    boolean first=true;
    for(java.lang.reflect.Field f: c.getFields()){
      int mod = f.getModifiers();
      if(java.lang.reflect.Modifier.isStatic(mod)) continue;
      Object v=f.get(o);
      if(!first) sb.append(',');
      first=false;
      sb.append('"').append(Json.escape(f.getName())).append('"').append(':').append(pojoToJson(v));
    }
    sb.append('}');
    return sb.toString();
  }

  /* =========================
   * Self-test harness (Stage 0+)
   * ========================= */
  static void resetGlobals(){
    VAR_COUNTER = 0;
    HEAP.clear();
    NEXT_ID = 1;
    BUILTIN_DISPATCH_ATTEMPTS = 0;
    CLAUSE_ATTEMPTS = 0;
  }

  static Obj buildProgramWithSample(){
    Obj prog = Program();
    definePred(prog, "true", 0, Predicate(Clause(Comp("true"))));
    definePred(prog, "fail", 0, Predicate(/* no clauses */));
    definePred(prog, "=", 2, Predicate(/* marker only; handled specially */));
    loadSampleProgram(prog);
    return prog;
  }

  /** Build the sample program plus OO + column DB + planner + demo-domain predicates. */
  static Obj buildProgramWithPrototypeStack(){
    Obj prog = buildProgramWithSample();
    // Load add-ons (in order) via reflection, so MiniPrologProto can compile
    // independently and we can stage compilation.
    loadAddon("com.mycompany.prolog.OopPrologLib", prog);
    loadAddon("com.mycompany.prolog.ColumnDbLib", prog);
    loadAddon("com.mycompany.prolog.PlannerStrategiesLib", prog);
    loadAddon("com.mycompany.prolog.HtnDemoLib", prog);
    return prog;
  }

  static void loadAddon(String className, Obj prog){
    try{
      Class<?> cls = Class.forName(className);
      var m = cls.getDeclaredMethod("load", Obj.class);
      m.invoke(null, prog);
    }catch(Exception e){
      throw new RuntimeException("Failed to load addon: "+className, e);
    }
  }

  static void check(boolean cond, String msg){
    if(!cond) throw new AssertionError(msg);
  }

  static void selfTest(){
    System.out.println("SELFTEST: begin");

    // Stage 0: baseline correctness
    resetGlobals();
    Obj prog = buildProgramWithSample();

    Obj X = Var();
    Obj goal = Comp("append", list(Num(1), Num(2)), list(Num(3)), X);
    List<Map<Integer,Obj>> sols = query(prog, goal);
    check(sols.size()==1, "append should yield 1 solution, got "+sols.size());
    Obj xVal = sols.get(0).get(X.get(K_VID));
    check(xVal!=null, "solution missing X");
    check(isProperList(xVal), "append result should be a proper list");
    List<Obj> items = flattenProperList(xVal);
    check(items.size()==3, "append result length should be 3");
    check("1".equals(deref(items.get(0), new Trail()).get(K_NAME)), "append[0] expected 1");
    check("2".equals(deref(items.get(1), new Trail()).get(K_NAME)), "append[1] expected 2");
    check("3".equals(deref(items.get(2), new Trail()).get(K_NAME)), "append[2] expected 3");

    Obj V = Var();
    Obj bad = Comp("=", V, Comp("f", V));
    List<Map<Integer,Obj>> occ = query(prog, bad);
    check(occ.isEmpty(), "occurs-check: X=f(X) should have 0 solutions");

    Obj T = Var();
    List<Map<Integer,Obj>> jp = query(prog, Comp("json_parse", Atom("[1,true,null,\"x\"]"), T));
    check(jp.size()==1, "json_parse should succeed");
    Obj parsed = jp.get(0).get(T.get(K_VID));
    Obj S = Var();
    List<Map<Integer,Obj>> js = query(prog, Comp("json_stringify", parsed, S));
    check(js.size()==1, "json_stringify should succeed");
    String jsonOut = js.get(0).get(S.get(K_VID)).get(K_NAME);
    check(jsonOut.contains("\"x\""), "json_stringify should contain string x");

    Obj R = Var();
    String personJson = "{\"name\":\"Ada\",\"age\":36,\"address\":{\"city\":\"Athens\",\"country\":\"GR\"},\"tags\":[\"engineer\",\"fp\"]}";
    List<Map<Integer,Obj>> s1 = query(prog, Comp("from_json", Atom(personJson), Atom("com.mycompany.prolog.Person"), R));
    check(!s1.isEmpty(), "from_json should succeed");
    Obj ref = s1.get(0).get(R.get(K_VID));
    check(ref!=null, "from_json should bind ref var");
    check(HEAP.size()==1, "heap should contain 1 object after from_json");
    Obj J2 = Var();
    List<Map<Integer,Obj>> s2 = query(prog, Comp("to_json", ref, J2));
    check(!s2.isEmpty(), "to_json should succeed");
    String rt = s2.get(0).get(J2.get(K_VID)).get(K_NAME);
    check(rt.contains("\"name\"") && rt.contains("Ada"), "roundtrip JSON should include name Ada");

    // heap_size + release_ref
    Obj N = Var();
    List<Map<Integer,Obj>> hs = query(prog, Comp("heap_size", N));
    check(hs.size()==1, "heap_size should succeed");
    check("1".equals(hs.get(0).get(N.get(K_VID)).get(K_NAME)), "heap_size should be 1");
    List<Map<Integer,Obj>> rel = query(prog, Comp("release_ref", ref));
    check(rel.size()==1, "release_ref should succeed");
    check(HEAP.isEmpty(), "heap should be empty after release_ref");

    System.out.println("STAGE0 ok");

    // Stage 1: pretty printer
    resetGlobals();
    check("[1,2,3]".equals(pp(list(Num(1), Num(2), Num(3)))), "pp list formatting failed");
    check("[1|x]".equals(pp(listCons(Num(1), Atom("x")))), "pp improper list formatting failed");
    check("\"true\"".equals(pp(Json.parse("\"true\""))), "pp str formatting failed");
    check("true".equals(pp(Json.parse("true"))), "pp boolean formatting failed");
    System.out.println("STAGE1 ok");

    // Stage 2: no static program leakage (run two different programs)
    resetGlobals();
    Obj prog1 = buildProgramWithSample();
    Obj prog2 = Program(); // empty predicates
    definePred(prog2, "true", 0, Predicate(Clause(Comp("true"))));

    // prog1 should work
    Obj X1 = Var();
    check(query(prog1, Comp("append", list(Num(1)), list(Num(2)), X1)).size()==1, "prog1 append failed");

    // prog2 should throw unknown predicate
    boolean threw=false;
    try{
      Obj X2 = Var();
      query(prog2, Comp("append", list(Num(1)), list(Num(2)), X2));
    } catch(IllegalStateException e){
      threw = e.getMessage().contains("Unknown predicate");
    }
    check(threw, "prog2 should throw Unknown predicate");
    System.out.println("STAGE2 ok");

    // Stage 3: snapshot sharing across query vars
    resetGlobals();
    Obj progShare = Program();
    definePred(progShare, "true", 0, Predicate(Clause(Comp("true"))));
    definePred(progShare, "fail", 0, Predicate());
    definePred(progShare, "=", 2, Predicate());

    Obj Xs = Var(); Obj Ys = Var();
    Obj head = Comp("share", Xs, Ys);
    Obj body1 = Comp("=", Xs, Ys);
    Obj body2 = Comp("=", Ys, list(Num(1)));
    definePred(progShare, "share", 2, Predicate(Clause(head, body1, body2)));

    Obj QX = Var(); Obj QY = Var();
    List<Map<Integer,Obj>> sh = query(progShare, Comp("share", QX, QY));
    check(sh.size()==1, "share/2 should yield 1 solution");
    Obj sx = sh.get(0).get(QX.get(K_VID));
    Obj sy = sh.get(0).get(QY.get(K_VID));
    check(sx!=null && sy!=null, "share solution missing vars");
    check(sx==sy, "snapshot sharing not preserved (expected same object)");
    check("[1]".equals(pp(sx)), "share value expected [1]");
    System.out.println("STAGE3 ok");

    // Stage 4: builtin dispatch only for known builtins
    resetGlobals();
    Obj progB = buildProgramWithSample();
    Obj BX = Var();
    query(progB, Comp("append", list(Num(1)), list(Num(2)), BX));
    check(BUILTIN_DISPATCH_ATTEMPTS==0, "append should not trigger extended builtin dispatch");
    Obj BT = Var();
    query(progB, Comp("json_parse", Atom("[1]"), BT));
    check(BUILTIN_DISPATCH_ATTEMPTS==1, "json_parse should trigger extended builtin dispatch once");
    System.out.println("STAGE4 ok");

    // Stage 5: JSON strict numbers + control escaping
    resetGlobals();
    // leading zero rejected
    boolean badNum=false;
    try{ Json.parse("01"); } catch(RuntimeException e){ badNum = e.getMessage().toLowerCase().contains("leading zero") || e.getMessage().toLowerCase().contains("bad"); }
    check(badNum, "Json.parse(\"01\") should reject leading zero");

    // exponent requires digits
    boolean badExp=false;
    try{ Json.parse("1e"); } catch(RuntimeException e){ badExp = true; }
    check(badExp, "Json.parse(\"1e\") should reject");

    // escape control char in stringify
    String ctrl = "" + (char)1;
    String out = Json.stringify(Json.Str(ctrl));
    String expectedEsc = "\\" + "u0001";
    check(out.contains(expectedEsc), "stringify should contain "+expectedEsc+" for control char, got: "+out);
    System.out.println("STAGE5 ok");

    // Stage 6: POJO mapping robustness (keys as str, better errors)
    resetGlobals();
    // Keys as str/1 should be accepted by mapJsonToPojo
    Obj keyName = Json.Str("name");
    Obj keyAge = Json.Str("age");
    Obj valName = Json.Str("Ada");
    Obj valAge = Num(36);
    Obj kv1 = Comp("kv", keyName, valName);
    Obj kv2 = Comp("kv", keyAge, valAge);
    Obj termObj = Comp("obj", list(kv1, kv2));
    try{
      Object p = mapJsonToPojo(termObj, com.mycompany.prolog.Person.class);
      check(((com.mycompany.prolog.Person)p).name.equals("Ada"), "mapJsonToPojo should set name");
      check(((com.mycompany.prolog.Person)p).age==36, "mapJsonToPojo should set age");
    } catch(Exception e){
      throw new AssertionError("mapJsonToPojo with str keys should succeed, got: "+e.getMessage());
    }

    // null into primitive should error with field name
    Obj progNull = buildProgramWithSample();
    Obj RR = Var();
    boolean gotField=false;
    boolean oldPrint = PRINT_BUILTIN_ERRORS;
    try{
      // This call should throw (null into primitive field). Silence built-in logging for this expected failure.
      PRINT_BUILTIN_ERRORS = false;
      query(progNull, Comp("from_json", Atom("{\"name\":\"Ada\",\"age\":null}"), Atom("com.mycompany.prolog.Person"), RR));
    } catch(RuntimeException e){
      gotField = e.getMessage().contains("field age");
    } finally {
      PRINT_BUILTIN_ERRORS = oldPrint;
    }
    check(gotField, "null into primitive should mention field age");
    System.out.println("STAGE6 ok");

    // Stage 7: control, arithmetic, aggregation, dynamic DB, indexing
    resetGlobals();

    Obj prog7 = Program();
    definePred(prog7, "true", 0, Predicate(Clause(Comp("true"))));
    definePred(prog7, "fail", 0, Predicate(/* no clauses */));
    definePred(prog7, "=", 2, Predicate(/* marker only */));

    // p(X) :- (X=1 ; X=2), !.
    Obj Xcl = Var();
    definePred(prog7, "p", 1, Predicate(
        Clause(Comp("p", Xcl),
            Comp(",", Comp(";", Comp("=", Xcl, Num(1)), Comp("=", Xcl, Num(2))),
                     Comp("!"))
        )
    ));

    // member/2
    Obj MX1 = Var(); Obj MT1 = Var();
    Obj MX2 = Var(); Obj M_2 = Var(); Obj MT2 = Var();
    definePred(prog7, "member", 2, Predicate(
        Clause(Comp("member", MX1, listCons(MX1, MT1))),
        Clause(Comp("member", MX2, listCons(M_2, MT2)),
            Comp("member", MX2, MT2))
    ));

    // Control: cut prunes disjunction in p/1
    Obj Rv = Var();
    List<Map<Integer,Obj>> s7a = query(prog7, Comp("p", Rv));
    check(s7a.size()==1, "p/1 with cut should yield 1 solution");
    check("1".equals(s7a.get(0).get(Rv.get(K_VID)).get(K_NAME)), "p(R) should bind R=1");

    // If-then-else: (true -> X=1 ; X=2) and (fail -> X=1 ; X=2)
    Obj Xv = Var();
    Obj iteGoal = Comp(";", Comp("->", Comp("true"), Comp("=", Xv, Num(1))), Comp("=", Xv, Num(2)));
    List<Map<Integer,Obj>> s7b = query(prog7, iteGoal);
    check(s7b.size()==1, "if-then-else true branch");
    check("1".equals(s7b.get(0).get(Xv.get(K_VID)).get(K_NAME)), "ITE should bind X=1");

    Obj Xv2 = Var();
    Obj iteGoal2 = Comp(";", Comp("->", Comp("fail"), Comp("=", Xv2, Num(1))), Comp("=", Xv2, Num(2)));
    List<Map<Integer,Obj>> s7c = query(prog7, iteGoal2);
    check(s7c.size()==1, "if-then-else else branch");
    check("2".equals(s7c.get(0).get(Xv2.get(K_VID)).get(K_NAME)), "ITE should bind X=2");

    // Negation as failure: \+(true) fails, \+(fail) succeeds
    check(query(prog7, Comp("\\+", Comp("true"))).isEmpty(), "\\+(true) should fail");
    check(query(prog7, Comp("\\+", Comp("fail"))).size()==1, "\\+(fail) should succeed");

    // once/1: once((X=1 ; X=2)) yields only X=1
    Obj Xv3 = Var();
    Obj onceGoal = Comp("once", Comp(";", Comp("=", Xv3, Num(1)), Comp("=", Xv3, Num(2))));
    List<Map<Integer,Obj>> s7e = query(prog7, onceGoal);
    check(s7e.size()==1, "once/1 should yield 1 solution");

    // Arithmetic: X is 1+2, X < 4
    Obj Xv4 = Var();
    Obj arGoal = Comp(",", Comp("is", Xv4, Comp("+", Num(1), Num(2))), Comp("<", Xv4, Num(4)));
    List<Map<Integer,Obj>> s7f = query(prog7, arGoal);
    check(s7f.size()==1, "arithmetic is/2 and </2");
    check("3".equals(s7f.get(0).get(Xv4.get(K_VID)).get(K_NAME)), "X should be 3");

    // findall/3: findall(X, (X=1;X=2), L) -> L=[1,2]
    Obj Xv5 = Var(); Obj Lv = Var();
    Obj faGoal = Comp("findall", Xv5,
        Comp(";", Comp("=", Xv5, Num(1)), Comp("=", Xv5, Num(2))),
        Lv
    );
    List<Map<Integer,Obj>> s7g = query(prog7, faGoal);
    check(s7g.size()==1, "findall/3 should succeed once");
    Obj lTerm = s7g.get(0).get(Lv.get(K_VID));
    check(isProperList(lTerm) && flattenProperList(lTerm).size()==2, "findall L should be [1,2]");

    // bagof/3 with free var Y: bagof(X, (member(X,[a,b]), member(Y,[1,2])), Bag)
    Obj Xv6 = Var(); Obj Yv = Var(); Obj Bagv = Var();
    Obj bagGoal = Comp("bagof",
        Xv6,
        Comp(",", Comp("member", Xv6, list(Atom("a"), Atom("b"))),
                 Comp("member", Yv, list(Num(1), Num(2)))),
        Bagv
    );
    List<Map<Integer,Obj>> s7h = query(prog7, bagGoal);
    check(s7h.size()==2, "bagof/3 should produce 2 groups (Y=1,Y=2)");

    // setof/3: setof(X, (X=2;X=1;X=2), S) -> [1,2]
    Obj Xv7 = Var(); Obj Sv = Var();
    Obj setGoal = Comp("setof", Xv7,
        Comp(";", Comp("=", Xv7, Num(2)),
            Comp(";", Comp("=", Xv7, Num(1)), Comp("=", Xv7, Num(2)))),
        Sv
    );
    List<Map<Integer,Obj>> s7i = query(prog7, setGoal);
    check(s7i.size()==1, "setof/3 should succeed once");
    Obj sTerm = s7i.get(0).get(Sv.get(K_VID));
    check(isProperList(sTerm) && "[1,2]".equals(pp(sTerm)), "setof should yield [1,2]");

    // Dynamic DB: assertz/retract
    Obj dynProg = Program();
    definePred(dynProg, "true", 0, Predicate(Clause(Comp("true"))));
    definePred(dynProg, "fail", 0, Predicate());
    definePred(dynProg, "=", 2, Predicate());
    query(dynProg, Comp("assertz", Comp("p", Num(1))));
    query(dynProg, Comp("assertz", Comp("p", Num(2))));
    check(query(dynProg, Comp("p", Var())).size()==2, "assertz should add facts");
    check(query(dynProg, Comp("retract", Comp("p", Num(1)))).size()==1, "retract should succeed");
    check(query(dynProg, Comp("p", Var())).size()==1, "after retract(p(1)) only p(2) remains");

    // Indexing sanity: q(1..100). Query q(100) should attempt very few clauses.
    Obj idxProg = Program();
    definePred(idxProg, "true", 0, Predicate(Clause(Comp("true"))));
    definePred(idxProg, "fail", 0, Predicate());
    definePred(idxProg, "=", 2, Predicate());
    Obj qPred = Predicate();
    for(int i=1;i<=100;i++){
      qPred.get(K_CLAUSES).add(Clause(Comp("q", Num(i))));
    }
    rebuildIndex(qPred);
    idxProg.get(K_PREDICATES).put(pi("q",1), qPred);

    int before = CLAUSE_ATTEMPTS;
    List<Map<Integer,Obj>> idxRes = query(idxProg, Comp("q", Num(100)));
    int attempts = CLAUSE_ATTEMPTS - before;
    check(idxRes.size()==1, "q(100) should succeed");
    check(attempts<=5, "indexing should reduce clause attempts (attempts="+attempts+")");

    System.out.println("STAGE7 ok");

    System.out.println("SELFTEST: all ok");
  }

  /* =========================
   * Demo main
   * ========================= */
  public static void main(String[] args){
    if(args!=null && args.length>0 && "--selftest".equals(args[0])){
      selfTest();
      return;
    }

    // Build program
    Obj prog = buildProgramWithSample();

    // --- Demo 1: append([1,2],[3], X) ---
    Obj X = Var();
    Obj goal = Comp("append", list(Num(1), Num(2)), list(Num(3)), X);
    List<Map<Integer,Obj>> sols = query(prog, goal);
    System.out.println("append/3 -> solutions: "+sols.size());
    for(Map<Integer,Obj> s: sols){
      for(Map.Entry<Integer,Obj> e : s.entrySet()){
        System.out.println("  _"+e.getKey()+" = "+ pp(e.getValue()));
      }
    }

    // --- Demo 2: JSON -> POJO -> JSON round-trip ---
    Obj R = Var();
    Obj goal1 = Comp("from_json",
        Atom("{\"name\":\"Ada\",\"age\":36,\"address\":{\"city\":\"Athens\",\"country\":\"GR\"},\"tags\":[\"engineer\",\"fp\"]}"),
        Atom("com.mycompany.prolog.Person"),
        R);
    List<Map<Integer,Obj>> s1 = query(prog, goal1);
    if(!s1.isEmpty()){
      Obj ref = s1.get(0).get(R.get(K_VID));
      Obj S = Var();
      Obj goal2 = Comp("to_json", ref, S);
      List<Map<Integer,Obj>> s2 = query(prog, goal2);
      if(!s2.isEmpty()){
        System.out.println("Round-trip JSON: "+ s2.get(0).get(S.get(K_VID)).get(K_NAME));
      }
    }

    // --- Demo 3: JSON parse/stringify at term level ---
    Obj T = Var();
    Obj goal3 = Comp("json_parse", Atom("[{\"x\":1}, {\"x\":2.5}, true, null, \"true\"]"), T);
    List<Map<Integer,Obj>> s3 = query(prog, goal3);
    if(!s3.isEmpty()){
      Obj term = s3.get(0).get(T.get(K_VID));
      System.out.println("Parsed term: "+pp(term));
      Obj S2 = Var();
      Obj goal4 = Comp("json_stringify", term, S2);
      List<Map<Integer,Obj>> s4 = query(prog, goal4);
      if(!s4.isEmpty()){
        System.out.println("Stringify again: "+ s4.get(0).get(S2.get(K_VID)).get(K_NAME));
      }
    }
  }
}
