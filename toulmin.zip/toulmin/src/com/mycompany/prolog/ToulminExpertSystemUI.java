package com.mycompany.prolog;

import static com.mycompany.prolog.MiniPrologProto.*;

import javax.swing.*;
import javax.swing.border.*;
import javax.swing.table.*;
import javax.swing.tree.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.util.List;

/**
 * Toulmin Argumentation Expert System - Swing UI
 */
public class ToulminExpertSystemUI extends JFrame {
    
    private Obj program;
    private JTabbedPane mainTabs;
    private JTextArea consoleOutput;
    private JTextArea queryInput;
    
    private DefaultTableModel factsTableModel;
    private DefaultTableModel rulesTableModel;
    private JTextField claimField;
    private JTextArea dataArea;
    private JTextField warrantField;
    private JTextArea backingArea;
    private JComboBox<String> qualifierCombo;
    private JTextArea rebuttalArea;
    private DefaultTableModel argumentsTableModel;
    
    private JTextArea forwardOutput;
    private JTextArea backwardInput;
    private JTextArea backwardOutput;
    
    private DefaultTableModel conflictsTableModel;
    private JTree argumentTree;
    private DefaultMutableTreeNode treeRoot;
    
    private JTextArea plannerOutput;
    
    private static final Color PRIMARY = new Color(41, 128, 185);
    private static final Color SECONDARY = new Color(52, 73, 94);
    private static final Color ACCENT = new Color(46, 204, 113);
    private static final Color BG = new Color(236, 240, 241);
    
    public ToulminExpertSystemUI() {
        super("Toulmin Argumentation Expert System");
        initializeProlog();
        initializeUI();
        loadSampleKnowledge();
    }
    
    private void initializeProlog() {
        program = Program();
        OopPrologLib.load(program);
        ColumnDbLib.load(program);
        PlannerStrategiesLib.load(program);
        HtnDemoLib.load(program);
        ToulminArgumentLib.load(program);
        
        definePred(program, "true", 0, Predicate(Clause(Comp("true"))));
        definePred(program, "fail", 0, Predicate());
        definePred(program, "=", 2, Predicate());
        
        Obj L = Var(), L2 = Var(), H = Var(), T = Var(), R = Var();
        definePred(program, "append", 3, Predicate(
            Clause(Comp("append", listNil(), L, L)),
            Clause(Comp("append", listCons(H, T), L2, listCons(H, R)), Comp("append", T, L2, R))
        ));
        
        query(program, Comp("toulmin_init"));
        log("Prolog engine initialized.");
    }
    
    private void initializeUI() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1400, 900);
        setLocationRelativeTo(null);
        
        try { UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName()); } catch (Exception e) {}
        
        setLayout(new BorderLayout());
        getContentPane().setBackground(BG);
        
        add(createHeader(), BorderLayout.NORTH);
        
        mainTabs = new JTabbedPane();
        mainTabs.setFont(new Font("SansSerif", Font.PLAIN, 14));
        mainTabs.addTab("Knowledge Base", createKnowledgeBasePanel());
        mainTabs.addTab("Argument Builder", createArgumentBuilderPanel());
        mainTabs.addTab("Forward Reasoning", createForwardReasoningPanel());
        mainTabs.addTab("Backward Reasoning", createBackwardReasoningPanel());
        mainTabs.addTab("Conflict Analysis", createConflictAnalysisPanel());
        mainTabs.addTab("HTN Planner", createPlannerPanel());
        mainTabs.addTab("Prolog Console", createConsolePanel());
        add(mainTabs, BorderLayout.CENTER);
        
        JPanel statusBar = new JPanel(new BorderLayout());
        statusBar.setBackground(SECONDARY);
        statusBar.setBorder(BorderFactory.createEmptyBorder(5, 15, 5, 15));
        JLabel status = new JLabel("Ready | Toulmin Expert System v1.0");
        status.setForeground(Color.WHITE);
        statusBar.add(status, BorderLayout.WEST);
        add(statusBar, BorderLayout.SOUTH);
    }
    
    private JPanel createHeader() {
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(PRIMARY);
        header.setBorder(BorderFactory.createEmptyBorder(15, 20, 15, 20));
        
        JLabel title = new JLabel("Toulmin Argumentation Expert System");
        title.setFont(new Font("SansSerif", Font.BOLD, 24));
        title.setForeground(Color.WHITE);
        
        JLabel subtitle = new JLabel("Forward & Backward Reasoning with HTN Planning");
        subtitle.setFont(new Font("SansSerif", Font.PLAIN, 14));
        subtitle.setForeground(new Color(200, 220, 240));
        
        JPanel titlePanel = new JPanel(new GridLayout(2, 1));
        titlePanel.setOpaque(false);
        titlePanel.add(title);
        titlePanel.add(subtitle);
        header.add(titlePanel, BorderLayout.WEST);
        
        JPanel actionPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        actionPanel.setOpaque(false);
        
        JButton resetBtn = createBtn("Reset System", ACCENT);
        resetBtn.addActionListener(e -> resetSystem());
        JButton helpBtn = createBtn("Help", SECONDARY);
        helpBtn.addActionListener(e -> showHelp());
        actionPanel.add(resetBtn);
        actionPanel.add(helpBtn);
        header.add(actionPanel, BorderLayout.EAST);
        
        return header;
    }
    
    private JButton createBtn(String text, Color bg) {
        JButton btn = new JButton(text);
        btn.setFont(new Font("SansSerif", Font.BOLD, 12));
        btn.setBackground(bg);
        btn.setForeground(Color.WHITE);
        btn.setFocusPainted(false);
        btn.setBorder(BorderFactory.createEmptyBorder(8, 16, 8, 16));
        btn.setOpaque(true);
        return btn;
    }
    
    private JPanel createCardPanel(String title) {
        JPanel card = new JPanel(new BorderLayout());
        card.setBackground(Color.WHITE);
        card.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(220, 220, 220), 1),
            BorderFactory.createEmptyBorder(10, 10, 10, 10)
        ));
        
        JLabel lbl = new JLabel(title);
        lbl.setFont(new Font("SansSerif", Font.BOLD, 14));
        lbl.setForeground(SECONDARY);
        lbl.setBorder(BorderFactory.createEmptyBorder(0, 0, 10, 0));
        card.add(lbl, BorderLayout.NORTH);
        
        return card;
    }
    
    private JPanel createKnowledgeBasePanel() {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBackground(BG);
        panel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
        
        JSplitPane split = new JSplitPane(JSplitPane.VERTICAL_SPLIT);
        split.setResizeWeight(0.5);
        
        // Facts
        JPanel factsPanel = createCardPanel("Facts (Ground Knowledge)");
        factsTableModel = new DefaultTableModel(new String[]{"ID", "Content"}, 0);
        JTable factsTable = new JTable(factsTableModel);
        factsTable.setFont(new Font("Monospaced", Font.PLAIN, 13));
        factsTable.setRowHeight(25);
        
        JPanel factsInput = new JPanel(new BorderLayout(5, 5));
        factsInput.setOpaque(false);
        JTextField factField = new JTextField();
        factField.setFont(new Font("Monospaced", Font.PLAIN, 13));
        JButton addFactBtn = createBtn("Add Fact", ACCENT);
        addFactBtn.addActionListener(e -> {
            String content = factField.getText().trim();
            if (!content.isEmpty()) { addFact(content); factField.setText(""); }
        });
        factsInput.add(new JLabel("New Fact: "), BorderLayout.WEST);
        factsInput.add(factField, BorderLayout.CENTER);
        factsInput.add(addFactBtn, BorderLayout.EAST);
        
        factsPanel.add(new JScrollPane(factsTable), BorderLayout.CENTER);
        factsPanel.add(factsInput, BorderLayout.SOUTH);
        
        // Rules
        JPanel rulesPanel = createCardPanel("Rules (Warrants/Inference Patterns)");
        rulesTableModel = new DefaultTableModel(new String[]{"ID", "Conclusion", "Conditions", "Certainty"}, 0);
        JTable rulesTable = new JTable(rulesTableModel);
        rulesTable.setFont(new Font("Monospaced", Font.PLAIN, 13));
        rulesTable.setRowHeight(25);
        
        JPanel rulesInput = new JPanel(new FlowLayout(FlowLayout.LEFT, 5, 5));
        rulesInput.setOpaque(false);
        JTextField ruleHead = new JTextField(12);
        JTextField ruleBody = new JTextField(20);
        JSpinner certSpinner = new JSpinner(new SpinnerNumberModel(0.8, 0.0, 1.0, 0.1));
        JButton addRuleBtn = createBtn("Add Rule", ACCENT);
        addRuleBtn.addActionListener(e -> {
            String head = ruleHead.getText().trim();
            String body = ruleBody.getText().trim();
            double cert = (Double) certSpinner.getValue();
            if (!head.isEmpty()) { addRule(head, body, cert); ruleHead.setText(""); ruleBody.setText(""); }
        });
        rulesInput.add(new JLabel("Conclusion:"));
        rulesInput.add(ruleHead);
        rulesInput.add(new JLabel("If:"));
        rulesInput.add(ruleBody);
        rulesInput.add(new JLabel("Certainty:"));
        rulesInput.add(certSpinner);
        rulesInput.add(addRuleBtn);
        
        rulesPanel.add(new JScrollPane(rulesTable), BorderLayout.CENTER);
        rulesPanel.add(rulesInput, BorderLayout.SOUTH);
        
        split.setTopComponent(factsPanel);
        split.setBottomComponent(rulesPanel);
        panel.add(split, BorderLayout.CENTER);
        
        return panel;
    }
    
    private JPanel createArgumentBuilderPanel() {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBackground(BG);
        panel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
        
        JSplitPane split = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT);
        split.setResizeWeight(0.5);
        
        // Builder form
        JPanel builderPanel = createCardPanel("Build Toulmin Argument");
        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setOpaque(false);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.anchor = GridBagConstraints.NORTHWEST;
        
        gbc.gridx = 0; gbc.gridy = 0;
        formPanel.add(new JLabel("Claim (C):"), gbc);
        gbc.gridx = 1; gbc.weightx = 1.0;
        claimField = new JTextField();
        formPanel.add(claimField, gbc);
        
        gbc.gridx = 0; gbc.gridy = 1; gbc.weightx = 0;
        formPanel.add(new JLabel("Data (D):"), gbc);
        gbc.gridx = 1; gbc.weightx = 1.0; gbc.weighty = 0.2;
        gbc.fill = GridBagConstraints.BOTH;
        dataArea = new JTextArea(3, 30);
        formPanel.add(new JScrollPane(dataArea), gbc);
        
        gbc.gridx = 0; gbc.gridy = 2; gbc.weightx = 0; gbc.weighty = 0;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        formPanel.add(new JLabel("Warrant (W):"), gbc);
        gbc.gridx = 1; gbc.weightx = 1.0;
        warrantField = new JTextField();
        formPanel.add(warrantField, gbc);
        
        gbc.gridx = 0; gbc.gridy = 3; gbc.weightx = 0;
        formPanel.add(new JLabel("Backing (B):"), gbc);
        gbc.gridx = 1; gbc.weightx = 1.0; gbc.weighty = 0.1;
        gbc.fill = GridBagConstraints.BOTH;
        backingArea = new JTextArea(2, 30);
        formPanel.add(new JScrollPane(backingArea), gbc);
        
        gbc.gridx = 0; gbc.gridy = 4; gbc.weightx = 0; gbc.weighty = 0;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        formPanel.add(new JLabel("Qualifier (Q):"), gbc);
        gbc.gridx = 1; gbc.weightx = 1.0;
        qualifierCombo = new JComboBox<>(new String[]{"certainly", "probably", "possibly", "presumably", "typically"});
        formPanel.add(qualifierCombo, gbc);
        
        gbc.gridx = 0; gbc.gridy = 5; gbc.weightx = 0;
        formPanel.add(new JLabel("Rebuttal (R):"), gbc);
        gbc.gridx = 1; gbc.weightx = 1.0; gbc.weighty = 0.1;
        gbc.fill = GridBagConstraints.BOTH;
        rebuttalArea = new JTextArea(2, 30);
        formPanel.add(new JScrollPane(rebuttalArea), gbc);
        
        gbc.gridx = 0; gbc.gridy = 6; gbc.gridwidth = 2; gbc.weighty = 0;
        gbc.fill = GridBagConstraints.NONE; gbc.anchor = GridBagConstraints.CENTER;
        JPanel btnPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
        btnPanel.setOpaque(false);
        JButton createBtn = createBtn("Create Argument", ACCENT);
        createBtn.addActionListener(e -> createArgument());
        JButton clearBtn = createBtn("Clear Form", SECONDARY);
        clearBtn.addActionListener(e -> clearArgumentForm());
        btnPanel.add(createBtn);
        btnPanel.add(clearBtn);
        formPanel.add(btnPanel, gbc);
        
        builderPanel.add(formPanel, BorderLayout.CENTER);
        
        // Arguments list
        JPanel listPanel = createCardPanel("Created Arguments");
        argumentsTableModel = new DefaultTableModel(new String[]{"ID", "Claim", "Qualifier", "Strength", "Status"}, 0);
        JTable argumentsTable = new JTable(argumentsTableModel);
        argumentsTable.setFont(new Font("Monospaced", Font.PLAIN, 13));
        argumentsTable.setRowHeight(25);
        listPanel.add(new JScrollPane(argumentsTable), BorderLayout.CENTER);
        
        split.setLeftComponent(builderPanel);
        split.setRightComponent(listPanel);
        panel.add(split, BorderLayout.CENTER);
        
        return panel;
    }
    
    private JPanel createForwardReasoningPanel() {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBackground(BG);
        panel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
        
        JSplitPane split = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT);
        split.setResizeWeight(0.5);
        
        JPanel inputPanel = createCardPanel("Forward Reasoning (Data -> Claims)");
        inputPanel.add(new JLabel("<html><b>Forward Reasoning:</b> Given facts, derive what claims can be made.</html>"), BorderLayout.NORTH);
        
        JPanel btnPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        btnPanel.setOpaque(false);
        JButton reasonBtn = createBtn("Derive Claims ->", ACCENT);
        reasonBtn.addActionListener(e -> performForwardReasoning());
        btnPanel.add(reasonBtn);
        inputPanel.add(btnPanel, BorderLayout.SOUTH);
        
        JPanel outputPanel = createCardPanel("Derived Claims");
        forwardOutput = new JTextArea();
        forwardOutput.setFont(new Font("Monospaced", Font.PLAIN, 14));
        forwardOutput.setEditable(false);
        outputPanel.add(new JScrollPane(forwardOutput), BorderLayout.CENTER);
        
        split.setLeftComponent(inputPanel);
        split.setRightComponent(outputPanel);
        panel.add(split, BorderLayout.CENTER);
        
        return panel;
    }
    
    private JPanel createBackwardReasoningPanel() {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBackground(BG);
        panel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
        
        JSplitPane split = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT);
        split.setResizeWeight(0.5);
        
        JPanel inputPanel = createCardPanel("Goal Claim (Claim -> Required Data)");
        inputPanel.add(new JLabel("<html><b>Backward Reasoning:</b> Given a claim, find what facts are needed.</html>"), BorderLayout.NORTH);
        backwardInput = new JTextArea();
        backwardInput.setFont(new Font("Monospaced", Font.PLAIN, 14));
        inputPanel.add(new JScrollPane(backwardInput), BorderLayout.CENTER);
        
        JPanel btnPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        btnPanel.setOpaque(false);
        JButton reasonBtn = createBtn("<- Find Requirements", ACCENT);
        reasonBtn.addActionListener(e -> performBackwardReasoning());
        JButton proveBtn = createBtn("Can Prove?", PRIMARY);
        proveBtn.addActionListener(e -> checkCanProve());
        btnPanel.add(reasonBtn);
        btnPanel.add(proveBtn);
        inputPanel.add(btnPanel, BorderLayout.SOUTH);
        
        JPanel outputPanel = createCardPanel("Required Facts / Proof Status");
        backwardOutput = new JTextArea();
        backwardOutput.setFont(new Font("Monospaced", Font.PLAIN, 14));
        backwardOutput.setEditable(false);
        outputPanel.add(new JScrollPane(backwardOutput), BorderLayout.CENTER);
        
        split.setLeftComponent(inputPanel);
        split.setRightComponent(outputPanel);
        panel.add(split, BorderLayout.CENTER);
        
        return panel;
    }
    
    private JPanel createConflictAnalysisPanel() {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBackground(BG);
        panel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
        
        JSplitPane split = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT);
        split.setResizeWeight(0.4);
        
        JPanel treePanel = createCardPanel("Argument Structure");
        treeRoot = new DefaultMutableTreeNode("Arguments");
        argumentTree = new JTree(treeRoot);
        argumentTree.setFont(new Font("Monospaced", Font.PLAIN, 13));
        treePanel.add(new JScrollPane(argumentTree), BorderLayout.CENTER);
        JButton refreshTreeBtn = createBtn("Refresh Tree", PRIMARY);
        refreshTreeBtn.addActionListener(e -> refreshArgumentTree());
        treePanel.add(refreshTreeBtn, BorderLayout.SOUTH);
        
        JPanel conflictsPanel = createCardPanel("Detected Conflicts");
        conflictsTableModel = new DefaultTableModel(new String[]{"Arg 1", "Arg 2", "Type", "Winner"}, 0);
        JTable conflictsTable = new JTable(conflictsTableModel);
        conflictsTable.setFont(new Font("Monospaced", Font.PLAIN, 13));
        conflictsTable.setRowHeight(25);
        conflictsPanel.add(new JScrollPane(conflictsTable), BorderLayout.CENTER);
        JButton analyzeBtn = createBtn("Analyze Conflicts", ACCENT);
        analyzeBtn.addActionListener(e -> analyzeConflicts());
        conflictsPanel.add(analyzeBtn, BorderLayout.SOUTH);
        
        split.setLeftComponent(treePanel);
        split.setRightComponent(conflictsPanel);
        panel.add(split, BorderLayout.CENTER);
        
        return panel;
    }
    
    private JPanel createPlannerPanel() {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBackground(BG);
        panel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
        
        JSplitPane split = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT);
        split.setResizeWeight(0.5);
        
        JPanel inputPanel = createCardPanel("HTN Planning Tasks");
        inputPanel.add(new JLabel("<html><b>HTN Planner:</b> Hierarchical Task Network planning with the column DB.</html>"), BorderLayout.NORTH);
        
        JPanel btnPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        btnPanel.setOpaque(false);
        JComboBox<String> profileCombo = new JComboBox<>(new String[]{"small", "cached", "indexed"});
        btnPanel.add(new JLabel("Strategy:"));
        btnPanel.add(profileCombo);
        JButton planBtn = createBtn("Generate Plan", ACCENT);
        planBtn.addActionListener(e -> generatePlan((String) profileCombo.getSelectedItem()));
        btnPanel.add(planBtn);
        inputPanel.add(btnPanel, BorderLayout.SOUTH);
        
        JPanel outputPanel = createCardPanel("Generated Plan");
        plannerOutput = new JTextArea();
        plannerOutput.setFont(new Font("Monospaced", Font.PLAIN, 14));
        plannerOutput.setEditable(false);
        outputPanel.add(new JScrollPane(plannerOutput), BorderLayout.CENTER);
        
        split.setLeftComponent(inputPanel);
        split.setRightComponent(outputPanel);
        panel.add(split, BorderLayout.CENTER);
        
        return panel;
    }
    
    private JPanel createConsolePanel() {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBackground(BG);
        panel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
        
        JPanel outputPanel = createCardPanel("Console Output");
        consoleOutput = new JTextArea();
        consoleOutput.setFont(new Font("Monospaced", Font.PLAIN, 13));
        consoleOutput.setEditable(false);
        consoleOutput.setBackground(new Color(30, 30, 30));
        consoleOutput.setForeground(new Color(200, 200, 200));
        outputPanel.add(new JScrollPane(consoleOutput), BorderLayout.CENTER);
        
        JPanel inputPanel = createCardPanel("Prolog Query");
        queryInput = new JTextArea(4, 50);
        queryInput.setFont(new Font("Monospaced", Font.PLAIN, 14));
        inputPanel.add(new JScrollPane(queryInput), BorderLayout.CENTER);
        
        JPanel btnPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 5));
        btnPanel.setOpaque(false);
        JButton queryBtn = createBtn("Execute Query", ACCENT);
        queryBtn.addActionListener(e -> executeQuery());
        JButton clearBtn = createBtn("Clear Console", SECONDARY);
        clearBtn.addActionListener(e -> consoleOutput.setText(""));
        btnPanel.add(queryBtn);
        btnPanel.add(clearBtn);
        inputPanel.add(btnPanel, BorderLayout.SOUTH);
        
        JSplitPane split = new JSplitPane(JSplitPane.VERTICAL_SPLIT);
        split.setResizeWeight(0.7);
        split.setTopComponent(outputPanel);
        split.setBottomComponent(inputPanel);
        panel.add(split, BorderLayout.CENTER);
        
        return panel;
    }
    
    // ==================== Logic Methods ====================
    
    private void loadSampleKnowledge() {
        addFact("bird(tweety)");
        addFact("penguin(pingu)");
        addFact("bird(pingu)");
        addFact("healthy(tweety)");
        addRule("can_fly(X)", "bird(X), healthy(X)", 0.9);
        addRule("cannot_fly(X)", "penguin(X)", 1.0);
        addRule("animal(X)", "bird(X)", 1.0);
        log("Sample knowledge base loaded.");
    }
    
    private void addFact(String content) {
        try {
            Obj contentTerm = parseTerm(content);
            Obj idVar = Var();
            List<Map<Integer, Obj>> results = query(program, Comp("assert_fact", idVar, contentTerm));
            if (!results.isEmpty()) {
                String idStr = pp(results.get(0).get(idVar.get(K_VID)));
                factsTableModel.addRow(new Object[]{idStr, content});
                log("Added fact: " + content);
            }
        } catch (Exception e) { log("Error adding fact: " + e.getMessage()); }
    }
    
    private void addRule(String head, String body, double certainty) {
        try {
            Obj headTerm = parseTerm(head);
            Obj bodyTerm = body.isEmpty() ? listNil() : parseBodyTerms(body);
            Obj certTerm = Num((long)(certainty * 100));
            Obj idVar = Var();
            List<Map<Integer, Obj>> results = query(program, Comp("assert_rule", idVar, headTerm, bodyTerm, certTerm));
            if (!results.isEmpty()) {
                String idStr = pp(results.get(0).get(idVar.get(K_VID)));
                rulesTableModel.addRow(new Object[]{idStr, head, body, certainty});
                log("Added rule: " + head + " :- " + body);
            }
        } catch (Exception e) { log("Error adding rule: " + e.getMessage()); }
    }
    
    private Obj parseTerm(String text) {
        text = text.trim();
        int parenIdx = text.indexOf('(');
        if (parenIdx > 0 && text.endsWith(")")) {
            String functor = text.substring(0, parenIdx);
            String argsStr = text.substring(parenIdx + 1, text.length() - 1);
            List<Obj> args = new ArrayList<>();
            for (String arg : splitArgs(argsStr)) args.add(parseTerm(arg.trim()));
            return Comp(functor, args.toArray(new Obj[0]));
        }
        try { return Num(Long.parseLong(text)); } catch (NumberFormatException e) {}
        if (text.length() > 0 && (Character.isUpperCase(text.charAt(0)) || text.charAt(0) == '_')) return Var();
        return Atom(text);
    }
    
    private List<String> splitArgs(String argsStr) {
        List<String> args = new ArrayList<>();
        int depth = 0;
        StringBuilder current = new StringBuilder();
        for (char c : argsStr.toCharArray()) {
            if (c == ',' && depth == 0) { args.add(current.toString()); current = new StringBuilder(); }
            else { if (c == '(' || c == '[') depth++; if (c == ')' || c == ']') depth--; current.append(c); }
        }
        if (current.length() > 0) args.add(current.toString());
        return args;
    }
    
    private Obj parseBodyTerms(String body) {
        List<String> conditions = splitArgs(body);
        if (conditions.size() == 1) return parseTerm(conditions.get(0));
        Obj result = listNil();
        for (int i = conditions.size() - 1; i >= 0; i--) result = listCons(parseTerm(conditions.get(i)), result);
        return result;
    }
    
    private void createArgument() {
        try {
            String claim = claimField.getText().trim();
            if (claim.isEmpty()) { JOptionPane.showMessageDialog(this, "Claim is required!"); return; }
            
            Obj claimTerm = parseTerm(claim);
            String[] dataLines = dataArea.getText().split("\n");
            Obj dataList = listNil();
            for (int i = dataLines.length - 1; i >= 0; i--) {
                String line = dataLines[i].trim();
                if (!line.isEmpty()) dataList = listCons(parseTerm(line), dataList);
            }
            
            String warrant = warrantField.getText().trim();
            Obj warrantTerm = warrant.isEmpty() ? Atom("none") : parseTerm(warrant);
            String backing = backingArea.getText().trim();
            Obj backingTerm = backing.isEmpty() ? Atom("none") : parseTerm(backing);
            String qualifier = (String) qualifierCombo.getSelectedItem();
            Obj qualTerm = Atom(qualifier);
            String rebuttal = rebuttalArea.getText().trim();
            Obj rebuttalTerm = rebuttal.isEmpty() ? Atom("none") : Comp("unless", parseTerm(rebuttal));
            
            Obj idVar = Var();
            List<Map<Integer, Obj>> results = query(program, Comp("create_argument", idVar, claimTerm, dataList, warrantTerm, backingTerm, qualTerm, rebuttalTerm));
            
            if (!results.isEmpty()) {
                Obj id = results.get(0).get(idVar.get(K_VID));
                Obj strengthVar = Var();
                List<Map<Integer, Obj>> strengthResults = query(program, Comp("argument_strength", id, strengthVar));
                String strength = strengthResults.isEmpty() ? "?" : pp(strengthResults.get(0).get(strengthVar.get(K_VID)));
                
                Obj statusVar = Var();
                List<Map<Integer, Obj>> statusResults = query(program, Comp("validate_argument", id, statusVar));
                String status = statusResults.isEmpty() ? "unknown" : pp(statusResults.get(0).get(statusVar.get(K_VID)));
                
                argumentsTableModel.addRow(new Object[]{pp(id), claim, qualifier, strength, status});
                log("Created argument " + pp(id) + ": " + claim);
                clearArgumentForm();
            }
        } catch (Exception e) { log("Error creating argument: " + e.getMessage()); e.printStackTrace(); }
    }
    
    private void clearArgumentForm() {
        claimField.setText(""); dataArea.setText(""); warrantField.setText("");
        backingArea.setText(""); rebuttalArea.setText("");
    }
    
    private void performForwardReasoning() {
        try {
            StringBuilder output = new StringBuilder("=== Forward Reasoning Results ===\n\n");
            Obj factsVar = Var();
            List<Map<Integer, Obj>> factResults = query(program, Comp("list_facts", factsVar));
            if (!factResults.isEmpty()) {
                Obj facts = factResults.get(0).get(factsVar.get(K_VID));
                output.append("Current Facts:\n").append(pp(facts)).append("\n\n");
                Obj claimsVar = Var();
                List<Map<Integer, Obj>> deriveResults = query(program, Comp("forward_derive", facts, claimsVar));
                if (!deriveResults.isEmpty()) {
                    Obj claims = deriveResults.get(0).get(claimsVar.get(K_VID));
                    output.append("Derived Claims:\n").append(formatList(claims));
                } else output.append("No claims could be derived.\n");
            }
            forwardOutput.setText(output.toString());
            log("Forward reasoning completed.");
        } catch (Exception e) { forwardOutput.setText("Error: " + e.getMessage()); }
    }
    
    private void performBackwardReasoning() {
        try {
            String claim = backwardInput.getText().trim();
            if (claim.isEmpty()) { backwardOutput.setText("Please enter a claim."); return; }
            StringBuilder output = new StringBuilder("=== Backward Reasoning for: " + claim + " ===\n\n");
            Obj claimTerm = parseTerm(claim);
            Obj requiredVar = Var();
            List<Map<Integer, Obj>> results = query(program, Comp("backward_derive", claimTerm, requiredVar));
            if (!results.isEmpty()) {
                output.append("Required facts:\n");
                for (Map<Integer, Obj> sol : results) output.append("  ").append(pp(sol.get(requiredVar.get(K_VID)))).append("\n");
            } else output.append("No rules found for this claim.\n");
            backwardOutput.setText(output.toString());
        } catch (Exception e) { backwardOutput.setText("Error: " + e.getMessage()); }
    }
    
    private void checkCanProve() {
        try {
            String claim = backwardInput.getText().trim();
            if (claim.isEmpty()) { backwardOutput.setText("Please enter a claim."); return; }
            Obj claimTerm = parseTerm(claim);
            Obj proofVar = Var();
            List<Map<Integer, Obj>> results = query(program, Comp("can_prove", claimTerm, proofVar));
            StringBuilder output = new StringBuilder("=== Proof Check for: " + claim + " ===\n\n");
            if (!results.isEmpty()) {
                output.append("YES! This claim CAN be proven.\n\nProof:\n");
                for (Map<Integer, Obj> sol : results) output.append(pp(sol.get(proofVar.get(K_VID)))).append("\n");
            } else output.append("NO. Cannot be proven with current facts.\n");
            backwardOutput.setText(output.toString());
        } catch (Exception e) { backwardOutput.setText("Error: " + e.getMessage()); }
    }
    
    private void analyzeConflicts() {
        conflictsTableModel.setRowCount(0);
        try {
            Obj arg1Var = Var(), arg2Var = Var(), typeVar = Var();
            List<Map<Integer, Obj>> results = query(program, Comp("detect_conflict", arg1Var, arg2Var, typeVar));
            for (Map<Integer, Obj> sol : results) {
                String arg1 = pp(sol.get(arg1Var.get(K_VID)));
                String arg2 = pp(sol.get(arg2Var.get(K_VID)));
                String type = pp(sol.get(typeVar.get(K_VID)));
                Obj winnerVar = Var();
                List<Map<Integer, Obj>> resolveResults = query(program, Comp("resolve_conflict", sol.get(arg1Var.get(K_VID)), sol.get(arg2Var.get(K_VID)), winnerVar));
                String winner = resolveResults.isEmpty() ? "?" : pp(resolveResults.get(0).get(winnerVar.get(K_VID)));
                conflictsTableModel.addRow(new Object[]{arg1, arg2, type, winner});
            }
            log(results.isEmpty() ? "No conflicts detected." : "Found " + results.size() + " conflict(s).");
        } catch (Exception e) { log("Error analyzing conflicts: " + e.getMessage()); }
    }
    
    private void refreshArgumentTree() {
        treeRoot.removeAllChildren();
        try {
            Obj idsVar = Var();
            List<Map<Integer, Obj>> results = query(program, Comp("list_arguments", idsVar));
            if (!results.isEmpty()) {
                Obj ids = results.get(0).get(idsVar.get(K_VID));
                List<Obj> idList = flattenProperList(ids);
                for (Obj id : idList) {
                    Obj claimVar = Var(), dataVar = Var(), warrantVar = Var();
                    Obj backingVar = Var(), qualVar = Var(), rebutVar = Var();
                    List<Map<Integer, Obj>> argResults = query(program, Comp("get_argument", id, claimVar, dataVar, warrantVar, backingVar, qualVar, rebutVar));
                    if (!argResults.isEmpty()) {
                        Map<Integer, Obj> arg = argResults.get(0);
                        DefaultMutableTreeNode argNode = new DefaultMutableTreeNode("Arg " + pp(id) + ": " + pp(arg.get(claimVar.get(K_VID))));
                        argNode.add(new DefaultMutableTreeNode("Data: " + pp(arg.get(dataVar.get(K_VID)))));
                        argNode.add(new DefaultMutableTreeNode("Warrant: " + pp(arg.get(warrantVar.get(K_VID)))));
                        argNode.add(new DefaultMutableTreeNode("Backing: " + pp(arg.get(backingVar.get(K_VID)))));
                        argNode.add(new DefaultMutableTreeNode("Qualifier: " + pp(arg.get(qualVar.get(K_VID)))));
                        argNode.add(new DefaultMutableTreeNode("Rebuttal: " + pp(arg.get(rebutVar.get(K_VID)))));
                        treeRoot.add(argNode);
                    }
                }
            }
            ((DefaultTreeModel) argumentTree.getModel()).reload();
            for (int i = 0; i < argumentTree.getRowCount(); i++) argumentTree.expandRow(i);
        } catch (Exception e) { log("Error refreshing tree: " + e.getMessage()); }
    }
    
    private void generatePlan(String profile) {
        try {
            plannerOutput.setText("Generating plan with profile: " + profile + "...\n\n");
            Obj profileAtom = Atom(profile);
            Obj planVar = Var();
            List<Map<Integer, Obj>> results = query(program, Comp("demo_plan", profileAtom, planVar));
            if (!results.isEmpty()) {
                Obj plan = results.get(0).get(planVar.get(K_VID));
                StringBuilder output = new StringBuilder("=== HTN Plan Generated ===\nProfile: " + profile + "\n\nPlan Steps:\n");
                output.append(formatList(plan));
                plannerOutput.setText(output.toString());
                log("Plan generated successfully.");
            } else plannerOutput.setText("No plan could be generated.");
        } catch (Exception e) { plannerOutput.setText("Error: " + e.getMessage()); e.printStackTrace(); }
    }
    
    private String formatList(Obj list) {
        StringBuilder sb = new StringBuilder();
        List<Obj> items = flattenProperList(list);
        int i = 1;
        for (Obj item : items) sb.append("  ").append(i++).append(". ").append(pp(item)).append("\n");
        return sb.toString();
    }
    
    private void executeQuery() {
        String queryText = queryInput.getText().trim();
        if (queryText.isEmpty()) return;
        log("\n> " + queryText);
        try {
            Obj goal = parseTerm(queryText);
            List<Map<Integer, Obj>> results = query(program, goal);
            if (results.isEmpty()) log("false.");
            else {
                log("Solutions (" + results.size() + "):");
                for (int i = 0; i < results.size(); i++) {
                    Map<Integer, Obj> sol = results.get(i);
                    StringBuilder sb = new StringBuilder("  #" + (i + 1) + ": ");
                    for (Map.Entry<Integer, Obj> e : sol.entrySet()) sb.append("_").append(e.getKey()).append(" = ").append(pp(e.getValue())).append(", ");
                    log(sb.toString());
                }
            }
        } catch (Exception e) { log("Error: " + e.getMessage()); }
    }
    
    private void resetSystem() {
        if (JOptionPane.showConfirmDialog(this, "Reset will clear everything. Continue?", "Confirm Reset", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {
            query(program, Comp("toulmin_init"));
            factsTableModel.setRowCount(0);
            rulesTableModel.setRowCount(0);
            argumentsTableModel.setRowCount(0);
            conflictsTableModel.setRowCount(0);
            treeRoot.removeAllChildren();
            ((DefaultTreeModel) argumentTree.getModel()).reload();
            loadSampleKnowledge();
            log("System reset complete.");
        }
    }
    
    private void showHelp() {
        String help = "TOULMIN ARGUMENTATION EXPERT SYSTEM\n====================================\n\n" +
            "1. KNOWLEDGE BASE: Add facts and rules\n" +
            "2. ARGUMENT BUILDER: Build Toulmin arguments (Claim, Data, Warrant, Backing, Qualifier, Rebuttal)\n" +
            "3. FORWARD REASONING: Derive claims from facts\n" +
            "4. BACKWARD REASONING: Find required facts for a claim\n" +
            "5. CONFLICT ANALYSIS: Detect and resolve conflicts\n" +
            "6. HTN PLANNER: Hierarchical task planning\n" +
            "7. PROLOG CONSOLE: Direct queries\n";
        JOptionPane.showMessageDialog(this, help, "Help", JOptionPane.INFORMATION_MESSAGE);
    }
    
    private void log(String message) {
        SwingUtilities.invokeLater(() -> {
            consoleOutput.append(message + "\n");
            consoleOutput.setCaretPosition(consoleOutput.getDocument().getLength());
        });
    }
    
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new ToulminExpertSystemUI().setVisible(true));
    }
}
