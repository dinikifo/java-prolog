package com.mycompany.prolog;

import static com.mycompany.prolog.MiniPrologProto.*;

/**
 * Toulmin Argumentation Model Library for Prolog.
 */
public final class ToulminArgumentLib {
    private ToulminArgumentLib() {}

    static Obj conj(Obj... gs) {
        if (gs == null || gs.length == 0) return Comp("true");
        Obj out = gs[gs.length - 1];
        for (int i = gs.length - 2; i >= 0; i--) out = Comp(",", gs[i], out);
        return out;
    }

    private static void ensurePred(Obj prog, String name, int arity) {
        if (getPred(prog.get(K_PREDICATES), name, arity) == null) {
            definePred(prog, name, arity, Predicate());
        }
    }

    public static void load(Obj prog) {
        ensurePred(prog, "argument", 7);
        ensurePred(prog, "fact", 2);
        ensurePred(prog, "rule", 4);
        ensurePred(prog, "arg_counter", 1);
        ensurePred(prog, "toulmin_ready", 0);
        
        installToulminCore(prog);
        installForwardReasoning(prog);
        installBackwardReasoning(prog);
        installArgumentAnalysis(prog);
        installConflictResolution(prog);
    }

    private static void installToulminCore(Obj prog) {
        {
            Obj Any = Var();
            definePred(prog, "toulmin_init", 0, Predicate(
                Clause(Comp("toulmin_init"),
                    Comp("retract_all", Comp("toulmin_ready")),
                    Comp("retract_all", Comp("argument", Any, Any, Any, Any, Any, Any, Any)),
                    Comp("retract_all", Comp("fact", Any, Any)),
                    Comp("retract_all", Comp("rule", Any, Any, Any, Any)),
                    Comp("retract_all", Comp("arg_counter", Any)),
                    Comp("assertz", Comp("arg_counter", Num(0))),
                    Comp("assertz", Comp("toulmin_ready"))
                )
            ));
        }

        {
            Obj N = Var(), N1 = Var(), Id = Var();
            definePred(prog, "next_arg_id", 1, Predicate(
                Clause(Comp("next_arg_id", Id),
                    Comp("toulmin_ready"),
                    Comp(";",
                        Comp("->", Comp("retract", Comp("arg_counter", N)), Comp("true")),
                        Comp("=", N, Num(0))
                    ),
                    Comp("is", N1, Comp("+", N, Num(1))),
                    Comp("assertz", Comp("arg_counter", N1)),
                    Comp("=", Id, N1)
                )
            ));
        }

        {
            Obj Id = Var(), Content = Var();
            definePred(prog, "assert_fact", 2, Predicate(
                Clause(Comp("assert_fact", Id, Content),
                    Comp("toulmin_ready"),
                    Comp("next_arg_id", Id),
                    Comp("assertz", Comp("fact", Id, Content))
                )
            ));
        }

        {
            Obj Id = Var(), Head = Var(), Body = Var(), Certainty = Var();
            definePred(prog, "assert_rule", 4, Predicate(
                Clause(Comp("assert_rule", Id, Head, Body, Certainty),
                    Comp("toulmin_ready"),
                    Comp("next_arg_id", Id),
                    Comp("assertz", Comp("rule", Id, Head, Body, Certainty))
                )
            ));
        }

        {
            Obj Id = Var(), Claim = Var(), Data = Var(), Warrant = Var();
            Obj Backing = Var(), Qualifier = Var(), Rebuttal = Var();
            definePred(prog, "create_argument", 7, Predicate(
                Clause(Comp("create_argument", Id, Claim, Data, Warrant, Backing, Qualifier, Rebuttal),
                    Comp("toulmin_ready"),
                    Comp("next_arg_id", Id),
                    Comp("assertz", Comp("argument", Id, Claim, Data, Warrant, Backing, Qualifier, Rebuttal))
                )
            ));
        }

        {
            Obj Id = Var(), Claim = Var(), Data = Var(), Warrant = Var();
            Obj Backing = Var(), Qualifier = Var(), Rebuttal = Var();
            definePred(prog, "get_argument", 7, Predicate(
                Clause(Comp("get_argument", Id, Claim, Data, Warrant, Backing, Qualifier, Rebuttal),
                    Comp("toulmin_ready"),
                    Comp("argument", Id, Claim, Data, Warrant, Backing, Qualifier, Rebuttal)
                )
            ));
        }

        {
            Obj Ids = Var(), Id = Var(), Any = Var();
            definePred(prog, "list_arguments", 1, Predicate(
                Clause(Comp("list_arguments", Ids),
                    Comp("toulmin_ready"),
                    Comp("findall", Id, Comp("argument", Id, Any, Any, Any, Any, Any, Any), Ids)
                )
            ));
        }

        {
            Obj Facts = Var(), Id = Var(), Content = Var();
            definePred(prog, "list_facts", 1, Predicate(
                Clause(Comp("list_facts", Facts),
                    Comp("toulmin_ready"),
                    Comp("findall", Comp("fact", Id, Content), Comp("fact", Id, Content), Facts)
                )
            ));
        }

        {
            Obj Rules = Var(), Id = Var(), H = Var(), B = Var(), C = Var();
            definePred(prog, "list_rules", 1, Predicate(
                Clause(Comp("list_rules", Rules),
                    Comp("toulmin_ready"),
                    Comp("findall", Comp("rule", Id, H, B, C), Comp("rule", Id, H, B, C), Rules)
                )
            ));
        }
    }

    private static void installForwardReasoning(Obj prog) {
        {
            Obj Facts = Var(), Claims = Var();
            Obj RuleId = Var(), Head = Var(), Body = Var(), Certainty = Var();
            definePred(prog, "forward_derive", 2, Predicate(
                Clause(Comp("forward_derive", Facts, Claims),
                    Comp("toulmin_ready"),
                    Comp("findall", Comp("claim", Head, RuleId, Certainty),
                        conj(
                            Comp("rule", RuleId, Head, Body, Certainty),
                            Comp("body_satisfied", Body, Facts)
                        ),
                        Claims
                    )
                )
            ));
        }

        {
            Obj Body = Var(), Facts = Var();
            Obj Cond = Var(), Rest = Var();
            definePred(prog, "body_satisfied", 2, Predicate(
                Clause(Comp("body_satisfied", listNil(), Facts), Comp("true")),
                Clause(Comp("body_satisfied", Cond, Facts),
                    Comp("\\+", Comp("=", Cond, listNil())),
                    Comp("\\+", Comp("=", Cond, listCons(Var(), Var()))),
                    Comp("fact_matches", Cond, Facts)
                ),
                Clause(Comp("body_satisfied", listCons(Cond, Rest), Facts),
                    Comp("fact_matches", Cond, Facts),
                    Comp("body_satisfied", Rest, Facts)
                )
            ));
        }

        {
            Obj Cond = Var(), Facts = Var(), Id = Var();
            definePred(prog, "fact_matches", 2, Predicate(
                Clause(Comp("fact_matches", Cond, Facts),
                    Comp("member", Comp("fact", Id, Cond), Facts)
                ),
                Clause(Comp("fact_matches", Cond, Facts),
                    Comp("fact", Id, Cond)
                )
            ));
        }

        {
            Obj Claim = Var(), Facts = Var(), ArgId = Var();
            Obj RuleId = Var(), Body = Var(), Certainty = Var();
            Obj DataList = Var(), Warrant = Var(), Backing = Var();
            definePred(prog, "forward_build_argument", 3, Predicate(
                Clause(Comp("forward_build_argument", Claim, Facts, ArgId),
                    Comp("toulmin_ready"),
                    Comp("rule", RuleId, Claim, Body, Certainty),
                    Comp("body_satisfied", Body, Facts),
                    Comp("collect_data", Body, Facts, DataList),
                    Comp("=", Warrant, Comp("rule", RuleId)),
                    Comp("=", Backing, Comp("facts", DataList)),
                    Comp("create_argument", ArgId, Claim, DataList, Warrant, Backing, Certainty, Atom("none"))
                )
            ));
        }

        {
            Obj Body = Var(), Facts = Var(), Data = Var();
            Obj Cond = Var(), Rest = Var(), D1 = Var(), D2 = Var(), Id = Var();
            definePred(prog, "collect_data", 3, Predicate(
                Clause(Comp("collect_data", listNil(), Facts, listNil()), Comp("true")),
                Clause(Comp("collect_data", Cond, Facts, list(Comp("fact", Id, Cond))),
                    Comp("\\+", Comp("=", Cond, listNil())),
                    Comp("\\+", Comp("=", Cond, listCons(Var(), Var()))),
                    Comp("fact", Id, Cond)
                ),
                Clause(Comp("collect_data", listCons(Cond, Rest), Facts, Data),
                    Comp("collect_data", Cond, Facts, D1),
                    Comp("collect_data", Rest, Facts, D2),
                    Comp("append", D1, D2, Data)
                )
            ));
        }
    }

    private static void installBackwardReasoning(Obj prog) {
        {
            Obj Claim = Var(), RequiredFacts = Var();
            Obj RuleId = Var(), Body = Var(), Certainty = Var();
            definePred(prog, "backward_derive", 2, Predicate(
                Clause(Comp("backward_derive", Claim, RequiredFacts),
                    Comp("toulmin_ready"),
                    Comp("rule", RuleId, Claim, Body, Certainty),
                    Comp("expand_body", Body, RequiredFacts)
                )
            ));
        }

        {
            Obj Body = Var(), Required = Var();
            Obj Cond = Var(), Rest = Var(), R1 = Var(), R2 = Var();
            definePred(prog, "expand_body", 2, Predicate(
                Clause(Comp("expand_body", listNil(), listNil()), Comp("true")),
                Clause(Comp("expand_body", Cond, list(Comp("need", Cond))),
                    Comp("\\+", Comp("=", Cond, listNil())),
                    Comp("\\+", Comp("=", Cond, listCons(Var(), Var())))
                ),
                Clause(Comp("expand_body", listCons(Cond, Rest), Required),
                    Comp("expand_body", Cond, R1),
                    Comp("expand_body", Rest, R2),
                    Comp("append", R1, R2, Required)
                )
            ));
        }

        {
            Obj Claim = Var(), Proof = Var();
            Obj RuleId = Var(), Body = Var(), Certainty = Var();
            Obj Facts = Var(), DataList = Var();
            definePred(prog, "can_prove", 2, Predicate(
                Clause(Comp("can_prove", Claim, Proof),
                    Comp("toulmin_ready"),
                    Comp("list_facts", Facts),
                    Comp("rule", RuleId, Claim, Body, Certainty),
                    Comp("body_satisfied", Body, Facts),
                    Comp("collect_data", Body, Facts, DataList),
                    Comp("=", Proof, Comp("proof", Claim, RuleId, DataList, Certainty))
                )
            ));
        }

        {
            Obj Claim = Var(), Missing = Var();
            Obj RuleId = Var(), Body = Var(), Certainty = Var(), Facts = Var();
            definePred(prog, "missing_facts", 2, Predicate(
                Clause(Comp("missing_facts", Claim, Missing),
                    Comp("toulmin_ready"),
                    Comp("list_facts", Facts),
                    Comp("rule", RuleId, Claim, Body, Certainty),
                    Comp("find_missing", Body, Facts, Missing)
                )
            ));
        }

        {
            Obj Body = Var(), Facts = Var(), Missing = Var();
            Obj Cond = Var(), Rest = Var(), M1 = Var(), M2 = Var();
            definePred(prog, "find_missing", 3, Predicate(
                Clause(Comp("find_missing", listNil(), Facts, listNil()), Comp("true")),
                Clause(Comp("find_missing", Cond, Facts, listNil()),
                    Comp("\\+", Comp("=", Cond, listNil())),
                    Comp("\\+", Comp("=", Cond, listCons(Var(), Var()))),
                    Comp("fact_matches", Cond, Facts)
                ),
                Clause(Comp("find_missing", Cond, Facts, list(Cond)),
                    Comp("\\+", Comp("=", Cond, listNil())),
                    Comp("\\+", Comp("=", Cond, listCons(Var(), Var()))),
                    Comp("\\+", Comp("fact_matches", Cond, Facts))
                ),
                Clause(Comp("find_missing", listCons(Cond, Rest), Facts, Missing),
                    Comp("find_missing", Cond, Facts, M1),
                    Comp("find_missing", Rest, Facts, M2),
                    Comp("append", M1, M2, Missing)
                )
            ));
        }
    }

    private static void installArgumentAnalysis(Obj prog) {
        {
            Obj ArgId = Var(), Strength = Var();
            Obj Claim = Var(), Data = Var(), Warrant = Var();
            Obj Backing = Var(), Qualifier = Var(), Rebuttal = Var();
            Obj DataLen = Var(), BackingBonus = Var(), RebuttalPenalty = Var(), BaseScore = Var();
            definePred(prog, "argument_strength", 2, Predicate(
                Clause(Comp("argument_strength", ArgId, Strength),
                    Comp("toulmin_ready"),
                    Comp("argument", ArgId, Claim, Data, Warrant, Backing, Qualifier, Rebuttal),
                    Comp("length", Data, DataLen),
                    Comp(";",
                        Comp("->", Comp("=", Backing, Atom("none")), Comp("=", BackingBonus, Num(0))),
                        Comp("=", BackingBonus, Num(10))
                    ),
                    Comp(";",
                        Comp("->", Comp("=", Rebuttal, Atom("none")), Comp("=", RebuttalPenalty, Num(0))),
                        Comp("=", RebuttalPenalty, Num(20))
                    ),
                    Comp("is", BaseScore, Comp("*", DataLen, Num(10))),
                    Comp("is", Strength, Comp("-", Comp("+", BaseScore, BackingBonus), RebuttalPenalty))
                )
            ));
        }

        {
            Obj ArgId = Var();
            Obj Claim = Var(), Data = Var(), Warrant = Var();
            Obj Backing = Var(), Qualifier = Var(), Rebuttal = Var();
            definePred(prog, "validate_argument", 2, Predicate(
                Clause(Comp("validate_argument", ArgId, Atom("valid")),
                    Comp("toulmin_ready"),
                    Comp("argument", ArgId, Claim, Data, Warrant, Backing, Qualifier, Rebuttal),
                    Comp("\\+", Comp("=", Claim, Atom("none"))),
                    Comp("\\+", Comp("=", Data, listNil())),
                    Comp("\\+", Comp("=", Warrant, Atom("none")))
                ),
                Clause(Comp("validate_argument", ArgId, Atom("missing_claim")),
                    Comp("toulmin_ready"),
                    Comp("argument", ArgId, Atom("none"), Data, Warrant, Backing, Qualifier, Rebuttal)
                ),
                Clause(Comp("validate_argument", ArgId, Atom("missing_data")),
                    Comp("toulmin_ready"),
                    Comp("argument", ArgId, Claim, listNil(), Warrant, Backing, Qualifier, Rebuttal)
                ),
                Clause(Comp("validate_argument", ArgId, Atom("missing_warrant")),
                    Comp("toulmin_ready"),
                    Comp("argument", ArgId, Claim, Data, Atom("none"), Backing, Qualifier, Rebuttal)
                )
            ));
        }
    }

    private static void installConflictResolution(Obj prog) {
        {
            Obj ArgId1 = Var(), ArgId2 = Var();
            Obj Claim1 = Var(), Claim2 = Var();
            Obj D1 = Var(), D2 = Var(), W1 = Var(), W2 = Var();
            Obj B1 = Var(), B2 = Var(), Q1 = Var(), Q2 = Var();
            Obj R1 = Var(), R2 = Var();
            definePred(prog, "detect_conflict", 3, Predicate(
                Clause(Comp("detect_conflict", ArgId1, ArgId2, Atom("contradiction")),
                    Comp("toulmin_ready"),
                    Comp("argument", ArgId1, Claim1, D1, W1, B1, Q1, R1),
                    Comp("argument", ArgId2, Claim2, D2, W2, B2, Q2, R2),
                    Comp("\\+", Comp("=", ArgId1, ArgId2)),
                    Comp("contradicts", Claim1, Claim2)
                ),
                Clause(Comp("detect_conflict", ArgId1, ArgId2, Atom("rebutted")),
                    Comp("toulmin_ready"),
                    Comp("argument", ArgId1, Claim1, D1, W1, B1, Q1, R1),
                    Comp("argument", ArgId2, Claim2, D2, W2, B2, Q2, R2),
                    Comp("\\+", Comp("=", ArgId1, ArgId2)),
                    Comp("\\+", Comp("=", R1, Atom("none"))),
                    Comp("rebuttal_applies", R1, ArgId2)
                )
            ));
        }

        {
            Obj P = Var();
            definePred(prog, "contradicts", 2, Predicate(
                Clause(Comp("contradicts", Comp("not", P), P), Comp("true")),
                Clause(Comp("contradicts", P, Comp("not", P)), Comp("true"))
            ));
        }

        {
            Obj Rebuttal = Var(), ArgId = Var();
            Obj Claim = Var(), Data = Var(), W = Var(), B = Var(), Q = Var(), R = Var();
            definePred(prog, "rebuttal_applies", 2, Predicate(
                Clause(Comp("rebuttal_applies", Comp("unless", Rebuttal), ArgId),
                    Comp("argument", ArgId, Claim, Data, W, B, Q, R),
                    Comp("member", Rebuttal, Data)
                )
            ));
        }

        {
            Obj ArgId1 = Var(), ArgId2 = Var(), S1 = Var(), S2 = Var();
            definePred(prog, "resolve_conflict", 3, Predicate(
                Clause(Comp("resolve_conflict", ArgId1, ArgId2, ArgId1),
                    Comp("toulmin_ready"),
                    Comp("argument_strength", ArgId1, S1),
                    Comp("argument_strength", ArgId2, S2),
                    Comp(">", S1, S2)
                ),
                Clause(Comp("resolve_conflict", ArgId1, ArgId2, ArgId2),
                    Comp("toulmin_ready"),
                    Comp("argument_strength", ArgId1, S1),
                    Comp("argument_strength", ArgId2, S2),
                    Comp("=<", S1, S2)
                )
            ));
        }
    }
}
