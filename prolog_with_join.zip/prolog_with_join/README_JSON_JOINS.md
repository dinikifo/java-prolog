# JSON Join Mechanics (ColumnDb)

This repo includes a **DB-side equi-join engine** driven by a **JSON join specification**. The join runs inside the ColumnDB layer (not the HTN planner), and can be invoked as a normal DB message.

---

## Quick start

### 1) Create tables (example)
```prolog
send(DB, create_table(users,  [col(id,int,[]), col(name,atom,[])],  UsersT)),
send(DB, create_table(orders, [col(id,int,[]), col(user_id,int,[]), col(total,int,[])], OrdersT)),

send(UsersT,  insert(row([id=1, name=ada]))),
send(UsersT,  insert(row([id=2, name=bob]))),

send(OrdersT, insert(row([id=10, user_id=1, total=120]))),
send(OrdersT, insert(row([id=11, user_id=1, total=40 ]))),
send(OrdersT, insert(row([id=12, user_id=3, total=9  ]))).
```

### 2) (Recommended) index the **right** join key
The join probes the **right** table by equality on the right join key, so a hash index there is the biggest win:

```prolog
send(OrdersT, create_index(user_id, hash)).
```

Hash indexes are maintained incrementally on insert.

### 3) Run a join from JSON

```prolog
Json = str('{
  "type":"left",
  "left":"users",
  "right":"orders",
  "on":{"left":"id","right":"user_id"},
  "select":{"left":["id","name"],"right":["id","total"]},
  "where":{"right":{"col":"total","op":"ge","val":50}},
  "opts":{"qualify":true,"aliases":{"left":"u","right":"o"},"limit":50}
}'),
send(DB, join_json(Json, Rows)).
```

`Rows` is a list of `row(Pairs)` terms, e.g. (shape example):

```prolog
[
  row([q(u,id)=1, q(u,name)=ada, q(o,id)=10, q(o,total)=120]),
  row([q(u,id)=2, q(u,name)=bob, q(o,id)=null, q(o,total)=null])
]
```

Notes:
- Outer joins fill missing-side columns with the atom `null`.
- If `qualify=false`, keys are **not** qualified and you may get collisions (e.g. both sides have `id`).

---

## DB entrypoint

### `send(DB, join_json(Json, Rows)).`

`Json` can be either:
- an atom/string containing JSON (e.g. `str('{"type":"inner",...}')`), **or**
- an already-parsed JSON term (e.g. `obj([...])`) if you want to bypass parsing.

`Rows` is unified with the result list of `row/1` terms.

---

## JSON Join specification

### Required fields

| Field | Type | Meaning |
|---|---|---|
| `left` | string | left table name (as registered in the DB) |
| `right` | string | right table name |
| `on.left` | string | join key column in left table |
| `on.right` | string | join key column in right table |

### Optional fields and defaults

| Field | Default | Notes |
|---|---|---|
| `type` | `"inner"` | `"inner"`, `"left"`, `"right"`, `"full"` |
| `select.left` | `"all"` | `"all"`, string, or array of strings |
| `select.right` | `"all"` | `"all"`, string, or array of strings |
| `where.left` | `{ "all": true }` | filter DSL (below) |
| `where.right` | `{ "all": true }` | filter DSL (below) |
| `opts.limit` | `"all"` | integer or `"all"` |
| `opts.qualify` | `true` | when true, output keys are `q(Alias,Col)` |
| `opts.aliases.left` | `"l"` | alias used for qualification |
| `opts.aliases.right` | `"r"` | alias used for qualification |

### Join types

All joins are **single-key equi-joins**.

- **inner**: only matching pairs
- **left**: all left rows, with `null` fill on the right when unmatched
- **right**: all right rows, with `null` fill on the left when unmatched
- **full**: left + right unmatched included (`null` fill on missing side)

### Ordering and limit
- Rows are produced by scanning the left side in row-id order.
- For `right`/`full`, unmatched right-side rows are appended after matched rows.
- `opts.limit` is applied **after** the join result list is built.

---

## JSON filter language

Filters map into the DB’s internal `filter_indices/3` mechanism.

### Filter forms

#### 1) All rows
```json
{ "all": true }
```

#### 2) Simple predicate
```json
{ "col": "total", "op": "ge", "val": 100 }
```

Supported ops:
- `"eq"`  (equality)
- `"ge"`  (>=)

Any other `op` will fail to match the DB’s comparator.

#### 3) `and`
```json
{ "and": [ F1, F2, F3 ] }
```

#### 4) `or`
```json
{ "or": [ F1, F2 ] }
```

#### 5) `not`
```json
{ "not": F }
```

`not` is implemented as **set subtraction**: `all_rows - matching_rows`.

### Where clause shapes

`where` supports either:
1) per-side object:
```json
"where": {
  "left":  <Filter>,
  "right": <Filter>
}
```

2) a single filter (applies to **left**; right defaults to all):
```json
"where": { "col":"status","op":"eq","val":"open" }
```

---

## Projection (`select`)

Projection supports:
- `"all"`
- a single string column name, e.g. `"name"`
- an array of column names, e.g. `["id","name"]`

`select` itself can be either:
- an object `{ "left": <Proj>, "right": <Proj> }`, or
- a single `<Proj>` applied to **both** sides.

Examples:

```json
"select": { "left":"all", "right":["id","total"] }
```

```json
"select": { "left":"name", "right":"all" }
```

```json
"select": ["id"]   
```

If `select` is omitted, both sides are `"all"`.

---

## Performance tips

1) **Index the right join key**
   The join probes the right table via `eq` on the right join key.
   A `hash` index avoids scanning the whole right table per left row:

   ```prolog
   send(RightTable, create_index(join_key, hash)).
   ```

2) **Prefer `eq` joins**
   Only equality joins are supported. Non-equi joins would require a different index strategy.

3) **Filter early**
   Use `where.left` / `where.right` to reduce candidate row sets before joining.

---

## Limitations (current)

- Joins are **single-key equi-joins only** (`leftKey == rightKey`).
- No multi-key joins (`(a,b) == (x,y)`) yet.
- No aggregation/group-by/order-by.
- JSON float numbers may parse as a non-integer numeric term; `ge` works best with integers.

---

## Troubleshooting

- If `join_json/2` fails:
  - verify `left` and `right` names match `create_table` names exactly
  - verify `on.left` / `on.right` are valid column names
  - verify `op` is `"eq"` or `"ge"`
  - set `"opts":{"qualify":true}` to avoid column-name collisions
