# MiniPrologProto (Java)

A tiny Prolog-style resolution engine (unification + backtracking) written in Java, with built-ins for:

- **JSON ⇄ Term**: `json_parse/2`, `json_stringify/2`
- **JSON ⇄ Java POJO** (reflection): `from_json/3`, `to_json/2`

It’s intentionally small/prototype-flavored, but includes:

- variable standardization-apart
- trail-based undo + choice points
- occurs-check in unification (prevents cyclic terms)
- solution snapshotting (answers don’t “disappear” after backtracking)
- a self-test harness (`--selftest`)

## Quick start

```bash
./build.sh
./demo.sh
```

## Self-tests

```bash
./selftest.sh
```

## Term conventions

### Prolog lists

- `[]` is the empty list
- `.(H,T)` is a cons cell
- Pretty-printer renders lists as `[a,b,c]` and improper lists as `[H|T]`

### JSON terms

`json_parse/2` produces the following term shapes:

- JSON object: `obj(List)` where `List` is a Prolog list of `kv(Key,Val)`
- JSON array:  `arr(List)`
- JSON string: `str(AtomPayload)` and the pretty-printer shows it as a quoted string
- JSON booleans/null: atoms `true`, `false`, `null`
- JSON integers: `NUM`
- JSON floats: `double(Atom("2.5"))`

`json_stringify/2` accepts the same shapes.

## Built-ins

Core:
- `true/0`
- `fail/0`
- `=/2`

JSON:
- `json_parse(JSONText, Term)`
- `json_stringify(Term, JSONText)`

POJO mapping:
- `from_json(JSONText, ClassName, Ref)`
- `to_json(Ref, JSONText)`

Heap hygiene:
- `release_ref(Ref)`
- `clear_heap`
- `heap_size(N)`

## POJO constraints & safety

`from_json/3` only instantiates classes whose names start with one of the prefixes in:

- `ALLOWED_CLASS_PREFIXES` (default allows `com.mycompany.prolog.`)

It uses:

- public no-arg constructor
- public, non-static, non-final fields

## Runtime configuration

You can override a few behaviors using `-D` system properties:

- `-Dprolog.printBuiltinErrors=true|false`
- `-Dprolog.printBuiltinStacktraces=true|false`
- `-Dprolog.builtinExceptionsAreErrors=true|false`

Example:

```bash
java -Dprolog.printBuiltinErrors=false -cp out com.mycompany.prolog.MiniPrologProto --selftest
```

## REPL

This repo includes a small Prolog-ish text parser and interactive REPL:

```bash
./build.sh
./repl.sh          # full stack (OO + ColumnDB + Planner)
./repl.sh --sample # core + sample predicates only
```

Inside the REPL:

- End statements with a dot (`.`)
- Use `:help` for commands (`:consult`, `:stack`, `:reset`, ...)

## GUI IDE

`prolog_ide.py` is a lightweight PyQt-based editor + REPL front-end.

```bash
python3 prolog_ide.py
```

Requires `PyQt6`.
