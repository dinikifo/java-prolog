package com.mycompany.prolog;

import static com.mycompany.prolog.MiniPrologProto.*;

/** CLI smoke test for the JSON-AIML library (no UI). */
public final class JsonAimlSmokeTestMain {
  public static void main(String[] args){
    Obj prog = buildProgramWithSample();
    JsonAimlLib.load(prog);

    // Create bot
    Obj B = Var();
    int vidB = B.get(K_VID);
    var s1 = query(prog, Comp("aiml_new_bot", B));
    Obj bot = s1.get(0).get(vidB);

    String js = "{\"categories\":[{\"pattern\":[\"HELLO\"],\"template\":[{\"t\":\"text\",\"v\":\"HI\"}]}]}";
    boolean ok = solveOnce(Engine(prog.get(K_PREDICATES)), Comp("aiml_load_json_string", bot, Atom(js)));
    if(!ok) throw new RuntimeException("load failed");

    Obj Reply = Var();
    int vidR = Reply.get(K_VID);
    var s2 = query(prog, Comp("aiml_reply", bot, Atom("u1"), Atom("hello"), Reply));
    System.out.println("reply=" + pp(s2.get(0).get(vidR)));
  }
}
