package com.mycompany.prolog;

import static com.mycompany.prolog.MiniPrologProto.*;

/**
 * Tiny column-oriented DB on top of the Prolog OO substrate (OopPrologLib).
 *
 * This is intentionally small: it supports create_table/3, insert/1, select/4,
 * count/2 and hash indexes for equality.
 */
public final class ColumnDbLib {
  private ColumnDbLib(){}

  static Obj conj(Obj... gs){
    if(gs==null || gs.length==0) return Comp("true");
    Obj out = gs[gs.length-1];
    for(int i=gs.length-2;i>=0;i--) out = Comp(",", gs[i], out);
    return out;
  }

  private static void ensurePred(Obj prog, String name, int arity){
    if(getPred(prog.get(K_PREDICATES), name, arity)==null){
      definePred(prog, name, arity, Predicate());
    }
  }

  public static void load(Obj prog){
    // Helpers we rely on (created if absent)
    ensurePred(prog, "member", 2);
    ensurePred(prog, "length", 2);
    ensurePred(prog, "rev", 2);
    ensurePred(prog, "rev_", 3);
    ensurePred(prog, "nth1", 3);
    ensurePred(prog, "numlist", 3);
    ensurePred(prog, "take", 3);
    ensurePred(prog, "kv_get", 3);
    ensurePred(prog, "kv_put", 4);
    ensurePred(prog, "kv_keys", 2);
    ensurePred(prog, "list_intersection", 3);
    ensurePred(prog, "list_union", 3);
    // helpers for JSON joins
    ensurePred(prog, "list_minus", 3);
    ensurePred(prog, "list_append", 3);
    ensurePred(prog, "cmp", 3);

    installListAndKvHelpers(prog);
    installDbInternals(prog);
    installColumnDbInit(prog);
  }

  private static void installListAndKvHelpers(Obj prog){
    // member/2
    {
      Obj X=Var(), T=Var();
      Obj X2=Var(), H=Var(), T2=Var();
      definePred(prog, "member", 2, Predicate(
          Clause(Comp("member", X, listCons(X, T))),
          Clause(Comp("member", X2, listCons(H, T2)), Comp("member", X2, T2))
      ));
    }

    // length/2
    {
      Obj H=Var(), T=Var(), N=Var(), N1=Var();
      definePred(prog, "length", 2, Predicate(
          Clause(Comp("length", listNil(), Num(0))),
          Clause(Comp("length", listCons(H, T), N),
              Comp("length", T, N1),
              Comp("is", N, Comp("+", N1, Num(1))))
      ));
    }

    // rev/2 and rev_/3
    {
      Obj L=Var(), R=Var();
      definePred(prog, "rev", 2, Predicate(
          Clause(Comp("rev", L, R), Comp("rev_", L, listNil(), R))
      ));

      Obj A=Var(), H=Var(), T=Var(), A2=Var(), R2=Var();
      definePred(prog, "rev_", 3, Predicate(
          Clause(Comp("rev_", listNil(), A, A)),
          Clause(Comp("rev_", listCons(H, T), A2, R2),
              Comp("rev_", T, listCons(H, A2), R2))
      ));
    }

    // nth1/3 (N>=1)
    {
      Obj H=Var(), T=Var();
      Obj N=Var(), Ign=Var(), T2=Var(), X=Var(), N1=Var();
      definePred(prog, "nth1", 3, Predicate(
          Clause(Comp("nth1", Num(1), listCons(H, T), H)),
          Clause(Comp("nth1", N, listCons(Ign, T2), X),
              Comp(">", N, Num(1)),
              Comp("is", N1, Comp("-", N, Num(1))),
              Comp("nth1", N1, T2, X))
      ));
    }

    // numlist/3: numlist(Lo,Hi,List)
    {
      Obj Lo=Var(), Hi=Var();
      Obj L=Var();
      Obj Lo2=Var(), Hi2=Var(), Tail=Var(), Lo3=Var();
      definePred(prog, "numlist", 3, Predicate(
          Clause(Comp("numlist", Lo, Hi, listNil()), Comp(">", Lo, Hi)),
          Clause(Comp("numlist", Lo2, Hi2, listCons(Lo2, Tail)),
              Comp("=<", Lo2, Hi2),
              Comp("is", Lo3, Comp("+", Lo2, Num(1))),
              Comp("numlist", Lo3, Hi2, Tail))
      ));
    }

    // take/3
    {
      Obj Any=Var();
      Obj N=Var(), H=Var(), T=Var(), R=Var(), N1=Var();
      definePred(prog, "take", 3, Predicate(
          Clause(Comp("take", Num(0), Any, listNil())),
          Clause(Comp("take", N, listNil(), listNil())),
          Clause(Comp("take", N, listCons(H, T), listCons(H, R)),
              Comp(">", N, Num(0)),
              Comp("is", N1, Comp("-", N, Num(1))),
              Comp("take", N1, T, R))
      ));
    }

    // kv_get/3 for assoc list [K=V,...]
    {
      Obj K=Var(), V=Var(), Tail=Var();
      Obj Any=Var(), T=Var(), K2=Var(), V2=Var();
      definePred(prog, "kv_get", 3, Predicate(
          Clause(Comp("kv_get", listCons(Comp("=", K, V), Tail), K, V)),
          Clause(Comp("kv_get", listCons(Any, T), K2, V2), Comp("kv_get", T, K2, V2))
      ));
    }

    // kv_put/4
    {
      Obj K=Var(), V=Var();
      Obj K1=Var(), Ign=Var(), T1=Var();
      Obj H=Var(), T=Var(), K2=Var(), V2=Var(), T2=Var();
      definePred(prog, "kv_put", 4, Predicate(
          Clause(Comp("kv_put", listNil(), K, V, listCons(Comp("=", K, V), listNil()))),
          Clause(Comp("kv_put", listCons(Comp("=", K1, Ign), T1), K1, V, listCons(Comp("=", K1, V), T1))),
          Clause(Comp("kv_put", listCons(H, T), K2, V2, listCons(H, T2)),
              Comp("kv_put", T, K2, V2, T2))
      ));
    }

    // kv_keys/2
    {
      Obj K=Var(), Ign=Var(), T=Var(), Ks=Var();
      definePred(prog, "kv_keys", 2, Predicate(
          Clause(Comp("kv_keys", listNil(), listNil())),
          Clause(Comp("kv_keys", listCons(Comp("=", K, Ign), T), listCons(K, Ks)),
              Comp("kv_keys", T, Ks))
      ));
    }

    // list_intersection/3 (naive)
    {
      Obj B=Var();
      Obj H=Var(), T=Var(), R=Var();
      definePred(prog, "list_intersection", 3, Predicate(
          Clause(Comp("list_intersection", listNil(), B, listNil())),
          Clause(Comp("list_intersection", listCons(H, T), B, listCons(H, R)),
              Comp("member", H, B),
              Comp("list_intersection", T, B, R)),
          Clause(Comp("list_intersection", listCons(H, T), B, R),
              Comp("\\+", Comp("member", H, B)),
              Comp("list_intersection", T, B, R))
      ));
    }

    // list_union/3 (naive; keeps all of B and adds elements of A not already in B)
    {
      Obj B=Var();
      Obj H=Var(), T=Var(), R=Var();
      definePred(prog, "list_union", 3, Predicate(
          Clause(Comp("list_union", listNil(), B, B)),
          Clause(Comp("list_union", listCons(H, T), B, R),
              Comp("member", H, B),
              Comp("!"),
              Comp("list_union", T, B, R)),
          Clause(Comp("list_union", listCons(H, T), B, listCons(H, R)),
              Comp("\\+", Comp("member", H, B)),
              Comp("list_union", T, B, R))
      ));
    }

    // list_minus/3 (naive set subtraction: A \ B)
    {
      Obj B=Var();
      Obj H=Var(), T=Var(), R=Var();
      definePred(prog, "list_minus", 3, Predicate(
          Clause(Comp("list_minus", listNil(), B, listNil())),
          Clause(Comp("list_minus", listCons(H, T), B, R),
              Comp("member", H, B),
              Comp("!"),
              Comp("list_minus", T, B, R)),
          Clause(Comp("list_minus", listCons(H, T), B, listCons(H, R)),
              Comp("\\+", Comp("member", H, B)),
              Comp("list_minus", T, B, R))
      ));
    }

    // list_append/3 (like append/3, but local)
    {
      Obj H=Var(), T=Var(), B=Var(), R=Var();
      definePred(prog, "list_append", 3, Predicate(
          Clause(Comp("list_append", listNil(), B, B)),
          Clause(Comp("list_append", listCons(H, T), B, listCons(H, R)),
              Comp("list_append", T, B, R))
      ));
    }

    // cmp/3 (eq and ge only; others are easy to add later)
    {
      Obj A=Var(), B=Var();
      Obj A2=Var(), B2=Var();
      definePred(prog, "cmp", 3, Predicate(
          Clause(Comp("cmp", Atom("eq"), A, B), Comp("=", A, B)),
          Clause(Comp("cmp", Atom("ge"), A2, B2), Comp(">=", A2, B2))
      ));
    }
  }

  private static void installDbInternals(Obj prog){
    // row_get(Row,K,V) where Row=row(Pairs)
    {
      Obj Row=Var(), K=Var(), V=Var(), Pairs=Var();
      definePred(prog, "row_get", 3, Predicate(
          Clause(Comp("row_get", Row, K, V),
              Comp("=", Row, Comp("row", Pairs)),
              Comp("kv_get", Pairs, K, V))
      ));
    }

    // table_col(T,CName,CObj)
    {
      Obj T=Var(), C=Var(), CObj=Var(), Cols=Var();
      definePred(prog, "table_col", 3, Predicate(
          Clause(Comp("table_col", T, C, CObj),
              Comp("get", T, Atom("cols"), Cols),
              Comp("kv_get", Cols, C, CObj))
      ));
    }

    // col_values(C,Values) :- get(C,data_rev,R), rev(R,Values).
    {
      Obj C=Var(), Values=Var(), R=Var();
      definePred(prog, "col_values", 2, Predicate(
          Clause(Comp("col_values", C, Values),
              Comp("get", C, Atom("data_rev"), R),
              Comp("rev", R, Values))
      ));
    }

    // column_append(C,Val) updates data_rev
    {
      Obj C=Var(), V=Var(), R0=Var();
      definePred(prog, "column_append", 2, Predicate(
          Clause(Comp("column_append", C, V),
              Comp("get", C, Atom("data_rev"), R0),
              Comp("put", C, Atom("data_rev"), listCons(V, R0)))
      ));
    }

    // hash_index_add/4 for assoc list Value=RevIds
    {
      Obj V=Var(), Row=Var();
      Obj Rs=Var(), T=Var();
      Obj H=Var(), T2=Var(), OutT=Var();

      definePred(prog, "hash_index_add", 4, Predicate(
          Clause(Comp("hash_index_add", listNil(), V, Row,
              listCons(Comp("=", V, listCons(Row, listNil())), listNil()))),
          Clause(Comp("hash_index_add", listCons(Comp("=", V, Rs), T), V, Row,
              listCons(Comp("=", V, listCons(Row, Rs)), T))),
          Clause(Comp("hash_index_add", listCons(H, T2), V, Row, listCons(H, OutT)),
              Comp("hash_index_add", T2, V, Row, OutT))
      ));
    }

    // hash_index_get/3
    {
      Obj Idx=Var(), Key=Var(), RevIds=Var(), Asc=Var();
      definePred(prog, "hash_index_get", 3, Predicate(
          Clause(Comp("hash_index_get", Idx, Key, Asc),
              Comp("kv_get", Idx, Key, RevIds),
              Comp("rev", RevIds, Asc))
      ));
    }

    // column_build_hash_index(C) (uses current contents)
    {
      Obj C=Var(), Vs=Var(), N=Var(), Idx=Var();
      definePred(prog, "column_build_hash_index", 2, Predicate(
          Clause(Comp("column_build_hash_index", C, Idx),
              Comp("col_values", C, Vs),
              Comp("length", Vs, N),
              Comp("build_hash_collect", Num(1), N, Vs, listNil(), Idx))
      ));

      Obj I=Var(), N2=Var(), Vs2=Var(), Acc=Var(), Out=Var();
      Obj V=Var(), Acc1=Var(), I1=Var();
      definePred(prog, "build_hash_collect", 5, Predicate(
          Clause(Comp("build_hash_collect", I, N2, Vs2, Acc, Acc),
              Comp(">", I, N2), Comp("!")),
          Clause(Comp("build_hash_collect", I, N2, Vs2, Acc, Out),
              Comp("nth1", I, Vs2, V),
              Comp("hash_index_add", Acc, V, I, Acc1),
              Comp("is", I1, Comp("+", I, Num(1))),
              Comp("build_hash_collect", I1, N2, Vs2, Acc1, Out))
      ));
    }

    // build_columns(Schema, ColPairs)
    {
      Obj Rest=Var(), Name=Var(), Type=Var(), Opts=Var();
      Obj CObj=Var(), Pairs=Var();
      definePred(prog, "build_columns", 2, Predicate(
          Clause(Comp("build_columns", listNil(), listNil())),
          Clause(Comp("build_columns", listCons(Comp("col", Name, Type, Opts), Rest),
              listCons(Comp("=", Name, CObj), Pairs)),
              Comp("clone", Atom("columnProto"), CObj),
              Comp("put", CObj, Atom("name"), Name),
              Comp("put", CObj, Atom("type"), Type),
              Comp("put", CObj, Atom("opts"), Opts),
              Comp("put", CObj, Atom("data_rev"), listNil()),
              Comp("put", CObj, Atom("index_kind"), Atom("none")),
              Comp("put", CObj, Atom("index_data"), listNil()),
              Comp("build_columns", Rest, Pairs))
      ));
    }

    // insert_cols(Schema, ColsAssoc, Row, RowId)
    {
      Obj Cols=Var(), Row=Var(), RowId=Var();
      Obj Rest=Var(), Name=Var(), Type=Var(), Opts=Var();
      Obj CObj=Var(), Val=Var();
      Obj Kind=Var(), Index0=Var(), Index1=Var();
      definePred(prog, "insert_cols", 4, Predicate(
          Clause(Comp("insert_cols", listNil(), Cols, Row, RowId), Comp("true")),
          Clause(Comp("insert_cols", listCons(Comp("col", Name, Type, Opts), Rest), Cols, Row, RowId),
              Comp("kv_get", Cols, Name, CObj),
              Comp("row_get", Row, Name, Val),
              Comp("column_append", CObj, Val),
              // maintain equality hash index if present
              Comp("get", CObj, Atom("index_kind"), Kind),
              Comp(";",
                  Comp("->",
                      Comp("=", Kind, Atom("hash")),
                      conj(
                          Comp("get", CObj, Atom("index_data"), Index0),
                          Comp("hash_index_add", Index0, Val, RowId, Index1),
                          Comp("put", CObj, Atom("index_data"), Index1)
                      )
                  ),
                  Comp("true")
              ),
              Comp("insert_cols", Rest, Cols, Row, RowId))
      ));
    }

    // schema_colnames/2 and proj_cols/3
    {
      Obj Schema=Var(), Names=Var();
      Obj R=Var(), N=Var(), T=Var(), O=Var(), Ns=Var();
      definePred(prog, "schema_colnames", 2, Predicate(
          Clause(Comp("schema_colnames", listNil(), listNil())),
          Clause(Comp("schema_colnames", listCons(Comp("col", N, T, O), R), listCons(N, Ns)),
              Comp("schema_colnames", R, Ns))
      ));

      Obj Table=Var(), Proj=Var(), ColNames=Var();
      definePred(prog, "proj_cols", 3, Predicate(
          Clause(Comp("proj_cols", Table, Atom("all"), ColNames),
              Comp("get", Table, Atom("schema"), Schema),
              Comp("schema_colnames", Schema, ColNames)),
          Clause(Comp("proj_cols", Table, Proj, Proj),
              Comp("\\+", Comp("=", Proj, Atom("all"))))
      ));
    }

    // filter_indices(Table, Filter, Idxs)
    {
      Obj T=Var(), Filter=Var(), Idxs=Var();
      Obj N=Var();
      Obj C=Var(), Op=Var(), Lit=Var(), Raw=Var();
      Obj F1=Var(), F2=Var(), A=Var(), B=Var();
      Obj F=Var(), All=Var(), Some=Var();
      definePred(prog, "filter_indices", 3, Predicate(
          Clause(Comp("filter_indices", T, Atom("all"), Idxs),
              Comp("get", T, Atom("nrows"), N),
              Comp("numlist", Num(1), N, Idxs)),
          Clause(Comp("filter_indices", T, Comp("where", C, Op, Lit), Raw),
              Comp("pred_indices", T, C, Op, Lit, Raw)),
          Clause(Comp("filter_indices", T, Comp("and", F1, F2), Idxs),
              Comp("filter_indices", T, F1, A),
              Comp("filter_indices", T, F2, B),
              Comp("list_intersection", A, B, Idxs)),
          Clause(Comp("filter_indices", T, Comp("or", F1, F2), Idxs),
              Comp("filter_indices", T, F1, A),
              Comp("filter_indices", T, F2, B),
              Comp("list_union", A, B, Idxs)),
          Clause(Comp("filter_indices", T, Comp("not", F), Idxs),
              Comp("filter_indices", T, Atom("all"), All),
              Comp("filter_indices", T, F, Some),
              Comp("list_minus", All, Some, Idxs))
      ));
    }

    // pred_indices(Table, Col, Op, Lit, Idxs)
    {
      Obj T=Var(), C=Var(), Op=Var(), Lit=Var(), Idxs=Var();
      Obj CObj=Var(), Kind=Var(), Index=Var();
      Obj Vs=Var(), N=Var();
      definePred(prog, "pred_indices", 5, Predicate(
          // hash fast path for eq
          Clause(Comp("pred_indices", T, C, Atom("eq"), Lit, Idxs),
              Comp("table_col", T, C, CObj),
              Comp("get", CObj, Atom("index_kind"), Kind),
              Comp("=", Kind, Atom("hash")),
              Comp("get", CObj, Atom("index_data"), Index),
              Comp(";",
                  Comp("->", Comp("hash_index_get", Index, Lit, Idxs), Comp("true")),
                  Comp("=", Idxs, listNil())
              ),
              Comp("!")
          ),
          // scan fallback for eq and ge
          Clause(Comp("pred_indices", T, C, Op, Lit, Idxs),
              Comp("table_col", T, C, CObj),
              Comp("col_values", CObj, Vs),
              Comp("get", T, Atom("nrows"), N),
              Comp("scan_pred", Num(1), N, Vs, Op, Lit, Idxs)
          )
      ));

      Obj I=Var(), N2=Var(), Vs2=Var(), Op2=Var(), Lit2=Var();
      Obj V=Var(), I1=Var(), Rest=Var();
      definePred(prog, "scan_pred", 6, Predicate(
          Clause(Comp("scan_pred", I, N2, Vs2, Op2, Lit2, listNil()),
              Comp(">", I, N2), Comp("!")),
          Clause(Comp("scan_pred", I, N2, Vs2, Op2, Lit2, listCons(I, Rest)),
              Comp("=<", I, N2),
              Comp("nth1", I, Vs2, V),
              Comp("cmp", Op2, V, Lit2),
              Comp("!"),
              Comp("is", I1, Comp("+", I, Num(1))),
              Comp("scan_pred", I1, N2, Vs2, Op2, Lit2, Rest)),
          Clause(Comp("scan_pred", I, N2, Vs2, Op2, Lit2, Rest),
              Comp("=<", I, N2),
              Comp("is", I1, Comp("+", I, Num(1))),
              Comp("scan_pred", I1, N2, Vs2, Op2, Lit2, Rest))
      ));
    }

    // apply_limit(opts(limit(all|N)), IdxsIn, IdxsOut)
    {
      Obj Opts=Var(), IdxsIn=Var(), IdxsOut=Var(), N=Var();
      definePred(prog, "apply_limit", 3, Predicate(
          Clause(Comp("apply_limit", Comp("opts", Comp("limit", Atom("all"))), IdxsIn, IdxsIn)),
          Clause(Comp("apply_limit", Comp("opts", Comp("limit", N)), IdxsIn, IdxsOut),
              Comp("take", N, IdxsIn, IdxsOut)),
          Clause(Comp("apply_limit", Opts, IdxsIn, IdxsIn))
      ));
    }

    // build_row/build_result_rows
    {
      Obj T=Var(), Cols=Var(), Idxs=Var(), Rows=Var();
      Obj I=Var(), Is=Var(), Row=Var(), Rest=Var(), Pairs=Var();
      definePred(prog, "build_result_rows", 4, Predicate(
          Clause(Comp("build_result_rows", T, Cols, listNil(), listNil())),
          Clause(Comp("build_result_rows", T, Cols, listCons(I, Is), listCons(Row, Rows)),
              Comp("build_row", T, Cols, I, Pairs),
              Comp("=", Row, Comp("row", Pairs)),
              Comp("build_result_rows", T, Cols, Is, Rows))
      ));

      Obj C=Var(), Cs=Var(), V=Var(), Ps=Var(), CObj=Var(), Vs=Var();
      definePred(prog, "build_row", 4, Predicate(
          Clause(Comp("build_row", T, listNil(), I, listNil())),
          Clause(Comp("build_row", T, listCons(C, Cs), I, listCons(Comp("=", C, V), Ps)),
              Comp("table_col", T, C, CObj),
              Comp("col_values", CObj, Vs),
              Comp("nth1", I, Vs, V),
              Comp("build_row", T, Cs, I, Ps))
      ));
    }

    // table_select_impl(Table,Proj,Filter,Opts,Rows)
    {
      Obj T=Var(), Proj=Var(), Filter=Var(), Opts=Var(), Rows=Var();
      Obj Idxs0=Var(), Idxs=Var(), ColNames=Var();
      definePred(prog, "table_select_impl", 5, Predicate(
          Clause(Comp("table_select_impl", T, Proj, Filter, Opts, Rows),
              Comp("filter_indices", T, Filter, Idxs0),
              Comp("apply_limit", Opts, Idxs0, Idxs),
              Comp("proj_cols", T, Proj, ColNames),
              Comp("build_result_rows", T, ColNames, Idxs, Rows))
      ));
    }

    // table_count_impl(Table,Filter,N)
    {
      Obj T=Var(), Filter=Var(), N=Var(), Idxs=Var();
      definePred(prog, "table_count_impl", 3, Predicate(
          Clause(Comp("table_count_impl", T, Filter, N),
              Comp("filter_indices", T, Filter, Idxs),
              Comp("length", Idxs, N))
      ));
    }

    // create_index_impl(Table,Col,hash)
    {
      Obj T=Var(), C=Var(), Kind=Var(), CObj=Var(), Idx=Var();
      definePred(prog, "create_index_impl", 3, Predicate(
          Clause(Comp("create_index_impl", T, C, Atom("hash")),
              Comp("table_col", T, C, CObj),
              Comp("column_build_hash_index", CObj, Idx),
              Comp("put", CObj, Atom("index_kind"), Atom("hash")),
              Comp("put", CObj, Atom("index_data"), Idx)),
          Clause(Comp("create_index_impl", T, C, Kind), Comp("true"))
      ));
    }

    // --- JSON join DSL + join execution ---

    // jkv_get/3 for JSON kv list [kv(Key,Val), ...]
    {
      Obj K=Var(), V=Var(), Tail=Var();
      Obj Any=Var(), T=Var(), K2=Var(), V2=Var();
      definePred(prog, "jkv_get", 3, Predicate(
          Clause(Comp("jkv_get", listCons(Comp("kv", K, V), Tail), K, V)),
          Clause(Comp("jkv_get", listCons(Any, T), K2, V2), Comp("jkv_get", T, K2, V2))
      ));
    }

    // jobj_get/3: jobj_get(obj(KVs), Key, Val)
    {
      Obj KVs=Var(), K=Var(), V=Var();
      definePred(prog, "jobj_get", 3, Predicate(
          Clause(Comp("jobj_get", Comp("obj", KVs), K, V), Comp("jkv_get", KVs, K, V))
      ));
    }

    // jobj_get_default/4
    {
      Obj O=Var(), K=Var(), Def=Var(), V=Var();
      definePred(prog, "jobj_get_default", 4, Predicate(
          Clause(Comp("jobj_get_default", O, K, Def, V),
              Comp("jobj_get", O, K, V),
              Comp("!")),
          Clause(Comp("jobj_get_default", O, K, Def, Def))
      ));
    }

    // json_atom/2: map JSON string term str(A) to atom A; pass through otherwise
    {
      Obj A=Var(), X=Var();
      definePred(prog, "json_atom", 2, Predicate(
          Clause(Comp("json_atom", Comp("str", A), A), Comp("!")),
          Clause(Comp("json_atom", X, X))
      ));
    }

    // json_lit/2: map JSON literals (str -> atom; numbers/bools/null passthrough)
    {
      Obj A=Var(), X=Var();
      definePred(prog, "json_lit", 2, Predicate(
          Clause(Comp("json_lit", Comp("str", A), A), Comp("!")),
          Clause(Comp("json_lit", X, X))
      ));
    }

    // json_arr_list/2: json_arr_list(arr(L), L)
    {
      Obj L=Var();
      definePred(prog, "json_arr_list", 2, Predicate(
          Clause(Comp("json_arr_list", Comp("arr", L), L))
      ));
    }

    // json_terms_to_atoms/2: map list of JSON terms to list of atoms
    {
      Obj H=Var(), T=Var(), A=Var(), R=Var();
      definePred(prog, "json_terms_to_atoms", 2, Predicate(
          Clause(Comp("json_terms_to_atoms", listNil(), listNil())),
          Clause(Comp("json_terms_to_atoms", listCons(H, T), listCons(A, R)),
              Comp("json_atom", H, A),
              Comp("json_terms_to_atoms", T, R))
      ));
    }

    // proj_from_json/2: JSON projection -> Prolog projection (all or list of atoms)
    {
      Obj J=Var(), P=Var(), L=Var(), A=Var();
      definePred(prog, "proj_from_json", 2, Predicate(
          Clause(Comp("proj_from_json", Atom("null"), Atom("all")), Comp("!")),
          Clause(Comp("proj_from_json", Comp("str", Atom("all")), Atom("all")), Comp("!")),
          Clause(Comp("proj_from_json", Comp("arr", L), P),
              Comp("json_terms_to_atoms", L, P),
              Comp("!")),
          Clause(Comp("proj_from_json", Comp("str", A), listCons(A, listNil())),
              Comp("\\+", Comp("=", A, Atom("all"))),
              Comp("!")),
          Clause(Comp("proj_from_json", J, Atom("all")))
      ));
    }

    // limit_from_json/2: JSON limit -> all|N
    {
      Obj J=Var(), L=Var();
      definePred(prog, "limit_from_json", 2, Predicate(
          Clause(Comp("limit_from_json", Atom("null"), Atom("all")), Comp("!")),
          Clause(Comp("limit_from_json", Comp("str", Atom("all")), Atom("all")), Comp("!")),
          Clause(Comp("limit_from_json", J, J))
      ));
    }

    // filters_from_json_list/2
    {
      Obj H=Var(), T=Var(), F=Var(), Fs=Var();
      definePred(prog, "filters_from_json_list", 2, Predicate(
          Clause(Comp("filters_from_json_list", listNil(), listNil())),
          Clause(Comp("filters_from_json_list", listCons(H, T), listCons(F, Fs)),
              Comp("filter_from_json", H, F),
              Comp("filters_from_json_list", T, Fs))
      ));
    }

    // fold_and/2 and fold_or/2 (n-ary)
    {
      Obj L=Var(), F=Var(), F1=Var(), F2=Var(), Rest=Var();
      definePred(prog, "fold_and", 2, Predicate(
          Clause(Comp("fold_and", listNil(), Atom("all")), Comp("!")),
          Clause(Comp("fold_and", listCons(F, listNil()), F), Comp("!")),
          Clause(Comp("fold_and", listCons(F1, listCons(F2, Rest)), Comp("and", F1, F)),
              Comp("fold_and", listCons(F2, Rest), F))
      ));

      definePred(prog, "fold_or", 2, Predicate(
          Clause(Comp("fold_or", listNil(), Atom("all")), Comp("!")),
          Clause(Comp("fold_or", listCons(F, listNil()), F), Comp("!")),
          Clause(Comp("fold_or", listCons(F1, listCons(F2, Rest)), Comp("or", F1, F)),
              Comp("fold_or", listCons(F2, Rest), F))
      ));
    }

    // filter_from_json/2: JSON filter DSL -> DB filter term
    {
      Obj J=Var(), F=Var();
      Obj Arr=Var(), L=Var(), Fs=Var(), Folded=Var();
      Obj Sub=Var(), ColJ=Var(), OpJ=Var(), ValJ=Var();
      Obj Col=Var(), Op=Var(), Lit=Var();
      definePred(prog, "filter_from_json", 2, Predicate(
          Clause(Comp("filter_from_json", Atom("null"), Atom("all")), Comp("!")),
          Clause(Comp("filter_from_json", J, Atom("all")),
              Comp("jobj_get", J, Atom("all"), Atom("true")),
              Comp("!")),
          Clause(Comp("filter_from_json", J, Folded),
              Comp("jobj_get", J, Atom("and"), Arr),
              Comp("json_arr_list", Arr, L),
              Comp("filters_from_json_list", L, Fs),
              Comp("fold_and", Fs, Folded),
              Comp("!")),
          Clause(Comp("filter_from_json", J, Folded),
              Comp("jobj_get", J, Atom("or"), Arr),
              Comp("json_arr_list", Arr, L),
              Comp("filters_from_json_list", L, Fs),
              Comp("fold_or", Fs, Folded),
              Comp("!")),
          Clause(Comp("filter_from_json", J, Comp("not", F)),
              Comp("jobj_get", J, Atom("not"), Sub),
              Comp("filter_from_json", Sub, F),
              Comp("!")),
          Clause(Comp("filter_from_json", J, Comp("where", Col, Op, Lit)),
              Comp("jobj_get", J, Atom("col"), ColJ),
              Comp("jobj_get", J, Atom("op"), OpJ),
              Comp("jobj_get", J, Atom("val"), ValJ),
              Comp("json_atom", ColJ, Col),
              Comp("json_atom", OpJ, Op),
              Comp("json_lit", ValJ, Lit))
      ));
    }

    // select_from_json/3: JSON select -> LProj/RProj
    {
      Obj J=Var(), L=Var(), R=Var(), JL=Var(), JR=Var();
      definePred(prog, "select_from_json", 3, Predicate(
          Clause(Comp("select_from_json", Atom("null"), Atom("all"), Atom("all")), Comp("!")),
          Clause(Comp("select_from_json", J, L, R),
              Comp("jobj_get", J, Atom("left"), JL),
              Comp("!"),
              Comp("proj_from_json", JL, L),
              Comp("jobj_get_default", J, Atom("right"), Atom("null"), JR),
              Comp("proj_from_json", JR, R)),
          Clause(Comp("select_from_json", J, L, R),
              Comp("proj_from_json", J, L),
              Comp("proj_from_json", J, R))
      ));
    }

    // where_from_json/3: JSON where -> FL/FR (supports {left:..., right:...} or a single filter for left)
    {
      Obj J=Var(), FL=Var(), FR=Var(), JL=Var(), JR=Var();
      definePred(prog, "where_from_json", 3, Predicate(
          Clause(Comp("where_from_json", Atom("null"), Atom("all"), Atom("all")), Comp("!")),
          Clause(Comp("where_from_json", J, FL, FR),
              Comp("jobj_get", J, Atom("left"), JL),
              Comp("!"),
              Comp("filter_from_json", JL, FL),
              Comp("jobj_get_default", J, Atom("right"), Atom("null"), JR),
              Comp("filter_from_json", JR, FR)),
          Clause(Comp("where_from_json", J, FL, Atom("all")),
              Comp("filter_from_json", J, FL))
      ));
    }

    // aliases_from_json/3
    {
      Obj J=Var(), LA=Var(), RA=Var(), JL=Var(), JR=Var();
      definePred(prog, "aliases_from_json", 3, Predicate(
          Clause(Comp("aliases_from_json", Atom("null"), Atom("l"), Atom("r")), Comp("!")),
          Clause(Comp("aliases_from_json", J, LA, RA),
              Comp("jobj_get_default", J, Atom("left"), Comp("str", Atom("l")), JL),
              Comp("jobj_get_default", J, Atom("right"), Comp("str", Atom("r")), JR),
              Comp("json_atom", JL, LA),
              Comp("json_atom", JR, RA))
      ));
    }

    // opts_from_json/5: JSON opts -> Limit, Qualify, LA, RA
    {
      Obj J=Var(), Limit=Var(), Qualify=Var(), LA=Var(), RA=Var();
      Obj LimJ=Var(), AliJ=Var();
      definePred(prog, "opts_from_json", 5, Predicate(
          Clause(Comp("opts_from_json", Atom("null"), Atom("all"), Atom("true"), Atom("l"), Atom("r")), Comp("!")),
          Clause(Comp("opts_from_json", J, Limit, Qualify, LA, RA),
              Comp("jobj_get_default", J, Atom("limit"), Comp("str", Atom("all")), LimJ),
              Comp("limit_from_json", LimJ, Limit),
              Comp("jobj_get_default", J, Atom("qualify"), Atom("true"), Qualify),
              Comp("jobj_get_default", J, Atom("aliases"), Atom("null"), AliJ),
              Comp("aliases_from_json", AliJ, LA, RA))
      ));
    }

    // join_spec_from_json/2
    {
      Obj J=Var();
      Obj TypeJ=Var(), Type=Var();
      Obj LNameJ=Var(), RNameJ=Var(), LName=Var(), RName=Var();
      Obj OnJ=Var(), LKJ=Var(), RKJ=Var(), LK=Var(), RK=Var();
      Obj SelJ=Var(), WhereJ=Var(), OptsJ=Var();
      Obj LProj=Var(), RProj=Var(), FL=Var(), FR=Var();
      Obj Limit=Var(), Qualify=Var(), LA=Var(), RA=Var();
      Obj Spec=Var();
      definePred(prog, "join_spec_from_json", 2, Predicate(
          Clause(Comp("join_spec_from_json", J, Spec),
              Comp("jobj_get_default", J, Atom("type"), Comp("str", Atom("inner")), TypeJ),
              Comp("json_atom", TypeJ, Type),
              Comp("jobj_get", J, Atom("left"), LNameJ),
              Comp("jobj_get", J, Atom("right"), RNameJ),
              Comp("json_atom", LNameJ, LName),
              Comp("json_atom", RNameJ, RName),
              Comp("jobj_get", J, Atom("on"), OnJ),
              Comp("jobj_get", OnJ, Atom("left"), LKJ),
              Comp("jobj_get", OnJ, Atom("right"), RKJ),
              Comp("json_atom", LKJ, LK),
              Comp("json_atom", RKJ, RK),
              Comp("jobj_get_default", J, Atom("select"), Atom("null"), SelJ),
              Comp("select_from_json", SelJ, LProj, RProj),
              Comp("jobj_get_default", J, Atom("where"), Atom("null"), WhereJ),
              Comp("where_from_json", WhereJ, FL, FR),
              Comp("jobj_get_default", J, Atom("opts"), Atom("null"), OptsJ),
              Comp("opts_from_json", OptsJ, Limit, Qualify, LA, RA),
              Comp("=", Spec, Comp("join_spec", Type, LName, RName, LK, RK, LProj, RProj, FL, FR, Limit, Qualify, LA, RA))
          )
      ));
    }

    // table_cell/4: table_cell(T, Col, RowId, Val)
    {
      Obj T=Var(), C=Var(), I=Var(), V=Var(), CObj=Var(), Vs=Var();
      definePred(prog, "table_cell", 4, Predicate(
          Clause(Comp("table_cell", T, C, I, V),
              Comp("table_col", T, C, CObj),
              Comp("col_values", CObj, Vs),
              Comp("nth1", I, Vs, V))
      ));
    }

    // qualify_pairs/3: qualify_pairs(Alias, [K=V,...], [q(Alias,K)=V,...])
    {
      Obj Alias=Var(), K=Var(), V=Var(), T=Var(), R=Var();
      definePred(prog, "qualify_pairs", 3, Predicate(
          Clause(Comp("qualify_pairs", Alias, listNil(), listNil())),
          Clause(Comp("qualify_pairs", Alias, listCons(Comp("=", K, V), T), listCons(Comp("=", Comp("q", Alias, K), V), R)),
              Comp("qualify_pairs", Alias, T, R))
      ));
    }

    // maybe_qualify/4
    {
      Obj Q=Var(), Alias=Var(), In=Var(), Out=Var();
      definePred(prog, "maybe_qualify", 4, Predicate(
          Clause(Comp("maybe_qualify", Atom("true"), Alias, In, Out),
              Comp("qualify_pairs", Alias, In, Out),
              Comp("!")),
          Clause(Comp("maybe_qualify", Q, Alias, In, In))
      ));
    }

    // build_null_pairs/2
    {
      Obj Cs=Var(), C=Var(), Rest=Var(), Out=Var();
      definePred(prog, "build_null_pairs", 2, Predicate(
          Clause(Comp("build_null_pairs", listNil(), listNil())),
          Clause(Comp("build_null_pairs", listCons(C, Cs), listCons(Comp("=", C, Atom("null")), Out)),
              Comp("build_null_pairs", Cs, Out))
      ));
    }

    // join type helpers
    {
      Obj T=Var();
      definePred(prog, "is_leftish_join", 1, Predicate(
          Clause(Comp("is_leftish_join", Atom("left"))),
          Clause(Comp("is_leftish_join", Atom("full")))
      ));
      definePred(prog, "is_rightish_join", 1, Predicate(
          Clause(Comp("is_rightish_join", Atom("right"))),
          Clause(Comp("is_rightish_join", Atom("full")))
      ));
    }

    // join_rmatches_loop/7
    {
      Obj Js=Var(), RT=Var(), RCols=Var(), Q=Var(), RA=Var(), LPairsQ=Var(), Rows=Var();
      Obj J=Var(), Rest=Var(), RPairs=Var(), RPairsQ=Var(), Pairs=Var(), Row=Var(), More=Var();
      definePred(prog, "join_rmatches_loop", 7, Predicate(
          Clause(Comp("join_rmatches_loop", listNil(), RT, RCols, Q, RA, LPairsQ, listNil())),
          Clause(Comp("join_rmatches_loop", listCons(J, Js), RT, RCols, Q, RA, LPairsQ, listCons(Row, Rows)),
              Comp("build_row", RT, RCols, J, RPairs),
              Comp("maybe_qualify", Q, RA, RPairs, RPairsQ),
              Comp("list_append", LPairsQ, RPairsQ, Pairs),
              Comp("=", Row, Comp("row", Pairs)),
              Comp("join_rmatches_loop", Js, RT, RCols, Q, RA, LPairsQ, Rows))
      ));
    }

    // join_rows_for_left/10
    {
      Obj Type=Var(), RT=Var(), RCols=Var(), Q=Var(), RA=Var();
      Obj LPairsQ=Var(), RMatches=Var();
      Obj RowsOut=Var(), Matched=Var();
      Obj RNull=Var(), RNullQ=Var(), Pairs=Var(), Row=Var();
      definePred(prog, "join_rows_for_left", 10, Predicate(
          // no matches -> left/full include, otherwise skip
          Clause(Comp("join_rows_for_left", Type, RT, RCols, Q, RA, LPairsQ, listNil(), listCons(Row, listNil()), listNil(), Atom("left")),
              Comp("is_leftish_join", Type),
              Comp("build_null_pairs", RCols, RNull),
              Comp("maybe_qualify", Q, RA, RNull, RNullQ),
              Comp("list_append", LPairsQ, RNullQ, Pairs),
              Comp("=", Row, Comp("row", Pairs)),
              Comp("!")),
          Clause(Comp("join_rows_for_left", Type, RT, RCols, Q, RA, LPairsQ, listNil(), listNil(), listNil(), Atom("skip")),
              Comp("!")),
          // matches -> cross product
          Clause(Comp("join_rows_for_left", Type, RT, RCols, Q, RA, LPairsQ, RMatches, RowsOut, Matched, Atom("match")),
              Comp("join_rmatches_loop", RMatches, RT, RCols, Q, RA, LPairsQ, RowsOut),
              Comp("=", Matched, RMatches))
      ));
    }

    // join_scan_left/14
    {
      Obj Type=Var(), LT=Var(), RT=Var(), LK=Var(), RK=Var();
      Obj LCols=Var(), RCols=Var(), LIdxs=Var(), RIdxs=Var();
      Obj Q=Var(), LA=Var(), RA=Var(), Rows=Var(), Matched=Var();
      Obj I=Var(), Is=Var(), V=Var();
      Obj R0=Var(), RMatches=Var();
      Obj LPairs=Var(), LPairsQ=Var();
      Obj RowsForI=Var(), RowsRest=Var();
      Obj MatchedForI=Var(), MatchedRest=Var();
      definePred(prog, "join_scan_left", 14, Predicate(
          Clause(Comp("join_scan_left", Type, LT, RT, LK, RK, LCols, RCols, listNil(), RIdxs, Q, LA, RA, listNil(), listNil())),
          Clause(Comp("join_scan_left", Type, LT, RT, LK, RK, LCols, RCols, listCons(I, Is), RIdxs, Q, LA, RA, Rows, Matched),
              Comp("table_cell", LT, LK, I, V),
              Comp("pred_indices", RT, RK, Atom("eq"), V, R0),
              Comp("list_intersection", R0, RIdxs, RMatches),
              Comp("build_row", LT, LCols, I, LPairs),
              Comp("maybe_qualify", Q, LA, LPairs, LPairsQ),
              // build rows for this left id
              Comp(";",
                  Comp("->",
                      Comp("=", RMatches, listNil()),
                      conj(
                          Comp("jlf_unmatched", Type, RT, RCols, Q, RA, LPairsQ, RowsForI, MatchedForI)
                      )
                  ),
                  conj(
                      Comp("join_rmatches_loop", RMatches, RT, RCols, Q, RA, LPairsQ, RowsForI),
                      Comp("=", MatchedForI, RMatches)
                  )
              ),
              Comp("join_scan_left", Type, LT, RT, LK, RK, LCols, RCols, Is, RIdxs, Q, LA, RA, RowsRest, MatchedRest),
              Comp("list_append", RowsForI, RowsRest, Rows),
              Comp("list_union", MatchedForI, MatchedRest, Matched))
      ));
    }

    // helper for left-unmatched case during join_scan_left
    {
      Obj Type=Var(), RT=Var(), RCols=Var(), Q=Var(), RA=Var(), LPairsQ=Var();
      Obj RowsForI=Var(), MatchedForI=Var();
      Obj RNull=Var(), RNullQ=Var(), Pairs=Var(), Row=Var();
      definePred(prog, "jlf_unmatched", 8, Predicate(
          Clause(Comp("jlf_unmatched", Type, RT, RCols, Q, RA, LPairsQ, listCons(Row, listNil()), listNil()),
              Comp("is_leftish_join", Type),
              Comp("build_null_pairs", RCols, RNull),
              Comp("maybe_qualify", Q, RA, RNull, RNullQ),
              Comp("list_append", LPairsQ, RNullQ, Pairs),
              Comp("=", Row, Comp("row", Pairs)),
              Comp("!")),
          Clause(Comp("jlf_unmatched", Type, RT, RCols, Q, RA, LPairsQ, listNil(), listNil()))
      ));
    }

    // build_rows_right_only/7
    {
      Obj Idxs=Var(), RT=Var(), RCols=Var(), Q=Var(), RA=Var(), LNullQ=Var(), Rows=Var();
      Obj I=Var(), Is=Var(), RPairs=Var(), RPairsQ=Var(), Pairs=Var(), Row=Var(), Rest=Var();
      definePred(prog, "build_rows_right_only", 7, Predicate(
          Clause(Comp("build_rows_right_only", listNil(), RT, RCols, Q, RA, LNullQ, listNil())),
          Clause(Comp("build_rows_right_only", listCons(I, Is), RT, RCols, Q, RA, LNullQ, listCons(Row, Rows)),
              Comp("build_row", RT, RCols, I, RPairs),
              Comp("maybe_qualify", Q, RA, RPairs, RPairsQ),
              Comp("list_append", LNullQ, RPairsQ, Pairs),
              Comp("=", Row, Comp("row", Pairs)),
              Comp("build_rows_right_only", Is, RT, RCols, Q, RA, LNullQ, Rows))
      ));
    }

    // join_right_unmatched/11
    {
      Obj Type=Var(), LT=Var(), RT=Var(), LCols=Var(), RCols=Var();
      Obj RIdxs=Var(), MatchedR=Var(), Q=Var(), LA=Var(), RA=Var(), Rows=Var();
      Obj Unmatched=Var(), LNull=Var(), LNullQ=Var();
      definePred(prog, "join_right_unmatched", 11, Predicate(
          Clause(Comp("join_right_unmatched", Type, LT, RT, LCols, RCols, RIdxs, MatchedR, Q, LA, RA, Rows),
              Comp("is_rightish_join", Type),
              Comp("list_minus", RIdxs, MatchedR, Unmatched),
              Comp("build_null_pairs", LCols, LNull),
              Comp("maybe_qualify", Q, LA, LNull, LNullQ),
              Comp("build_rows_right_only", Unmatched, RT, RCols, Q, RA, LNullQ, Rows),
              Comp("!")),
          Clause(Comp("join_right_unmatched", Type, LT, RT, LCols, RCols, RIdxs, MatchedR, Q, LA, RA, listNil()))
      ));
    }

    // apply_limit_rows/3
    {
      Obj Limit=Var(), In=Var(), Out=Var();
      definePred(prog, "apply_limit_rows", 3, Predicate(
          Clause(Comp("apply_limit_rows", Atom("all"), In, In), Comp("!")),
          Clause(Comp("apply_limit_rows", Limit, In, Out),
              Comp("take", Limit, In, Out),
              Comp("!")),
          Clause(Comp("apply_limit_rows", Limit, In, In))
      ));
    }

    // db_join_spec_impl(DB, join_spec(...), Rows)
    {
      Obj DB=Var(), Spec=Var(), Rows=Var();
      Obj Type=Var(), LName=Var(), RName=Var(), LK=Var(), RK=Var();
      Obj LProj=Var(), RProj=Var(), FL=Var(), FR=Var();
      Obj Limit=Var(), Q=Var(), LA=Var(), RA=Var();
      Obj LT=Var(), RT=Var();
      Obj LCols=Var(), RCols=Var();
      Obj LIdxs=Var(), RIdxs=Var();
      Obj RowsLeft=Var(), MatchedR=Var(), RowsRight=Var(), RowsAll=Var();
      Obj RowsLimited=Var();
      definePred(prog, "db_join_spec_impl", 3, Predicate(
          Clause(Comp("db_join_spec_impl", DB, Spec, Rows),
              Comp("=", Spec, Comp("join_spec", Type, LName, RName, LK, RK, LProj, RProj, FL, FR, Limit, Q, LA, RA)),
              Comp("send", DB, Comp("table", LName, LT)),
              Comp("send", DB, Comp("table", RName, RT)),
              Comp("proj_cols", LT, LProj, LCols),
              Comp("proj_cols", RT, RProj, RCols),
              Comp("filter_indices", LT, FL, LIdxs),
              Comp("filter_indices", RT, FR, RIdxs),
              Comp("join_scan_left", Type, LT, RT, LK, RK, LCols, RCols, LIdxs, RIdxs, Q, LA, RA, RowsLeft, MatchedR),
              Comp("join_right_unmatched", Type, LT, RT, LCols, RCols, RIdxs, MatchedR, Q, LA, RA, RowsRight),
              Comp("list_append", RowsLeft, RowsRight, RowsAll),
              Comp("apply_limit_rows", Limit, RowsAll, RowsLimited),
              Comp("=", Rows, RowsLimited))
      ));
    }

    
  }

  private static void installColumnDbInit(Obj prog){
    Obj Self=Var();
    Obj Name=Var(), Schema=Var(), Table=Var();
    Obj Ts0=Var(), Ts1=Var(), ColPairs=Var();
    Obj Names=Var();
    Obj DescName=Var(), TDesc=Var(), DescSchema=Var();
    Obj JoinJson=Var(), JoinParsed=Var(), JoinSpec=Var(), JoinRows=Var();
    Obj Row=Var(), N0=Var(), RowId=Var(), Cols=Var(), Rows=Var();
    Obj Proj=Var(), Filter=Var(), Opts=Var();
    Obj ColName=Var(), Kind=Var();

    Obj initBody = conj(
        Comp("oop_ready"),
        // prototypes
        Comp("retract_all", Comp("proto", Atom("dbProto"), Var())),
        Comp("retract_all", Comp("proto", Atom("tableProto"), Var())),
        Comp("retract_all", Comp("proto", Atom("columnProto"), Var())),
        Comp("assertz", Comp("proto", Atom("dbProto"), Atom("objectProto"))),
        Comp("assertz", Comp("proto", Atom("tableProto"), Atom("objectProto"))),
        Comp("assertz", Comp("proto", Atom("columnProto"), Atom("objectProto"))),
        // default slots
        Comp("put", Atom("dbProto"), Atom("tables"), listNil()),
        Comp("put", Atom("columnProto"), Atom("data_rev"), listNil()),
        Comp("put", Atom("columnProto"), Atom("index_kind"), Atom("none")),
        Comp("put", Atom("columnProto"), Atom("index_data"), listNil()),

        // DB methods
        Comp("defmethod", Atom("dbProto"), Comp("create_table", Name, Schema, Table), Self,
            conj(
                Comp("clone", Atom("tableProto"), Table),
                Comp("put", Table, Atom("name"), Name),
                Comp("put", Table, Atom("schema"), Schema),
                Comp("build_columns", Schema, ColPairs),
                Comp("put", Table, Atom("cols"), ColPairs),
                Comp("put", Table, Atom("nrows"), Num(0)),
                Comp("get", Self, Atom("tables"), Ts0),
                Comp("kv_put", Ts0, Name, Table, Ts1),
                Comp("put", Self, Atom("tables"), Ts1)
            )
        ),

        Comp("defmethod", Atom("dbProto"), Comp("table", Name, Table), Self,
            conj(
                Comp("get", Self, Atom("tables"), Ts0),
                Comp("kv_get", Ts0, Name, Table)
            )
        ),

        Comp("defmethod", Atom("dbProto"), Comp("list_tables", Names), Self,
            conj(
                Comp("get", Self, Atom("tables"), Ts0),
                Comp("kv_keys", Ts0, Names)
            )
        ),

        Comp("defmethod", Atom("dbProto"), Comp("describe_table", DescName, DescSchema), Self,
            conj(
                Comp("get", Self, Atom("tables"), Ts0),
                Comp("kv_get", Ts0, DescName, TDesc),
                Comp("get", TDesc, Atom("schema"), DescSchema)
            )
        ),

        // Join via JSON DSL (string or already-parsed JSON term)
        // send(DB, join_json(Json, Rows)).
        // Json example:
        // {"type":"left","left":"users","right":"orders","on":{"left":"id","right":"user_id"},
        //  "select":{"left":["id","name"],"right":["id","total"]},
        //  "where":{"right":{"col":"total","op":"ge","val":100}},
        //  "opts":{"qualify":true,"aliases":{"left":"u","right":"o"},"limit":10}}
        Comp("defmethod", Atom("dbProto"), Comp("join_json", JoinJson, JoinRows), Self,
            conj(
                Comp(";",
                    conj(Comp("json_parse", JoinJson, JoinParsed), Comp("!")),
                    Comp("=", JoinParsed, JoinJson)
                ),
                Comp("join_spec_from_json", JoinParsed, JoinSpec),
                Comp("db_join_spec_impl", Self, JoinSpec, JoinRows)
            )
        ),

        // Table methods
        Comp("defmethod", Atom("tableProto"), Comp("insert", Row), Self,
            conj(
                Comp("get", Self, Atom("nrows"), N0),
                Comp("is", RowId, Comp("+", N0, Num(1))),
                Comp("get", Self, Atom("schema"), Schema),
                Comp("get", Self, Atom("cols"), Cols),
                Comp("insert_cols", Schema, Cols, Row, RowId),
                Comp("put", Self, Atom("nrows"), RowId)
            )
        ),

        Comp("defmethod", Atom("tableProto"), Comp("insert_many", Rows), Self,
            Comp("insert_many_", Self, Rows)
        ),

        Comp("defmethod", Atom("tableProto"), Comp("select", Proj, Filter, Opts, Rows), Self,
            Comp("table_select_impl", Self, Proj, Filter, Opts, Rows)
        ),

        Comp("defmethod", Atom("tableProto"), Comp("count", Filter, N0), Self,
            Comp("table_count_impl", Self, Filter, N0)
        ),

        Comp("defmethod", Atom("tableProto"), Comp("create_index", ColName, Kind), Self,
            Comp("create_index_impl", Self, ColName, Kind)
        )
    );

    // insert_many_/2 helper
    {
      Obj T=Var(), R=Var(), Rs=Var();
      definePred(prog, "insert_many_", 2, Predicate(
          Clause(Comp("insert_many_", T, listNil()), Comp("true")),
          Clause(Comp("insert_many_", T, listCons(R, Rs)),
              Comp("send", T, Comp("insert", R)),
              Comp("insert_many_", T, Rs))
      ));
    }

    definePred(prog, "columndb_init", 0, Predicate(
        Clause(Comp("columndb_init"), initBody)
    ));
  }
}
