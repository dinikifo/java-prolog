package com.mycompany.prolog;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.awt.*;
import java.awt.event.*;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;

/**
 * JsonAimlStudioMain - Swing desktop editor/tester for JSON-AIML datasets and bots.
 *
 * Run:
 *   javac -d out $(find src -name "*.java")
 *   java -cp out com.mycompany.prolog.JsonAimlStudioMain
 */
public final class JsonAimlStudioMain {

  static final class BotHandle {
    final MiniPrologProto.Obj term;
    final String label;
    BotHandle(MiniPrologProto.Obj term){
      this.term = term;
      this.label = MiniPrologProto.pp(term);
    }
    @Override public String toString(){ return label; }
  }

  private final MiniPrologProto.Obj prog;

  private JFrame frame;
  private JTextArea jsonArea;
  private JTextArea chatArea;
  private JTextField userField;
  private JTextField inputField;
  private JButton sendBtn;
  private JButton loadBtn;
  private JButton newBotBtn;
  private JButton clearBotBtn;
  private JButton validateBtn;
  private JLabel statsLabel;

  private JComboBox<BotHandle> botCombo;

  private java.nio.file.Path currentFile;

  public JsonAimlStudioMain(){
    // Build a minimal program (true/fail/=/sample preds) + JSON-AIML lib.
    prog = MiniPrologProto.buildProgramWithSample();
    JsonAimlLib.load(prog);
  }

  public void show(){
    frame = new JFrame("JSON-AIML Studio (Prolog-based)");
    frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
    frame.setLayout(new BorderLayout());

    frame.setJMenuBar(buildMenuBar());

    JSplitPane mainSplit = new JSplitPane(JSplitPane.VERTICAL_SPLIT);
    mainSplit.setResizeWeight(0.60);

    // Top: dataset editor
    mainSplit.setTopComponent(buildDatasetPanel());

    // Bottom: chat
    mainSplit.setBottomComponent(buildChatPanel());

    frame.add(mainSplit, BorderLayout.CENTER);
    frame.add(buildRightPanel(), BorderLayout.EAST);

    frame.setSize(1200, 800);
    frame.setLocationRelativeTo(null);
    frame.setVisible(true);

    ensureBotExists();
    refreshStats();
  }

  private JMenuBar buildMenuBar(){
    JMenuBar mb = new JMenuBar();
    JMenu file = new JMenu("File");

    JMenuItem n = new JMenuItem("New Dataset");
    n.addActionListener(e -> {
      jsonArea.setText(defaultDataset());
      currentFile = null;
      frame.setTitle("JSON-AIML Studio (Prolog-based)");
    });

    JMenuItem open = new JMenuItem("Open...");
    open.addActionListener(e -> openJsonFile());

    JMenuItem save = new JMenuItem("Save");
    save.addActionListener(e -> saveJsonFile(false));

    JMenuItem saveAs = new JMenuItem("Save As...");
    saveAs.addActionListener(e -> saveJsonFile(true));

    JMenuItem exit = new JMenuItem("Exit");
    exit.addActionListener(e -> frame.dispose());

    file.add(n);
    file.add(open);
    file.addSeparator();
    file.add(save);
    file.add(saveAs);
    file.addSeparator();
    file.add(exit);

    mb.add(file);
    return mb;
  }

  private Component buildDatasetPanel(){
    JPanel p = new JPanel(new BorderLayout());
    p.setBorder(new EmptyBorder(8,8,8,8));

    JLabel title = new JLabel("Dataset (JSON)");
    title.setFont(title.getFont().deriveFont(Font.BOLD, 14f));

    jsonArea = new JTextArea(defaultDataset());
    jsonArea.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 12));
    JScrollPane sp = new JScrollPane(jsonArea);

    JPanel top = new JPanel(new BorderLayout());
    top.add(title, BorderLayout.WEST);

    JPanel btns = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
    validateBtn = new JButton("Validate JSON");
    validateBtn.addActionListener(e -> validateJson());
    btns.add(validateBtn);
    top.add(btns, BorderLayout.EAST);

    p.add(top, BorderLayout.NORTH);
    p.add(sp, BorderLayout.CENTER);
    return p;
  }

  private Component buildChatPanel(){
    JPanel p = new JPanel(new BorderLayout());
    p.setBorder(new EmptyBorder(8,8,8,8));

    JLabel title = new JLabel("Chat Tester");
    title.setFont(title.getFont().deriveFont(Font.BOLD, 14f));

    chatArea = new JTextArea();
    chatArea.setEditable(false);
    chatArea.setLineWrap(true);
    chatArea.setWrapStyleWord(true);
    chatArea.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 12));

    JScrollPane sp = new JScrollPane(chatArea);

    JPanel controls = new JPanel(new BorderLayout(8, 8));
    JPanel left = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
    left.add(new JLabel("User:"));
    userField = new JTextField("user1", 10);
    left.add(userField);

    JButton clearChat = new JButton("Clear Chat");
    clearChat.addActionListener(e -> chatArea.setText(""));
    left.add(clearChat);

    controls.add(left, BorderLayout.WEST);

    JPanel inputRow = new JPanel(new BorderLayout(8, 8));
    inputField = new JTextField();
    sendBtn = new JButton("Send");
    sendBtn.addActionListener(e -> sendMessage());

    inputField.addActionListener(e -> sendMessage());

    inputRow.add(inputField, BorderLayout.CENTER);
    inputRow.add(sendBtn, BorderLayout.EAST);

    p.add(title, BorderLayout.NORTH);
    p.add(sp, BorderLayout.CENTER);
    p.add(inputRow, BorderLayout.SOUTH);

    return p;
  }

  private Component buildRightPanel(){
    JPanel p = new JPanel();
    p.setLayout(new BoxLayout(p, BoxLayout.Y_AXIS));
    p.setBorder(new EmptyBorder(8,8,8,8));
    p.setPreferredSize(new Dimension(320, 10));

    JLabel title = new JLabel("Bot Controls");
    title.setFont(title.getFont().deriveFont(Font.BOLD, 14f));
    title.setAlignmentX(Component.LEFT_ALIGNMENT);

    botCombo = new JComboBox<>();
    botCombo.setAlignmentX(Component.LEFT_ALIGNMENT);

    newBotBtn = new JButton("New Bot");
    newBotBtn.setAlignmentX(Component.LEFT_ALIGNMENT);
    newBotBtn.addActionListener(e -> newBot());

    clearBotBtn = new JButton("Clear Selected Bot");
    clearBotBtn.setAlignmentX(Component.LEFT_ALIGNMENT);
    clearBotBtn.addActionListener(e -> clearSelectedBot());

    loadBtn = new JButton("Load Dataset into Bot");
    loadBtn.setAlignmentX(Component.LEFT_ALIGNMENT);
    loadBtn.addActionListener(e -> loadDatasetIntoBot());

    statsLabel = new JLabel("Stats: (no bot)");
    statsLabel.setAlignmentX(Component.LEFT_ALIGNMENT);

    JButton testTokens = new JButton("Show Tokens for Input");
    testTokens.setAlignmentX(Component.LEFT_ALIGNMENT);
    testTokens.addActionListener(e -> showTokenization());

    p.add(title);
    p.add(Box.createVerticalStrut(8));
    p.add(new JLabel("Selected bot:"));
    p.add(botCombo);
    p.add(Box.createVerticalStrut(8));
    p.add(newBotBtn);
    p.add(Box.createVerticalStrut(8));
    p.add(loadBtn);
    p.add(Box.createVerticalStrut(8));
    p.add(clearBotBtn);
    p.add(Box.createVerticalStrut(16));
    p.add(statsLabel);
    p.add(Box.createVerticalStrut(16));
    p.add(testTokens);
    p.add(Box.createVerticalGlue());

    return p;
  }

  /* =========================
   * Actions
   * ========================= */

  private void ensureBotExists(){
    if(botCombo.getItemCount()==0){
      newBot();
    }
  }

  private BotHandle selectedBot(){
    return (BotHandle) botCombo.getSelectedItem();
  }

  private void newBot(){
    try{
      MiniPrologProto.Obj B = MiniPrologProto.Var();
      int vid = B.get(MiniPrologProto.K_VID);

      var sols = MiniPrologProto.query(prog, MiniPrologProto.Comp("aiml_new_bot", B));
      if(sols.isEmpty()) throw new RuntimeException("aiml_new_bot/1 failed");
      MiniPrologProto.Obj bot = sols.get(0).get(vid);

      BotHandle h = new BotHandle(bot);
      botCombo.addItem(h);
      botCombo.setSelectedItem(h);

      chatArea.append("[system] Created bot: "+h.label+"\n");
      refreshStats();
    } catch(Exception ex){
      showError("New Bot failed", ex);
    }
  }

  private void clearSelectedBot(){
    BotHandle h = selectedBot();
    if(h==null) return;
    int ok = JOptionPane.showConfirmDialog(frame,
        "Clear all categories/sets/session state for "+h.label+"?",
        "Clear Bot",
        JOptionPane.OK_CANCEL_OPTION);
    if(ok!=JOptionPane.OK_OPTION) return;

    try{
      boolean success = MiniPrologProto.solveOnce(MiniPrologProto.Engine(prog.get(MiniPrologProto.K_PREDICATES)),
          MiniPrologProto.Comp("aiml_clear_bot", h.term));
      if(!success) throw new RuntimeException("aiml_clear_bot/1 failed");
      chatArea.append("[system] Cleared bot: "+h.label+"\n");
      refreshStats();
    } catch(Exception ex){
      showError("Clear Bot failed", ex);
    }
  }

  private void validateJson(){
    try{
      String js = jsonArea.getText();
      MiniPrologProto.Obj parsed = MiniPrologProto.Json.parse(js); // uses the same parser as json_parse/2
      JOptionPane.showMessageDialog(frame,
          "JSON OK. Top-level term: "+MiniPrologProto.pp(parsed),
          "Validate JSON",
          JOptionPane.INFORMATION_MESSAGE);
    } catch(Exception ex){
      showError("JSON validation error", ex);
    }
  }

  private void loadDatasetIntoBot(){
    BotHandle h = selectedBot();
    if(h==null) return;
    try{
      // Clear bot first (so re-loading doesn't accumulate)
      MiniPrologProto.solveOnce(MiniPrologProto.Engine(prog.get(MiniPrologProto.K_PREDICATES)),
          MiniPrologProto.Comp("aiml_clear_bot", h.term));

      String js = jsonArea.getText();
      boolean ok = MiniPrologProto.solveOnce(MiniPrologProto.Engine(prog.get(MiniPrologProto.K_PREDICATES)),
          MiniPrologProto.Comp("aiml_load_json_string", h.term, MiniPrologProto.Atom(js)));
      if(!ok) throw new RuntimeException("aiml_load_json_string/2 failed");

      chatArea.append("[system] Loaded dataset into "+h.label+"\n");
      refreshStats();
    } catch(Exception ex){
      showError("Load dataset failed", ex);
    }
  }

  private void sendMessage(){
    BotHandle h = selectedBot();
    if(h==null) return;

    String user = userField.getText().trim();
    if(user.isEmpty()) user = "user1";

    String input = inputField.getText().trim();
    if(input.isEmpty()) return;

    inputField.setText("");

    chatArea.append(user+"> "+input+"\n");
    try{
      MiniPrologProto.Obj Reply = MiniPrologProto.Var();
      int vid = Reply.get(MiniPrologProto.K_VID);

      var sols = MiniPrologProto.query(prog,
          MiniPrologProto.Comp("aiml_reply", h.term, MiniPrologProto.Atom(user), MiniPrologProto.Atom(input), Reply));
      if(sols.isEmpty()){
        chatArea.append(h.label+"> [no reply]\n\n");
        return;
      }
      MiniPrologProto.Obj replyTerm = sols.get(0).get(vid);
      String replyText = (replyTerm==null) ? "" : MiniPrologProto.termToJavaString(replyTerm, new MiniPrologProto.Trail());

      chatArea.append(h.label+"> "+replyText+"\n\n");
      refreshStats();
    } catch(Exception ex){
      showError("Chat failed", ex);
    }
  }

  private void showTokenization(){
    String input = inputField.getText().trim();
    if(input.isEmpty()){
      JOptionPane.showMessageDialog(frame, "Type something in the input box first.", "Tokens", JOptionPane.INFORMATION_MESSAGE);
      return;
    }
    try{
      MiniPrologProto.Obj Toks = MiniPrologProto.Var();
      int vid = Toks.get(MiniPrologProto.K_VID);
      var sols = MiniPrologProto.query(prog, MiniPrologProto.Comp("aiml_tokenize", MiniPrologProto.Atom(input), Toks));
      if(sols.isEmpty()) throw new RuntimeException("aiml_tokenize/2 failed");
      MiniPrologProto.Obj toks = sols.get(0).get(vid);
      JOptionPane.showMessageDialog(frame, MiniPrologProto.pp(toks), "Tokens", JOptionPane.INFORMATION_MESSAGE);
    } catch(Exception ex){
      showError("Tokenize failed", ex);
    }
  }

  private void refreshStats(){
    BotHandle h = selectedBot();
    if(h==null){
      statsLabel.setText("Stats: (no bot)");
      return;
    }
    try{
      MiniPrologProto.Obj SN = MiniPrologProto.Var();
      MiniPrologProto.Obj CN = MiniPrologProto.Var();
      int vidS = SN.get(MiniPrologProto.K_VID);
      int vidC = CN.get(MiniPrologProto.K_VID);

      var sols = MiniPrologProto.query(prog, MiniPrologProto.Comp("aiml_stats", h.term, SN, CN));
      if(sols.isEmpty()){
        statsLabel.setText("Stats: sets=?, cats=?");
        return;
      }
      MiniPrologProto.Obj s = sols.get(0).get(vidS);
      MiniPrologProto.Obj c = sols.get(0).get(vidC);
      statsLabel.setText("Stats: sets="+MiniPrologProto.pp(s)+", cats="+MiniPrologProto.pp(c));
    } catch(Exception ex){
      statsLabel.setText("Stats: (error)");
    }
  }

  private void openJsonFile(){
    JFileChooser fc = new JFileChooser();
    fc.setFileFilter(new FileNameExtensionFilter("JSON files", "json"));
    if(currentFile!=null) fc.setCurrentDirectory(currentFile.toFile().getParentFile());
    int r = fc.showOpenDialog(frame);
    if(r!=JFileChooser.APPROVE_OPTION) return;
    currentFile = fc.getSelectedFile().toPath();
    try{
      String s = Files.readString(currentFile, StandardCharsets.UTF_8);
      jsonArea.setText(s);
      frame.setTitle("JSON-AIML Studio - "+currentFile.getFileName());
    } catch(IOException ex){
      showError("Open failed", ex);
    }
  }

  private void saveJsonFile(boolean forceChoose){
    try{
      if(currentFile==null || forceChoose){
        JFileChooser fc = new JFileChooser();
        fc.setFileFilter(new FileNameExtensionFilter("JSON files", "json"));
        int r = fc.showSaveDialog(frame);
        if(r!=JFileChooser.APPROVE_OPTION) return;
        currentFile = fc.getSelectedFile().toPath();
        if(!currentFile.toString().toLowerCase().endsWith(".json")){
          currentFile = java.nio.file.Path.of(currentFile.toString()+".json");
        }
      }
      Files.writeString(currentFile, jsonArea.getText(), StandardCharsets.UTF_8);
      frame.setTitle("JSON-AIML Studio - "+currentFile.getFileName());
    } catch(IOException ex){
      showError("Save failed", ex);
    }
  }

  private static void showError(String title, Exception ex){
    ex.printStackTrace(System.err);
    JOptionPane.showMessageDialog(null,
        ex.getClass().getSimpleName()+": "+ex.getMessage(),
        title,
        JOptionPane.ERROR_MESSAGE);
  }

  private static String defaultDataset(){
    return "{\n" +
        "  \"version\": \"json-aiml-0.1\",\n" +
        "  \"sets\": {\n" +
        "    \"COLOR\": [\"RED\", \"GREEN\", \"BLUE\"]\n" +
        "  },\n" +
        "  \"categories\": [\n" +
        "    {\n" +
        "      \"pattern\": [\"HELLO\", \"*\"],\n" +
        "      \"template\": [\n" +
        "        { \"t\": \"text\", \"v\": \"Hello!\" }\n" +
        "      ]\n" +
        "    },\n" +
        "    {\n" +
        "      \"pattern\": [\"MY\", \"NAME\", \"IS\", \"*\"],\n" +
        "      \"template\": [\n" +
        "        { \"t\": \"set\", \"name\": \"name\", \"value\": [ { \"t\": \"star\", \"index\": 1 } ] },\n" +
        "        { \"t\": \"text\", \"v\": \"Nice to meet you,\" },\n" +
        "        { \"t\": \"get\", \"name\": \"name\" }\n" +
        "      ]\n" +
        "    },\n" +
        "    {\n" +
        "      \"pattern\": [\"WHAT\", \"IS\", \"MY\", \"NAME\"],\n" +
        "      \"template\": [\n" +
        "        { \"t\": \"text\", \"v\": \"Your name is\" },\n" +
        "        { \"t\": \"get\", \"name\": \"name\" }\n" +
        "      ]\n" +
        "    },\n" +
        "    {\n" +
        "      \"pattern\": [\"PICK\", \"A\", \"COLOR\"],\n" +
        "      \"template\": [\n" +
        "        { \"t\": \"random\", \"items\": [\n" +
        "          [ { \"t\": \"text\", \"v\": \"RED\" } ],\n" +
        "          [ { \"t\": \"text\", \"v\": \"GREEN\" } ],\n" +
        "          [ { \"t\": \"text\", \"v\": \"BLUE\" } ]\n" +
        "        ] }\n" +
        "      ]\n" +
        "    },\n" +
        "    {\n" +
        "      \"pattern\": [\"WHO\", \"ARE\", \"YOU\"],\n" +
        "      \"template\": [\n" +
        "        { \"t\": \"text\", \"v\": \"I am a JSON-AIML bot running inside Prolog.\" }\n" +
        "      ]\n" +
        "    }\n" +
        "  ]\n" +
        "}\n";
  }

  public static void main(String[] args){
    SwingUtilities.invokeLater(() -> new JsonAimlStudioMain().show());
  }
}
