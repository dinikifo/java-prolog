package com.mycompany.prolog;

import static com.mycompany.prolog.MiniPrologProto.*;

/**
 * JsonAimlLib - a JSON-first AIML-like chatbot library implemented in Prolog rules
 * (registered via definePred). Pattern matching + template evaluation run inside
 * the MiniPrologProto engine; JSON parsing/tokenization are provided by built-ins.
 *
 * Public API:
 *   - aiml_new_bot(-Bot)
 *   - aiml_clear_bot(+Bot)
 *   - aiml_load_json_string(+Bot, +JsonStringOrAtom)
 *   - aiml_load_json(+Bot, +JsonTerm)
 *   - aiml_reply_tokens(+Bot, +User, +InputTokens, -OutputChunks)
 *   - aiml_reply(+Bot, +User, +InputText, -ReplyText)   (uses aiml_tokenize/2 + aiml_detokenize/2)
 *   - aiml_stats(+Bot, -SetsCount, -CatsCount)
 *
 * Notes:
 * - Tokenization is intentionally simple (uppercasing + split on non-alnum/_).
 * - Template output is a list of "chunks" (atoms). aiml_detokenize/2 joins chunks
 *   with basic punctuation-aware spacing.
 */
public final class JsonAimlLib {
  private JsonAimlLib(){}

  public static void load(Obj prog){

    /* -------------------------
     * Basic list helpers
     * ------------------------- */
    {
      Obj X=Var(), XS=Var(), Y=Var();
      definePred(prog, "member", 2, Predicate(
          Clause(Comp("member", X, listCons(X, XS))),
          Clause(Comp("member", X, listCons(Y, XS)),
              Comp("member", X, XS))
      ));
    }
    {
      Obj B=Var(), H=Var(), T=Var(), R=Var();
      definePred(prog, "append", 3, Predicate(
          Clause(Comp("append", listNil(), B, B)),
          Clause(Comp("append", listCons(H,T), B, listCons(H,R)),
              Comp("append", T, B, R))
      ));
    }
    {
      Obj L=Var(), N=Var(), H=Var(), T=Var(), N1=Var();
      definePred(prog, "length", 2, Predicate(
          Clause(Comp("length", listNil(), Num(0))),
          Clause(Comp("length", listCons(H,T), N),
              Comp("length", T, N1),
              Comp("is", N, Comp("+", N1, Num(1))))
      ));
    }
    {
      Obj I=Var(), X=Var(), XS=Var(), N=Var(), N1=Var();
      definePred(prog, "nth1", 3, Predicate(
          Clause(Comp("nth1", Num(1), listCons(X, XS), X), Comp("!")),
          Clause(Comp("nth1", N, listCons(X, XS), I),
              Comp("is", N1, Comp("-", N, Num(1))),
              Comp("nth1", N1, XS, I))
      ));
    }
    {
      Obj L=Var(), R=Var();
      definePred(prog, "reverse", 2, Predicate(
          Clause(Comp("reverse", L, R), Comp("rev_acc", L, listNil(), R))
      ));
      Obj Acc=Var(), H=Var(), T=Var();
      definePred(prog, "rev_acc", 3, Predicate(
          Clause(Comp("rev_acc", listNil(), Acc, Acc), Comp("!")),
          Clause(Comp("rev_acc", listCons(H,T), Acc, R),
              Comp("rev_acc", T, listCons(H,Acc), R))
      ));
    }

    /* -------------------------
     * JSON helpers
     * ------------------------- */
    {
      Obj K=Var(), V=Var(), L=Var();
      definePred(prog, "json_obj_get", 3, Predicate(
          Clause(Comp("json_obj_get", Comp("obj", L), K, V),
              Comp("member", Comp("kv", K, V), L))
      ));
    }
    {
      Obj J=Var(), K=Var(), D=Var(), V=Var();
      definePred(prog, "json_obj_get_default", 4, Predicate(
          Clause(Comp("json_obj_get_default", J, K, D, V),
              Comp("json_obj_get", J, K, V),
              Comp("!")),
          Clause(Comp("json_obj_get_default", J, K, D, D))
      ));
    }
    {
      Obj L=Var();
      definePred(prog, "json_arr_list", 2, Predicate(
          Clause(Comp("json_arr_list", Comp("arr", L), L))
      ));
    }
    {
      Obj A=Var(), X=Var();
      definePred(prog, "json_atom", 2, Predicate(
          Clause(Comp("json_atom", Comp("str", A), A), Comp("!")),
          Clause(Comp("json_atom", X, X))
      ));
    }
    {
      Obj H=Var(), T=Var(), A=Var(), R=Var();
      definePred(prog, "json_terms_to_atoms", 2, Predicate(
          Clause(Comp("json_terms_to_atoms", listNil(), listNil())),
          Clause(Comp("json_terms_to_atoms", listCons(H, T), listCons(A, R)),
              Comp("json_atom", H, A),
              Comp("json_terms_to_atoms", T, R))
      ));
    }

    /* -------------------------
     * AIML dynamic facts
     * ------------------------- */
    definePred(prog, "aiml_counter", 1, Predicate(
        Clause(Comp("aiml_counter", Num(0)))
    ));

    // Data model (asserted dynamically)
    definePred(prog, "aiml_set", 3, Predicate());      // aiml_set(Bot, SetName, WordsList)
    definePred(prog, "aiml_cat", 5, Predicate());      // aiml_cat(Bot, TopicPat, ThatPat, InputPat, TemplateNodes)
    definePred(prog, "aiml_var", 4, Predicate());      // aiml_var(Bot, User, Name, ValueChunks)
    definePred(prog, "aiml_that", 3, Predicate());     // aiml_that(Bot, User, LastReplyChunks)
    definePred(prog, "aiml_rng", 3, Predicate());      // aiml_rng(Bot, User, Seed)

    /* -------------------------
     * Bot creation / clearing / stats
     * ------------------------- */
    {
      Obj C=Var(), C1=Var();
      definePred(prog, "aiml_new_bot", 1, Predicate(
          Clause(Comp("aiml_new_bot", Comp("bot", C1)),
              Comp("aiml_counter", C),
              Comp("retract", Comp("aiml_counter", C)),
              Comp("is", C1, Comp("+", C, Num(1))),
              Comp("assertz", Comp("aiml_counter", C1))
          )
      ));
    }

    // aiml_clear_bot(B) :- (retract(aiml_set(B,_,_)) ; retract(aiml_cat(B,_,_,_,_)) ; retract(aiml_var(B,_,_,_)) ; retract(aiml_that(B,_,_)) ; retract(aiml_rng(B,_,_))), !, aiml_clear_bot(B).
    // aiml_clear_bot(_).
    {
      Obj B=Var();
      Obj any = Var();
      Obj disj =
          Comp(";",
              Comp("retract", Comp("aiml_set", B, Var(), Var())),
              Comp(";",
                  Comp("retract", Comp("aiml_cat", B, Var(), Var(), Var(), Var())),
                  Comp(";",
                      Comp("retract", Comp("aiml_var", B, Var(), Var(), Var())),
                      Comp(";",
                          Comp("retract", Comp("aiml_that", B, Var(), Var())),
                          Comp("retract", Comp("aiml_rng", B, Var(), Var()))
                      )
                  )
              )
          );

      definePred(prog, "aiml_clear_bot", 1, Predicate(
          Clause(Comp("aiml_clear_bot", B),
              disj,
              Comp("!"),
              Comp("aiml_clear_bot", B)),
          Clause(Comp("aiml_clear_bot", any))
      ));
    }

    {
      Obj B=Var(), Sets=Var(), Cats=Var(), SetsN=Var(), CatsN=Var();
      definePred(prog, "aiml_stats", 3, Predicate(
          Clause(Comp("aiml_stats", B, SetsN, CatsN),
              Comp("findall", Num(1), Comp("aiml_set", B, Var(), Var()), Sets),
              Comp("length", Sets, SetsN),
              Comp("findall", Num(1), Comp("aiml_cat", B, Var(), Var(), Var(), Var()), Cats),
              Comp("length", Cats, CatsN))
      ));
    }

    /* -------------------------
     * Load JSON-AIML
     * ------------------------- */
    {
      Obj B=Var(), S=Var(), J=Var();
      definePred(prog, "aiml_load_json_string", 2, Predicate(
          Clause(Comp("aiml_load_json_string", B, S),
              Comp("json_parse", S, J),
              Comp("aiml_load_json", B, J))
      ));
    }

    {
      Obj B=Var(), J=Var(), Sets=Var(), Cats=Var(), CatsL=Var();
      definePred(prog, "aiml_load_json", 2, Predicate(
          Clause(Comp("aiml_load_json", B, J),
              Comp("json_obj_get_default", J, Atom("sets"), Atom("null"), Sets),
              Comp("aiml_load_sets", B, Sets),
              Comp("json_obj_get", J, Atom("categories"), Cats),
              Comp("json_arr_list", Cats, CatsL),
              Comp("aiml_load_categories", B, CatsL))
      ));
    }

    {
      Obj B=Var(), Sets=Var();
      definePred(prog, "aiml_load_sets", 2, Predicate(
          Clause(Comp("aiml_load_sets", B, Atom("null")), Comp("!")),
          Clause(Comp("aiml_load_sets", B, Sets),
              Comp("aiml_load_sets_obj", B, Sets))
      ));
    }

    {
      Obj B=Var(), L=Var();
      definePred(prog, "aiml_load_sets_obj", 2, Predicate(
          Clause(Comp("aiml_load_sets_obj", B, Comp("obj", L)),
              Comp("aiml_load_sets_kvs", B, L))
      ));
    }

    {
      Obj B=Var(), K=Var(), V=Var(), T=Var(), WordsJ=Var(), Words=Var();
      definePred(prog, "aiml_load_sets_kvs", 2, Predicate(
          Clause(Comp("aiml_load_sets_kvs", B, listNil()), Comp("!")),
          Clause(Comp("aiml_load_sets_kvs", B, listCons(Comp("kv", K, V), T)),
              Comp("json_arr_list", V, WordsJ),
              Comp("json_terms_to_atoms", WordsJ, Words),
              Comp("assertz", Comp("aiml_set", B, K, Words)),
              Comp("aiml_load_sets_kvs", B, T))
      ));
    }

    {
      Obj B=Var(), H=Var(), T=Var();
      definePred(prog, "aiml_load_categories", 2, Predicate(
          Clause(Comp("aiml_load_categories", B, listNil()), Comp("!")),
          Clause(Comp("aiml_load_categories", B, listCons(H, T)),
              Comp("aiml_load_category", B, H),
              Comp("aiml_load_categories", B, T))
      ));
    }

    {
      Obj B=Var(), JCat=Var();
      Obj JPat=Var(), JThat=Var(), JTopic=Var(), JTpl=Var();
      Obj Pat=Var(), ThatPat=Var(), TopicPat=Var(), Tpl=Var();
      definePred(prog, "aiml_load_category", 2, Predicate(
          Clause(Comp("aiml_load_category", B, JCat),
              Comp("json_obj_get", JCat, Atom("pattern"), JPat),
              Comp("aiml_compile_pattern", JPat, Pat),
              Comp("json_obj_get_default", JCat, Atom("that"), Comp("arr", list(Comp("str", Atom("*")))), JThat),
              Comp("aiml_compile_pattern", JThat, ThatPat),
              Comp("json_obj_get_default", JCat, Atom("topic"), Comp("arr", list(Comp("str", Atom("*")))), JTopic),
              Comp("aiml_compile_pattern", JTopic, TopicPat),
              Comp("json_obj_get", JCat, Atom("template"), JTpl),
              Comp("aiml_compile_template", JTpl, Tpl),
              Comp("assertz", Comp("aiml_cat", B, TopicPat, ThatPat, Pat, Tpl))
          )
      ));
    }

    /* -------------------------
     * Compile patterns
     * ------------------------- */
    {
      Obj J=Var(), P=Var(), L=Var(), Tok=Var();
      definePred(prog, "aiml_compile_pattern", 2, Predicate(
          Clause(Comp("aiml_compile_pattern", Comp("arr", L), P),
              Comp("aiml_compile_pat_list", L, P),
              Comp("!")),
          Clause(Comp("aiml_compile_pattern", Comp("str", Tok), listCons(Tok, listNil())))
      ));
    }

    {
      Obj H=Var(), T=Var(), PH=Var(), PT=Var();
      definePred(prog, "aiml_compile_pat_list", 2, Predicate(
          Clause(Comp("aiml_compile_pat_list", listNil(), listNil()), Comp("!")),
          Clause(Comp("aiml_compile_pat_list", listCons(H, T), listCons(PH, PT)),
              Comp("aiml_compile_pat_tok", H, PH),
              Comp("aiml_compile_pat_list", T, PT))
      ));
    }

    {
      Obj JTok=Var(), Tok=Var(), L=Var(), Name=Var();
      definePred(prog, "aiml_compile_pat_tok", 2, Predicate(
          Clause(Comp("aiml_compile_pat_tok", Comp("str", Tok), Tok), Comp("!")),
          Clause(Comp("aiml_compile_pat_tok", Comp("obj", L), Comp("set", Name)),
              Comp("json_obj_get", Comp("obj", L), Atom("set"), Comp("str", Name)),
              Comp("!")),
          Clause(Comp("aiml_compile_pat_tok", JTok, Tok),
              Comp("json_atom", JTok, Tok))
      ));
    }

    /* -------------------------
     * Compile templates into an AST
     * ------------------------- */
    {
      Obj J=Var(), Tpl=Var(), L=Var();
      definePred(prog, "aiml_compile_template", 2, Predicate(
          Clause(Comp("aiml_compile_template", Comp("arr", L), Tpl),
              Comp("aiml_compile_nodes", L, Tpl),
              Comp("!")),
          Clause(Comp("aiml_compile_template", J, listCons(Comp("t_text", Atom("[bad_template]")), listNil())))
      ));
    }

    {
      Obj H=Var(), T=Var(), NH=Var(), NT=Var();
      definePred(prog, "aiml_compile_nodes", 2, Predicate(
          Clause(Comp("aiml_compile_nodes", listNil(), listNil()), Comp("!")),
          Clause(Comp("aiml_compile_nodes", listCons(H, T), listCons(NH, NT)),
              Comp("aiml_compile_node", H, NH),
              Comp("aiml_compile_nodes", T, NT))
      ));
    }

    {
      Obj L=Var(), V=Var(), Name=Var(), ValJ=Var(), NodesJ=Var(), ValNodes=Var();
      Obj ItemsJ=Var(), ItemsL=Var(), Items=Var(), I=Var();
      definePred(prog, "aiml_compile_node", 2, Predicate(
          Clause(Comp("aiml_compile_node", Comp("obj", L), Comp("t_text", V)),
              Comp("json_obj_get", Comp("obj", L), Atom("t"), Comp("str", Atom("text"))),
              Comp("json_obj_get", Comp("obj", L), Atom("v"), Comp("str", V)),
              Comp("!")),
          Clause(Comp("aiml_compile_node", Comp("obj", L), Comp("t_get", Name)),
              Comp("json_obj_get", Comp("obj", L), Atom("t"), Comp("str", Atom("get"))),
              Comp("json_obj_get", Comp("obj", L), Atom("name"), Comp("str", Name)),
              Comp("!")),
          Clause(Comp("aiml_compile_node", Comp("obj", L), Comp("t_set", Name, ValNodes)),
              Comp("json_obj_get", Comp("obj", L), Atom("t"), Comp("str", Atom("set"))),
              Comp("json_obj_get", Comp("obj", L), Atom("name"), Comp("str", Name)),
              Comp("json_obj_get", Comp("obj", L), Atom("value"), ValJ),
              Comp("json_arr_list", ValJ, NodesJ),
              Comp("aiml_compile_nodes", NodesJ, ValNodes),
              Comp("!")),
          Clause(Comp("aiml_compile_node", Comp("obj", L), Comp("t_star", I)),
              Comp("json_obj_get", Comp("obj", L), Atom("t"), Comp("str", Atom("star"))),
              Comp("json_obj_get_default", Comp("obj", L), Atom("index"), Num(1), I),
              Comp("!")),
          Clause(Comp("aiml_compile_node", Comp("obj", L), Comp("t_srai", ValNodes)),
              Comp("json_obj_get", Comp("obj", L), Atom("t"), Comp("str", Atom("srai"))),
              Comp("json_obj_get", Comp("obj", L), Atom("value"), ValJ),
              Comp("json_arr_list", ValJ, NodesJ),
              Comp("aiml_compile_nodes", NodesJ, ValNodes),
              Comp("!")),
          Clause(Comp("aiml_compile_node", Comp("obj", L), Comp("t_think", ValNodes)),
              Comp("json_obj_get", Comp("obj", L), Atom("t"), Comp("str", Atom("think"))),
              Comp("json_obj_get", Comp("obj", L), Atom("value"), ValJ),
              Comp("json_arr_list", ValJ, NodesJ),
              Comp("aiml_compile_nodes", NodesJ, ValNodes),
              Comp("!")),
          Clause(Comp("aiml_compile_node", Comp("obj", L), Comp("t_random", Items)),
              Comp("json_obj_get", Comp("obj", L), Atom("t"), Comp("str", Atom("random"))),
              Comp("json_obj_get", Comp("obj", L), Atom("items"), ItemsJ),
              Comp("json_arr_list", ItemsJ, ItemsL),
              Comp("aiml_compile_random_items", ItemsL, Items),
              Comp("!")),
          Clause(Comp("aiml_compile_node", Comp("str", V), Comp("t_text", V)), Comp("!")),
          Clause(Comp("aiml_compile_node", Var(), Comp("t_text", Atom("[unhandled_node]"))))
      ));
    }

    {
      Obj H=Var(), T=Var(), NodesJ=Var(), Nodes=Var(), R=Var();
      definePred(prog, "aiml_compile_random_items", 2, Predicate(
          Clause(Comp("aiml_compile_random_items", listNil(), listNil()), Comp("!")),
          Clause(Comp("aiml_compile_random_items", listCons(H, T), listCons(Nodes, R)),
              Comp("json_arr_list", H, NodesJ),
              Comp("aiml_compile_nodes", NodesJ, Nodes),
              Comp("aiml_compile_random_items", T, R))
      ));
    }

    /* -------------------------
     * Context helpers
     * ------------------------- */
    {
      Obj B=Var(), U=Var(), T=Var();
      definePred(prog, "aiml_get_that", 3, Predicate(
          Clause(Comp("aiml_get_that", B, U, T), Comp("aiml_that", B, U, T), Comp("!")),
          Clause(Comp("aiml_get_that", B, U, listCons(Atom("*"), listNil())))
      ));
    }

    {
      Obj B=Var(), U=Var(), T=Var();
      definePred(prog, "aiml_set_that", 3, Predicate(
          Clause(Comp("aiml_set_that", B, U, T),
              Comp("retract", Comp("aiml_that", B, U, Var())),
              Comp("!"),
              Comp("assertz", Comp("aiml_that", B, U, T))
          ),
          Clause(Comp("aiml_set_that", B, U, T),
              Comp("assertz", Comp("aiml_that", B, U, T))
          )
      ));
    }

    {
      Obj B=Var(), U=Var(), Topic=Var();
      definePred(prog, "aiml_get_topic", 3, Predicate(
          Clause(Comp("aiml_get_topic", B, U, Topic), Comp("aiml_var", B, U, Atom("topic"), Topic), Comp("!")),
          Clause(Comp("aiml_get_topic", B, U, listCons(Atom("*"), listNil())))
      ));
    }

    {
      Obj B=Var(), U=Var(), Name=Var(), Val=Var();
      definePred(prog, "aiml_set_var", 4, Predicate(
          Clause(Comp("aiml_set_var", B, U, Name, Val),
              Comp("retract", Comp("aiml_var", B, U, Name, Var())),
              Comp("!"),
              Comp("assertz", Comp("aiml_var", B, U, Name, Val))
          ),
          Clause(Comp("aiml_set_var", B, U, Name, Val),
              Comp("assertz", Comp("aiml_var", B, U, Name, Val))
          )
      ));
    }

    definePred(prog, "aiml_depth_limit", 1, Predicate(
        Clause(Comp("aiml_depth_limit", Num(10)))
    ));

    /* -------------------------
     * Pattern matching
     * ------------------------- */
    {
      Obj B=Var(), Pat=Var(), In=Var(), Stars=Var();
      definePred(prog, "aiml_match_simple", 3, Predicate(
          Clause(Comp("aiml_match_simple", B, Pat, In),
              Comp("aiml_match", B, Pat, In, Stars))
      ));
    }

    {
      Obj B=Var(), PT=Var(), In=Var();
      Obj Cap=Var(), RestIn=Var(), StarsRest=Var();
      Obj SetName=Var(), SetWords=Var(), IH=Var(), IT=Var(), PH=Var(), Stars=Var();
      definePred(prog, "aiml_match", 4, Predicate(
          Clause(Comp("aiml_match", B, listNil(), listNil(), listNil()), Comp("!")),
          // * wildcard (can match empty)
          Clause(Comp("aiml_match", B, listCons(Atom("*"), PT), In, listCons(Cap, StarsRest)),
              Comp("append", Cap, RestIn, In),
              Comp("aiml_match", B, PT, RestIn, StarsRest)),
          // _ wildcard (must match at least 1 token)
          Clause(Comp("aiml_match", B, listCons(Atom("_"), PT), In, listCons(Cap, StarsRest)),
              Comp("append", Cap, RestIn, In),
              Comp("\\+", Comp("=", Cap, listNil())),
              Comp("aiml_match", B, PT, RestIn, StarsRest)),
          // set(Name) matches one token that is a member of the named set
          Clause(Comp("aiml_match", B, listCons(Comp("set", SetName), PT), listCons(IH, IT), Stars),
              Comp("aiml_set", B, SetName, SetWords),
              Comp("member", IH, SetWords),
              Comp("aiml_match", B, PT, IT, Stars)),
          // literal token match
          Clause(Comp("aiml_match", B, listCons(PH, PT), listCons(PH, IT), Stars),
              Comp("aiml_match", B, PT, IT, Stars))
      ));
    }

    /* -------------------------
     * Pattern scoring / best match
     * ------------------------- */
    {
      Obj Pat=Var(), Score=Var();
      definePred(prog, "aiml_pattern_score", 2, Predicate(
          Clause(Comp("aiml_pattern_score", Pat, Score),
              Comp("aiml_pattern_score_acc", Pat, Num(0), Score))
      ));
    }
    {
      Obj Acc=Var(), Score=Var(), H=Var(), T=Var(), Acc1=Var(), W=Var();
      definePred(prog, "aiml_pattern_score_acc", 3, Predicate(
          Clause(Comp("aiml_pattern_score_acc", listNil(), Acc, Acc), Comp("!")),
          Clause(Comp("aiml_pattern_score_acc", listCons(Atom("*"), T), Acc, Score),
              Comp("aiml_pattern_score_acc", T, Acc, Score)),
          Clause(Comp("aiml_pattern_score_acc", listCons(Atom("_"), T), Acc, Score),
              Comp("is", Acc1, Comp("+", Acc, Num(1))),
              Comp("aiml_pattern_score_acc", T, Acc1, Score)),
          Clause(Comp("aiml_pattern_score_acc", listCons(Comp("set", W), T), Acc, Score),
              Comp("is", Acc1, Comp("+", Acc, Num(2))),
              Comp("aiml_pattern_score_acc", T, Acc1, Score)),
          Clause(Comp("aiml_pattern_score_acc", listCons(H, T), Acc, Score),
              Comp("is", Acc1, Comp("+", Acc, Num(10))),
              Comp("aiml_pattern_score_acc", T, Acc1, Score))
      ));
    }

    {
      Obj B=Var(), Topic=Var(), That=Var(), In=Var();
      Obj TopicPat=Var(), ThatPat=Var(), Pat=Var(), Tpl=Var(), Stars=Var(), Score=Var();
      definePred(prog, "aiml_candidate_item", 5, Predicate(
          Clause(Comp("aiml_candidate_item", B, Topic, That, In, Comp("item", Score, Tpl, Stars)),
              Comp("aiml_cat", B, TopicPat, ThatPat, Pat, Tpl),
              Comp("aiml_match_simple", B, TopicPat, Topic),
              Comp("aiml_match_simple", B, ThatPat, That),
              Comp("aiml_match", B, Pat, In, Stars),
              Comp("aiml_pattern_score", Pat, Score))
      ));
    }

    {
      Obj B=Var(), Topic=Var(), That=Var(), In=Var(), Best=Var(), Items=Var(), It=Var();
      definePred(prog, "aiml_best_item", 5, Predicate(
          Clause(Comp("aiml_best_item", B, Topic, That, In, Best),
              Comp("findall", It, Comp("aiml_candidate_item", B, Topic, That, In, It), Items),
              Comp("aiml_best_item_list", Items, Best))
      ));
    }

    {
      Obj H=Var(), T=Var(), Best=Var();
      definePred(prog, "aiml_best_item_list", 2, Predicate(
          Clause(Comp("aiml_best_item_list", listNil(), Atom("none")), Comp("!")),
          Clause(Comp("aiml_best_item_list", listCons(H,T), Best),
              Comp("aiml_best_item_acc", T, H, Best))
      ));
    }

    {
      Obj T=Var(), Cur=Var(), Best=Var(), H=Var();
      Obj S1=Var(), S2=Var();
      definePred(prog, "aiml_best_item_acc", 3, Predicate(
          Clause(Comp("aiml_best_item_acc", listNil(), Cur, Cur), Comp("!")),
          Clause(Comp("aiml_best_item_acc", listCons(H,T), Cur, Best),
              Comp("aiml_item_score", H, S1),
              Comp("aiml_item_score", Cur, S2),
              Comp(">", S1, S2),
              Comp("!"),
              Comp("aiml_best_item_acc", T, H, Best)
          ),
          Clause(Comp("aiml_best_item_acc", listCons(H,T), Cur, Best),
              Comp("aiml_best_item_acc", T, Cur, Best)
          )
      ));
    }

    {
      Obj S=Var(), Tpl=Var(), Stars=Var();
      definePred(prog, "aiml_item_score", 2, Predicate(
          Clause(Comp("aiml_item_score", Comp("item", S, Tpl, Stars), S))
      ));
    }

    /* -------------------------
     * RNG for random templates (deterministic)
     * ------------------------- */
    {
      Obj B=Var(), U=Var(), Seed=Var();
      definePred(prog, "aiml_get_seed", 3, Predicate(
          Clause(Comp("aiml_get_seed", B, U, Seed), Comp("aiml_rng", B, U, Seed), Comp("!")),
          Clause(Comp("aiml_get_seed", B, U, Num(1)))
      ));
    }
    {
      Obj B=Var(), U=Var(), Seed=Var();
      definePred(prog, "aiml_set_seed", 3, Predicate(
          Clause(Comp("aiml_set_seed", B, U, Seed),
              Comp("retract", Comp("aiml_rng", B, U, Var())),
              Comp("!"),
              Comp("assertz", Comp("aiml_rng", B, U, Seed))
          ),
          Clause(Comp("aiml_set_seed", B, U, Seed),
              Comp("assertz", Comp("aiml_rng", B, U, Seed))
          )
      ));
    }
    {
      Obj B=Var(), U=Var(), Max=Var(), N=Var(), Seed0=Var(), Seed1=Var(), Tmp=Var(), N0=Var();
      definePred(prog, "aiml_rand1", 4, Predicate(
          Clause(Comp("aiml_rand1", B, U, Max, N),
              Comp("aiml_get_seed", B, U, Seed0),
              Comp("is", Tmp, Comp("+", Comp("*", Seed0, Num(1103515245L)), Num(12345))),
              Comp("is", Seed1, Comp("mod", Tmp, Num(2147483648L))),
              Comp("is", N0, Comp("mod", Seed1, Max)),
              Comp("is", N, Comp("+", N0, Num(1))),
              Comp("aiml_set_seed", B, U, Seed1)
          )
      ));
    }

    /* -------------------------
     * Template evaluation
     * ------------------------- */
    {
      Obj B=Var(), U=Var(), Nodes=Var(), Stars=Var(), D=Var(), Out=Var();
      definePred(prog, "aiml_eval_nodes", 6, Predicate(
          Clause(Comp("aiml_eval_nodes", B, U, Nodes, Stars, D, Out),
              Comp("aiml_eval_nodes_acc", B, U, Nodes, Stars, D, listNil(), Out))
      ));
      Obj Acc=Var(), H=Var(), T=Var(), Part=Var(), RevPart=Var(), Acc1=Var();
      definePred(prog, "aiml_eval_nodes_acc", 7, Predicate(
          Clause(Comp("aiml_eval_nodes_acc", B, U, listNil(), Stars, D, Acc, Out),
              Comp("reverse", Acc, Out),
              Comp("!")),
          Clause(Comp("aiml_eval_nodes_acc", B, U, listCons(H, T), Stars, D, Acc, Out),
              Comp("aiml_eval_node", B, U, H, Stars, D, Part),
              Comp("reverse", Part, RevPart),
              Comp("append", RevPart, Acc, Acc1),
              Comp("aiml_eval_nodes_acc", B, U, T, Stars, D, Acc1, Out))
      ));
    }

    {
      Obj B=Var(), U=Var(), Stars=Var(), D=Var(), Out=Var();
      Obj V=Var(), Name=Var(), ValNodes=Var(), Val=Var(), I=Var();
      Obj In2=Var(), D1=Var(), Items=Var(), Len=Var(), K=Var(), Choice=Var();
      Obj Score=Var(), Node=Var();
      definePred(prog, "aiml_eval_node", 6, Predicate(
          Clause(Comp("aiml_eval_node", B, U, Comp("t_text", V), Stars, D, listCons(V, listNil())), Comp("!")),
          Clause(Comp("aiml_eval_node", B, U, Comp("t_get", Name), Stars, D, Val),
              Comp("aiml_var", B, U, Name, Val),
              Comp("!")),
          Clause(Comp("aiml_eval_node", B, U, Comp("t_get", Name), Stars, D, listNil()), Comp("!")),
          Clause(Comp("aiml_eval_node", B, U, Comp("t_set", Name, ValNodes), Stars, D, Val),
              Comp("aiml_eval_nodes", B, U, ValNodes, Stars, D, Val),
              Comp("aiml_set_var", B, U, Name, Val),
              Comp("!")),
          Clause(Comp("aiml_eval_node", B, U, Comp("t_star", I), Stars, D, Val),
              Comp("nth1", I, Stars, Val),
              Comp("!")),
          Clause(Comp("aiml_eval_node", B, U, Comp("t_star", I), Stars, D, listNil()), Comp("!")),
          Clause(Comp("aiml_eval_node", B, U, Comp("t_think", ValNodes), Stars, D, listNil()),
              Comp("aiml_eval_nodes", B, U, ValNodes, Stars, D, Var()),
              Comp("!")),
          Clause(Comp("aiml_eval_node", B, U, Comp("t_srai", ValNodes), Stars, D, Out),
              Comp("aiml_eval_nodes", B, U, ValNodes, Stars, D, In2),
              Comp("is", D1, Comp("+", D, Num(1))),
              Comp("aiml_reply_tokens_depth", B, U, In2, D1, Out),
              Comp("!")),
          Clause(Comp("aiml_eval_node", B, U, Comp("t_random", Items), Stars, D, Out),
              Comp("length", Items, Len),
              Comp("aiml_rand1", B, U, Len, K),
              Comp("nth1", K, Items, Choice),
              Comp("aiml_eval_nodes", B, U, Choice, Stars, D, Out),
              Comp("!")),
          Clause(Comp("aiml_eval_node", B, U, Node, Stars, D, listNil()))
      ));
    }

    /* -------------------------
     * Reply (token/chunks)
     * ------------------------- */
    {
      Obj B=Var(), U=Var(), In=Var(), Out=Var();
      definePred(prog, "aiml_reply_tokens", 4, Predicate(
          Clause(Comp("aiml_reply_tokens", B, U, In, Out),
              Comp("aiml_reply_tokens_depth", B, U, In, Num(0), Out))
      ));
    }

    {
      Obj B=Var(), U=Var(), In=Var(), D=Var(), Out=Var(), Topic=Var(), That=Var(), Best=Var();
      Obj Limit=Var();
      definePred(prog, "aiml_reply_tokens_depth", 5, Predicate(
          Clause(Comp("aiml_reply_tokens_depth", B, U, In, D, listNil()),
              Comp("aiml_depth_limit", Limit),
              Comp(">=", D, Limit),
              Comp("!")),
          Clause(Comp("aiml_reply_tokens_depth", B, U, In, D, Out),
              Comp("aiml_depth_limit", Limit),
              Comp("<", D, Limit),
              Comp("aiml_get_topic", B, U, Topic),
              Comp("aiml_get_that", B, U, That),
              Comp("aiml_best_item", B, Topic, That, In, Best),
              Comp("=", Best, Atom("none")),
              Comp("!"),
              Comp("=", Out, listCons(Atom("I_DONT_UNDERSTAND"), listNil())),
              Comp("aiml_set_that", B, U, Out)
          ),
          Clause(Comp("aiml_reply_tokens_depth", B, U, In, D, Out),
              Comp("aiml_depth_limit", Limit),
              Comp("<", D, Limit),
              Comp("aiml_get_topic", B, U, Topic),
              Comp("aiml_get_that", B, U, That),
              Comp("aiml_best_item", B, Topic, That, In, Best),
              Comp("aiml_eval_best", B, U, Best, D, Out),
              Comp("aiml_set_that", B, U, Out),
              Comp("!"))
      ));
    }

    {
      Obj B=Var(), U=Var(), D=Var(), Out=Var(), Score=Var(), Tpl=Var(), Stars=Var();
      definePred(prog, "aiml_eval_best", 5, Predicate(
          Clause(Comp("aiml_eval_best", B, U, Comp("item", Score, Tpl, Stars), D, Out),
              Comp("aiml_eval_nodes", B, U, Tpl, Stars, D, Out))
      ));
    }

    /* -------------------------
     * Reply (text) wrapper using builtins
     * ------------------------- */
    {
      Obj B=Var(), U=Var(), InText=Var(), Reply=Var(), InTok=Var(), OutChunks=Var();
      definePred(prog, "aiml_reply", 4, Predicate(
          Clause(Comp("aiml_reply", B, U, InText, Reply),
              Comp("aiml_tokenize", InText, InTok),
              Comp("aiml_reply_tokens", B, U, InTok, OutChunks),
              Comp("aiml_detokenize", OutChunks, Reply))
      ));
    }
  }
}
