package com.mycompany.prolog;

import java.util.*;

import static com.mycompany.prolog.MiniPrologProto.*;

/** Quick debugging harness for the prototype stack. */
public final class PrototypeDebugMain {
  private PrototypeDebugMain(){}

  static Obj conj(Obj... gs){
    if(gs==null || gs.length==0) return Comp("true");
    Obj out = gs[gs.length-1];
    for(int i=gs.length-2;i>=0;i--) out = Comp(",", gs[i], out);
    return out;
  }

  public static void main(String[] args){
    Obj prog = MiniPrologProto.buildProgramWithSample();
    OopPrologLib.load(prog);
    ColumnDbLib.load(prog);
    PlannerStrategiesLib.load(prog);
    HtnDemoLib.load(prog);

    System.out.println("oop_init sols=" + query(prog, Comp("oop_init")).size());
    System.out.println("columndb_init sols=" + query(prog, Comp("columndb_init")).size());
    System.out.println("planner_param_init sols=" + query(prog, Comp("planner_param_init")).size());

    Obj P0=Var(), M0=Var(), S0=Var(), B0=Var();
    System.out.println("method/4 total after inits=" + query(prog, Comp("method", P0, M0, S0, B0)).size());

    // Sanity-check patched assertz/1 captures bindings: (X=1, assertz(p(X))) should assert p(1)
    Obj Xp=Var();
    query(prog, Comp("assertz", Comp("p", Num(123)))); // ensure p/1 exists
    List<Map<Integer,Obj>> as = query(prog, Comp(",", Comp("=", Xp, Num(1)), Comp("assertz", Comp("p", Xp))));
    System.out.println("assertz(binding) sols=" + as.size());
    System.out.println("p(1) sols=" + query(prog, Comp("p", Num(1))).size());

    // Test assertz capture with nested structure: assertz(method(P,M,...)) with P and M bound
    Obj Pm=Var(), Mv=Var(), Z=Var();
    query(prog, Comp("retract_all", Comp("method", Var(), Var(), Var(), Var())));
    List<Map<Integer,Obj>> a2 = query(prog,
        conj(
            Comp("=", Pm, Atom("protoX")),
            Comp("=", Mv, Comp("msg", Z)),
            Comp("assertz", Comp("method", Pm, Mv, Atom("s"), Atom("b")))
        )
    );
    System.out.println("assertz(method capture) sols=" + a2.size());
    Obj Mq=Var();
    System.out.println("method(protoX,msg/1) sols=" +
        query(prog, Comp("method", Atom("protoX"), Comp("msg", Mq), Var(), Var())).size());

    // Sanity-check defmethod/4 actually asserts into method/4
    Obj X=Var(), SSelf=Var();
    System.out.println("defmethod sanity sols=" +
        query(prog, Comp("defmethod", Atom("testProto"), Comp("foo", X), SSelf, Atom("true"))).size());
    Obj Pchk=Var(), Mchk=Var(), Schk=Var(), Bchk=Var();
    List<Map<Integer,Obj>> mchk = query(prog, Comp("method", Atom("testProto"), Mchk, Schk, Bchk));
    System.out.println("method(testProto,_) sols=" + mchk.size());

    // Re-run oop_init and columndb_init to restore state after the destructive retract_all test above
    query(prog, Comp("oop_init"));
    query(prog, Comp("columndb_init"));

    // Inspect whether dbProto.create_table method exists
    Obj N=Var(), S=Var(), T=Var(), SelfM=Var(), Body=Var();
    List<Map<Integer,Obj>> m1 = query(prog, Comp("method", Atom("dbProto"), Comp("create_table", N, S, T), SelfM, Body));
    System.out.println("method(dbProto,create_table/3) sols=" + m1.size());

    Obj Pany=Var(), Many=Var(), Sany=Var(), Bany=Var();
    List<Map<Integer,Obj>> mall = query(prog, Comp("method", Pany, Many, Sany, Bany));
    System.out.println("method/4 total clauses (solutions)=" + mall.size());
    if(!mall.isEmpty()){
      Obj p = mall.get(0).get(Pany.get(K_VID));
      Obj m = mall.get(0).get(Many.get(K_VID));
      System.out.println("first method: proto=" + pp(p) + " msg=" + pp(m));
    }

    Obj DB = Var();
    List<Map<Integer,Obj>> sClone = query(prog, Comp("clone", Atom("dbProto"), DB));
    System.out.println("clone dbProto sols=" + sClone.size());
    if(sClone.isEmpty()) return;
    Obj dbVal = sClone.get(0).get(DB.get(K_VID));

    // Step-by-step seeding debug
    Obj TOrders = Var();
    Obj SchemaOrders = list(
        Comp("col", Atom("id"), Atom("num"), Atom("opts")),
        Comp("col", Atom("customer"), Atom("atom"), Atom("opts"))
    );
    System.out.println("create_table orders sols=" +
        query(prog, Comp("send", dbVal, Comp("create_table", Atom("orders"), SchemaOrders, TOrders))).size());

    // After create_table, try list_tables
    Obj Names = Var();
    List<Map<Integer,Obj>> sTables1 = query(prog, Comp("send", dbVal, Comp("list_tables", Names)));
    System.out.println("list_tables(after orders) sols=" + sTables1.size());
    if(!sTables1.isEmpty()){
      System.out.println("tables=" + pp(sTables1.get(0).get(Names.get(K_VID))));
    }

    // Try full demo_seed
    System.out.println("demo_seed sols=" + query(prog, Comp("demo_seed", dbVal)).size());

    Obj Names2 = Var();
    List<Map<Integer,Obj>> sTables2 = query(prog, Comp("send", dbVal, Comp("list_tables", Names2)));
    System.out.println("list_tables(final) sols=" + sTables2.size());
    if(!sTables2.isEmpty()){
      System.out.println("tables=" + pp(sTables2.get(0).get(Names2.get(K_VID))));
    }
  }
}
