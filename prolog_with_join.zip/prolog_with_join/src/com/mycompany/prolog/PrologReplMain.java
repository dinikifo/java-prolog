package com.mycompany.prolog;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;

import static com.mycompany.prolog.MiniPrologProto.*;

/**
 * Interactive REPL for MiniPrologProto.
 *
 * Run:
 *   ./build.sh
 *   java -cp out com.mycompany.prolog.PrologReplMain
 *
 * Helpful commands:
 *   :help
 *   :stack sample|full
 *   :consult path/to/file.pl
 *   :predicates
 *   :reset
 *   :quit
 */
public final class PrologReplMain {

  static final String PROMPT_MAIN = "?- ";
  static final String PROMPT_CONT = "|  ";

  static final class ReplState {
    Obj prog;
    boolean fullStack = true;
  }

  public static void main(String[] args) throws Exception {
    ReplState st = new ReplState();
    st.fullStack = true;

    for(String a: args){
      if("--sample".equals(a)) st.fullStack = false;
      if("--full".equals(a)) st.fullStack = true;
    }

    st.prog = st.fullStack ? buildProgramWithPrototypeStack() : buildProgramWithSample();

    System.out.println("MiniPrologProto REPL");
    System.out.println("Type :help for commands. End statements with a dot '.'");
    System.out.println(st.fullStack ? "Loaded: full stack (OO + ColumnDB + Planner)" : "Loaded: sample program");
    System.out.println();

    BufferedReader br = new BufferedReader(new InputStreamReader(System.in, StandardCharsets.UTF_8));

    StringBuilder buf = new StringBuilder();
    String prompt = PROMPT_MAIN;

    while(true){
      System.out.print(prompt);
      System.out.flush();

      String line = br.readLine();
      if(line==null) break;

      String trimmed = line.trim();

      // command mode only when not mid-statement
      if(buf.length()==0 && trimmed.startsWith(":")){
        if(handleCommand(st, trimmed, br)) break;
        continue;
      }

      buf.append(line).append('\n');

      if(!looksStatementComplete(buf.toString())){
        prompt = PROMPT_CONT;
        continue;
      }

      String src = buf.toString().trim();
      buf.setLength(0);
      prompt = PROMPT_MAIN;

      if(src.isEmpty()) continue;

      try{
        PrologTextParser.Statement stmt = PrologTextParser.parseStatement(src);

        if(stmt instanceof PrologTextParser.ClauseStmt){
          PrologTextParser.ClauseStmt cs = (PrologTextParser.ClauseStmt) stmt;

          // assert clause
          query(st.prog, Comp("assertz", cs.clauseTerm));
          System.out.println("true.");
          continue;
        }

        if(stmt instanceof PrologTextParser.DirectiveStmt){
          PrologTextParser.DirectiveStmt ds = (PrologTextParser.DirectiveStmt) stmt;

          runQuery(st, ds.goal, ds.vars, br);
          continue;
        }

        if(stmt instanceof PrologTextParser.QueryStmt){
          PrologTextParser.QueryStmt qs = (PrologTextParser.QueryStmt) stmt;

          runQuery(st, qs.goal, qs.vars, br);
          continue;
        }

        System.out.println("false.");
      }catch(PrologTextParser.IncompleteInput inc){
        // Shouldn't happen because looksStatementComplete tries to prevent it,
        // but keep a graceful path.
        buf.append(src).append('\n');
        prompt = PROMPT_CONT;
      }catch(Exception e){
        System.out.println("ERROR: "+e.getMessage());
      }
    }
  }

  static boolean handleCommand(ReplState st, String cmdLine, BufferedReader br) throws Exception {
    String[] parts = cmdLine.trim().split("\\s+", 2);
    String cmd = parts[0];

    switch(cmd){
      case ":q":
      case ":quit":
      case ":exit":
        return true;

      case ":help":
        System.out.println("Commands:");
        System.out.println("  :help                 show this help");
        System.out.println("  :quit | :q            exit");
        System.out.println("  :reset                rebuild program (preserves chosen stack)");
        System.out.println("  :stack sample|full    switch base program");
        System.out.println("  :consult <file>       load facts/rules from a .pl file (assertz)");
        System.out.println("  :predicates           list current predicate indicators");
        System.out.println();
        return false;

      case ":reset":
        st.prog = st.fullStack ? buildProgramWithPrototypeStack() : buildProgramWithSample();
        System.out.println("true.");
        return false;

      case ":stack":
        if(parts.length<2){
          System.out.println("ERROR: usage :stack sample|full");
          return false;
        }
        String which = parts[1].trim();
        if("sample".equalsIgnoreCase(which)){
          st.fullStack = false;
          st.prog = buildProgramWithSample();
          System.out.println("true.");
          return false;
        }
        if("full".equalsIgnoreCase(which) || "prototype".equalsIgnoreCase(which)){
          st.fullStack = true;
          st.prog = buildProgramWithPrototypeStack();
          System.out.println("true.");
          return false;
        }
        System.out.println("ERROR: unknown stack '"+which+"'");
        return false;

      case ":consult":
        if(parts.length<2){
          System.out.println("ERROR: usage :consult path/to/file.pl");
          return false;
        }
        consultFile(st, parts[1].trim());
        System.out.println("true.");
        return false;

      case ":predicates":
        List<String> keys = new ArrayList<>(st.prog.get(K_PREDICATES).keySet());
        Collections.sort(keys);
        for(String k: keys) System.out.println(k);
        System.out.println("true.");
        return false;

      default:
        System.out.println("ERROR: unknown command. Try :help");
        return false;
    }
  }

  static void consultFile(ReplState st, String path) throws IOException {
    Path p = Paths.get(path);
    if(!Files.exists(p)) throw new IOException("file not found: "+p.toAbsolutePath());
    String text = Files.readString(p, StandardCharsets.UTF_8);

    for(String stmtSrc : splitStatements(text)){
      String s = stmtSrc.trim();
      if(s.isEmpty()) continue;
      PrologTextParser.Statement stmt = PrologTextParser.parseStatement(s);
      if(stmt instanceof PrologTextParser.ClauseStmt){
          PrologTextParser.ClauseStmt cs = (PrologTextParser.ClauseStmt) stmt;

        query(st.prog, Comp("assertz", cs.clauseTerm));
      } else if(stmt instanceof PrologTextParser.DirectiveStmt){
          PrologTextParser.DirectiveStmt ds = (PrologTextParser.DirectiveStmt) stmt;

        // run directive at consult time
        query(st.prog, ds.goal);
      } else if(stmt instanceof PrologTextParser.QueryStmt){
        // ignore queries in consulted files
      }
    }
  }

  static List<String> splitStatements(String src){
    // Split by top-level '.' tokens (not inside quotes or brackets/parens).
    List<String> out = new ArrayList<>();
    StringBuilder cur = new StringBuilder();

    int par=0, br=0;
    boolean inS=false, inD=false;
    boolean esc=false;

    for(int idx=0; idx<src.length(); idx++){
      char c = src.charAt(idx);
      cur.append(c);

      if(esc){
        esc=false;
        continue;
      }
      if(inS){
        if(c=='\\') { esc=true; continue; }
        if(c=='\'') inS=false;
        continue;
      }
      if(inD){
        if(c=='\\') { esc=true; continue; }
        if(c=='"') inD=false;
        continue;
      }

      if(c=='\''){ inS=true; continue; }
      if(c=='"'){ inD=true; continue; }

      if(c=='(') par++;
      else if(c==')' && par>0) par--;
      else if(c=='[') br++;
      else if(c==']' && br>0) br--;

      if(c=='.' && par==0 && br==0){
        out.add(cur.toString());
        cur.setLength(0);
      }
    }

    if(cur.toString().trim().length()>0){
      // leftover without dot: ignore (likely trailing whitespace) or treat as incomplete
      // We'll append it so consult shows a parse error if non-empty.
      out.add(cur.toString());
    }
    return out;
  }

  static void runQuery(ReplState st, Obj goal, LinkedHashMap<String, Obj> vars, BufferedReader br) throws IOException {
    List<Map<Integer, Obj>> sols = query(st.prog, goal);

    if(sols.isEmpty()){
      System.out.println("false.");
      return;
    }

    // If there are no user-visible vars, SWI prints 'true.'
    boolean anyNamed = vars.values().stream().anyMatch(v -> v!=null);

    for(int i=0; i<sols.size(); i++){
      Map<Integer, Obj> sol = sols.get(i);

      if(vars.isEmpty() || !anyNamed){
        System.out.print("true");
      } else {
        System.out.print(formatBindings(vars, sol));
      }

      if(i==sols.size()-1){
        System.out.println(".");
        break;
      } else {
        System.out.print(" ;");
        System.out.flush();
        String resp = br.readLine();
        if(resp==null) { System.out.println("."); break; }
        String t = resp.trim();
        if(";".equals(t)){
          System.out.println();
          continue;
        }
        // anything else stops
        System.out.println(".");
        break;
      }
    }
  }

  static String formatBindings(LinkedHashMap<String, Obj> vars, Map<Integer, Obj> sol){
    // Build var-id -> name map for printing nested vars nicely.
    Map<Integer, String> idToName = new HashMap<>();
    for(Map.Entry<String, Obj> e : vars.entrySet()){
      if(e.getValue()==null) continue;
      idToName.put(e.getValue().get(K_VID), e.getKey());
    }

    StringBuilder sb = new StringBuilder();
    boolean first=true;

    for(Map.Entry<String, Obj> e : vars.entrySet()){
      String name = e.getKey();
      Obj v = e.getValue();
      if(v==null) continue;

      Obj val = sol.get(v.get(K_VID));
      if(val==null) val = v; // unbound

      if(!first) sb.append(", ");
      first=false;

      sb.append(name).append(" = ").append(ppWithNames(val, idToName, new IdentityHashMap<>()));
    }

    if(first) return "true";
    return sb.toString();
  }

  static String ppWithNames(Obj t, Map<Integer,String> idToName, IdentityHashMap<Obj,Boolean> seen){
    t = deref(t, new Trail());
    if(seen.put(t, Boolean.TRUE)!=null) return "<cycle>";
    Tag tag = t.get(K_TAG);

    if(tag==Tag.VAR){
      String n = idToName.get(t.get(K_VID));
      if(n!=null) return n;
      return "_"+t.get(K_VID);
    }
    if(tag==Tag.ATOM){
      String s = t.get(K_NAME);
      // quote atoms with spaces or punctuation that would confuse a re-read
      if(needsQuoting(s)) return "'" + s.replace("\\", "\\\\").replace("'", "\\'") + "'";
      return s;
    }
    if(tag==Tag.NUM){
      return t.get(K_NAME);
    }
    if(tag==Tag.COMP){
      String f=t.get(K_NAME);
      int ar=t.get(K_ARITY);

      // list sugar
      if(isListLike(t)) return ppListWithNames(t, idToName, seen);

      // JSON string term: str(Atom("...")) -> "..."
      if("str".equals(f) && ar==1){
        String s = termToJavaString(t, new Trail());
        return "\"" + MiniPrologProto.Json.escape(s) + "\"";
      }

      StringBuilder sb=new StringBuilder();
      sb.append(f).append('(');
      List<Obj> as=t.get(K_ARGS);
      for(int i=0;i<as.size();i++){
        if(i>0) sb.append(',');
        sb.append(ppWithNames(as.get(i), idToName, seen));
      }
      sb.append(')');
      return sb.toString();
    }
    return "?";
  }

  static String ppListWithNames(Obj t, Map<Integer,String> idToName, IdentityHashMap<Obj,Boolean> seen){
    StringBuilder sb=new StringBuilder();
    sb.append('[');
    Obj cur = t;
    boolean first=true;

    while(true){
      cur = deref(cur, new Trail());
      if(isNil(cur)){
        sb.append(']');
        return sb.toString();
      }
      if(!isCons(cur)){
        if(!first) sb.append('|');
        sb.append(ppWithNames(cur, idToName, seen)).append(']');
        return sb.toString();
      }

      Obj h = cur.get(K_ARGS).get(0);
      Obj tail = cur.get(K_ARGS).get(1);
      if(!first) sb.append(',');
      sb.append(ppWithNames(h, idToName, seen));
      first=false;
      cur = tail;
    }
  }

  static boolean needsQuoting(String atom){
    if(atom.isEmpty()) return true;
    // safe bare atoms: lowercase start, then [a-zA-Z0-9_]*
    char c0 = atom.charAt(0);
    if(!(c0>='a' && c0<='z')) return true;
    for(int i=1;i<atom.length();i++){
      char c = atom.charAt(i);
      if(!(Character.isLetterOrDigit(c) || c=='_')) return true;
    }
    return false;
  }

  static boolean looksStatementComplete(String src){
    // Heuristic: a top-level '.' exists (not inside quotes or bracket/paren nesting)
    int par=0, br=0;
    boolean inS=false, inD=false;
    boolean esc=false;

    for(int i=0;i<src.length();i++){
      char c = src.charAt(i);

      if(esc){ esc=false; continue; }
      if(inS){
        if(c=='\\'){ esc=true; continue; }
        if(c=='\'') inS=false;
        continue;
      }
      if(inD){
        if(c=='\\'){ esc=true; continue; }
        if(c=='"') inD=false;
        continue;
      }

      if(c=='\''){ inS=true; continue; }
      if(c=='"'){ inD=true; continue; }

      if(c=='(') par++;
      else if(c==')' && par>0) par--;
      else if(c=='[') br++;
      else if(c==']' && br>0) br--;

      if(c=='.' && par==0 && br==0){
        // ensure something after dot is only whitespace/comments
        // We'll treat it as complete and let the real parser validate.
        return true;
      }
    }
    return false;
  }

  private PrologReplMain(){}
}
