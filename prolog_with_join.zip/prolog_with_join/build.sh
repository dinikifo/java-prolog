#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$ROOT"

rm -rf out
mkdir -p out

# Stage 1: core compiler unit.
# MiniPrologProto references Person in selftests, so compile those together.
javac -encoding UTF-8 -d out \
  src/com/mycompany/prolog/Address.java \
  src/com/mycompany/prolog/Person.java \
  src/com/mycompany/prolog/MiniPrologProto.java

# Stage 2: everything else, using the already-built core on the classpath.
# (Keeps compilation snappy and avoids javac doing expensive whole-project work twice.)
find src -name "*.java" \
  | grep -vE '/(Address|Person|MiniPrologProto)\.java$' \
  > sources_stage2.txt

javac -encoding UTF-8 -cp out -d out @sources_stage2.txt

echo "Built to: $ROOT/out"
