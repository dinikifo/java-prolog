#!/usr/bin/env python3
"""
MiniPrologProto IDE - A GUI development environment for the Java-based Prolog interpreter
"""

import sys
import os
import subprocess
import re
from PyQt6.QtWidgets import (QApplication, QMainWindow, QWidget, QVBoxLayout,
                             QHBoxLayout, QTextEdit, QPlainTextEdit, QPushButton,
                             QSplitter, QLabel, QTabWidget, QFileDialog, QMessageBox,
                             QToolBar, QStatusBar, QComboBox, QTreeWidget, QTreeWidgetItem,
                             QLineEdit)
from PyQt6.QtGui import (QFont, QSyntaxHighlighter, QTextCharFormat, QColor, 
                        QAction, QTextCursor, QKeySequence)
from PyQt6.QtCore import Qt, QRegularExpression, pyqtSignal, QProcess


class PrologSyntaxHighlighter(QSyntaxHighlighter):
    """Syntax highlighter for Prolog-like code"""
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.highlighting_rules = []
        
        # Keywords
        keyword_format = QTextCharFormat()
        keyword_format.setForeground(QColor("#569CD6"))
        keyword_format.setFontWeight(QFont.Weight.Bold)
        keywords = [
            'assertz', 'retract', 'clone', 'send', 'get', 'put', 
            'defmethod', 'query', 'findall', 'bagof', 'setof',
            'oop_init', 'columndb_init', 'planner_param_init',
            'create_table', 'create_index', 'insert', 'select', 'count', 'where',
            'join_json',
            'json_parse', 'json_stringify',
            'from_json', 'to_json', 'release_ref', 'clear_heap', 'heap_size',
            'new_ctx', 'plan', 'demo_plan', 'primitive', 'method', 'op',
            'true', 'fail', 'call', 'once', 'is'
        ]
        for word in keywords:
            pattern = QRegularExpression(f'\\b{word}\\b')
            self.highlighting_rules.append((pattern, keyword_format))
        
        # Comments
        comment_format = QTextCharFormat()
        comment_format.setForeground(QColor("#6A9955"))
        comment_format.setFontItalic(True)
        self.highlighting_rules.append((QRegularExpression('%.*'), comment_format))
        self.highlighting_rules.append((QRegularExpression('//.*'), comment_format))
        
        # Strings
        string_format = QTextCharFormat()
        string_format.setForeground(QColor("#CE9178"))
        self.highlighting_rules.append((QRegularExpression('"[^"]*"'), string_format))
        self.highlighting_rules.append((QRegularExpression("'[^']*'"), string_format))
        
        # Atoms
        atom_format = QTextCharFormat()
        atom_format.setForeground(QColor("#4EC9B0"))
        self.highlighting_rules.append((QRegularExpression('\\b[a-z][a-zA-Z0-9_]*'), atom_format))
        
        # Variables
        var_format = QTextCharFormat()
        var_format.setForeground(QColor("#9CDCFE"))
        self.highlighting_rules.append((QRegularExpression('\\b[A-Z][a-zA-Z0-9_]*'), var_format))
        
        # Numbers
        number_format = QTextCharFormat()
        number_format.setForeground(QColor("#B5CEA8"))
        self.highlighting_rules.append((QRegularExpression('\\b[0-9]+\\b'), number_format))
        
        # Operators
        operator_format = QTextCharFormat()
        operator_format.setForeground(QColor("#D4D4D4"))
        operators = [':-', '->', ',', ';', '!', '\\+', '=', '==', '\\=', 
                    '=:=', '=\\=', '<', '=<', '>', '>=', '+', '-', '*', '/']
        for op in operators:
            pattern = QRegularExpression(re.escape(op))
            self.highlighting_rules.append((pattern, operator_format))
    
    def highlightBlock(self, text):
        for pattern, fmt in self.highlighting_rules:
            iterator = pattern.globalMatch(text)
            while iterator.hasNext():
                match = iterator.next()
                self.setFormat(match.capturedStart(), match.capturedLength(), fmt)


class CodeGenerator:
    """Converts Prolog-like syntax to Java API calls"""
    
    @staticmethod
    def generate_java_code(prolog_code, template="query"):
        """Generate Java code from Prolog-like syntax"""
        
        if template == "query":
            return CodeGenerator._generate_query_code(prolog_code)
        elif template == "full_stack":
            return CodeGenerator._generate_full_stack_code(prolog_code)
        elif template == "oo_example":
            return CodeGenerator._generate_oo_example(prolog_code)
        elif template == "db_example":
            return CodeGenerator._generate_db_example(prolog_code)
        else:
            return CodeGenerator._generate_query_code(prolog_code)
    
    @staticmethod
    def _generate_query_code(prolog_code):
        """Generate basic query code"""
        code = """import java.util.*;
import static com.mycompany.prolog.MiniPrologProto.*;

public class PrologQuery {
    public static void main(String[] args) {
        // Build program with sample predicates
        Obj prog = MiniPrologProto.buildProgramWithSample();
        
        // Create variables
        Obj X = Var();
        Obj Y = Var();
        
        // Build goal
        // TODO: Construct your goal here
        // Example: Obj goal = Comp("append", list(Num(1), Num(2)), list(Num(3)), X);
        
        Obj goal = Atom("true");  // Replace with your goal
        
        // Execute query
        List<Map<Integer, Obj>> solutions = query(prog, goal);
        
        // Print results
        System.out.println("Solutions found: " + solutions.size());
        for (int i = 0; i < solutions.size(); i++) {
            System.out.println("Solution " + (i+1) + ":");
            Map<Integer, Obj> sol = solutions.get(i);
            
            // Print variable bindings
            System.out.println("  X = " + pp(sol.get(X.get(K_VID))));
            // Add more variables as needed
        }
    }
}

/* Your Prolog code:
""" + prolog_code + """
*/"""
        return code
    
    @staticmethod
    def _generate_full_stack_code(prolog_code):
        """Generate full stack initialization code"""
        code = """import java.util.*;
import static com.mycompany.prolog.MiniPrologProto.*;
import com.mycompany.prolog.*;

public class FullStackExample {
    public static void main(String[] args) {
        // Build full stack program
        Obj prog = buildFullStackProgram();
        
        // Initialize all layers
        query(prog, Comp("oop_init"));
        query(prog, Comp("columndb_init"));
        query(prog, Comp("planner_param_init"));
        
        // Your code here
        
        System.out.println("Full stack initialized successfully!");
    }
    
    public static Obj buildFullStackProgram() {
        Obj prog = MiniPrologProto.buildProgramWithSample();
        OopPrologLib.load(prog);
        ColumnDbLib.load(prog);
        PlannerStrategiesLib.load(prog);
        HtnDemoLib.load(prog);
        return prog;
    }
}

/* Your Prolog code:
""" + prolog_code + """
*/"""
        return code
    
    @staticmethod
    def _generate_oo_example(prolog_code):
        """Generate OO example code"""
        code = """import java.util.*;
import static com.mycompany.prolog.MiniPrologProto.*;
import com.mycompany.prolog.*;

public class OOExample {
    public static void main(String[] args) {
        // Setup
        Obj prog = MiniPrologProto.emptyProgram();
        OopPrologLib.load(prog);
        query(prog, Comp("oop_init"));
        
        // Create an object
        Obj O = Var();
        var sols = query(prog, Comp("clone", Atom("objectProto"), O));
        Obj objVal = sols.get(0).get(O.get(K_VID));
        
        // Set a slot
        query(prog, Comp("put", objVal, Atom("name"), Atom("ada")));
        
        // Get a slot
        Obj Name = Var();
        sols = query(prog, Comp("get", objVal, Atom("name"), Name));
        System.out.println("Name = " + pp(sols.get(0).get(Name.get(K_VID))));
    }
}

/* Your Prolog code:
""" + prolog_code + """
*/"""
        return code
    
    @staticmethod
    def _generate_db_example(prolog_code):
        """Generate database example code"""
        code = """import java.util.*;
import static com.mycompany.prolog.MiniPrologProto.*;
import com.mycompany.prolog.*;

public class DBExample {
    public static void main(String[] args) {
        // Setup
        Obj prog = MiniPrologProto.emptyProgram();
        OopPrologLib.load(prog);
        ColumnDbLib.load(prog);
        query(prog, Comp("oop_init"));
        query(prog, Comp("columndb_init"));
        
        // Create DB
        Obj DB = Var();
        var sols = query(prog, Comp("clone", Atom("dbProto"), DB));
        Obj dbVal = sols.get(0).get(DB.get(K_VID));
        
        // Define schema
        Obj schema = list(
            Comp("col", Atom("id"), Atom("num"), Atom("opts")),
            Comp("col", Atom("name"), Atom("atom"), Atom("opts"))
        );
        
        // Create table
        Obj T = Var();
        sols = query(prog, Comp("send", dbVal, 
            Comp("create_table", Atom("people"), schema, T)));
        Obj tableVal = sols.get(0).get(T.get(K_VID));
        
        // Insert row
        Obj row = Comp("row", list(
            Comp("=", Atom("id"), Num(1)),
            Comp("=", Atom("name"), Atom("alice"))
        ));
        query(prog, Comp("send", tableVal, Comp("insert", row)));
        
        // Select
        Obj Out = Var();
        sols = query(prog, Comp("send", tableVal,
            Comp("select", Atom("all"), Atom("all"), 
                Comp("opts", Comp("limit", Atom("all"))), Out)));
        
        System.out.println("Results: " + pp(sols.get(0).get(Out.get(K_VID))));
    }
}

/* Your Prolog code:
""" + prolog_code + """
*/"""
        return code


class CodeEditor(QPlainTextEdit):
    """Enhanced code editor with line numbers"""
    
    def __init__(self, parent=None):
        super().__init__(parent)
        font = QFont("Courier New", 11)
        self.setFont(font)
        self.setTabStopDistance(40)
        
        # Set dark theme colors
        self.setStyleSheet("""
            QPlainTextEdit {
                background-color: #1E1E1E;
                color: #D4D4D4;
                border: 1px solid #3C3C3C;
            }
        """)


class ConsoleWidget(QTextEdit):
    """Console for displaying output"""
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setReadOnly(True)
        font = QFont("Courier New", 10)
        self.setFont(font)
        self.setStyleSheet("""
            QTextEdit {
                background-color: #1E1E1E;
                color: #CCCCCC;
                border: 1px solid #3C3C3C;
            }
        """)
    
    def append_output(self, text, color="#CCCCCC"):
        """Append colored text to console"""
        self.setTextColor(QColor(color))
        self.append(text)
        self.verticalScrollBar().setValue(self.verticalScrollBar().maximum())

    def append_raw(self, text, color="#CCCCCC"):
        """Append raw text (no implicit newline) to console."""
        self.setTextColor(QColor(color))
        self.moveCursor(QTextCursor.MoveOperation.End)
        self.insertPlainText(text)
        self.verticalScrollBar().setValue(self.verticalScrollBar().maximum())
    
    def append_error(self, text):
        """Append error text in red"""
        self.append_output(text, "#F48771")
    
    def append_success(self, text):
        """Append success text in green"""
        self.append_output(text, "#4EC9B0")
    
    def append_info(self, text):
        """Append info text in blue"""
        self.append_output(text, "#569CD6")


class ExampleTreeWidget(QTreeWidget):
    """Tree widget showing example code snippets"""
    
    example_selected = pyqtSignal(str, str)
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setHeaderLabel("Examples & Templates")
        self.itemDoubleClicked.connect(self._on_item_clicked)
        self._populate_examples()
    
    def _populate_examples(self):
        """Populate the tree with examples"""
        
        # Basic Examples
        basic = QTreeWidgetItem(self, ["Basic Examples"])
        basic.setExpanded(True)
        
        item = QTreeWidgetItem(basic, ["Simple Query"])
        item.setData(0, Qt.ItemDataRole.UserRole, self._get_simple_query())
        
        item = QTreeWidgetItem(basic, ["List Operations"])
        item.setData(0, Qt.ItemDataRole.UserRole, self._get_list_example())
        
        item = QTreeWidgetItem(basic, ["Arithmetic"])
        item.setData(0, Qt.ItemDataRole.UserRole, self._get_arithmetic_example())
        
        # OO Examples
        oo = QTreeWidgetItem(self, ["Object-Oriented"])
        oo.setExpanded(False)
        
        item = QTreeWidgetItem(oo, ["Create Object"])
        item.setData(0, Qt.ItemDataRole.UserRole, self._get_oo_basic())
        
        item = QTreeWidgetItem(oo, ["Methods"])
        item.setData(0, Qt.ItemDataRole.UserRole, self._get_oo_methods())
        
        # Database Examples
        db = QTreeWidgetItem(self, ["Database"])
        db.setExpanded(False)
        
        item = QTreeWidgetItem(db, ["Create Table"])
        item.setData(0, Qt.ItemDataRole.UserRole, self._get_db_basic())
        
        item = QTreeWidgetItem(db, ["Query Data"])
        item.setData(0, Qt.ItemDataRole.UserRole, self._get_db_query())

        item = QTreeWidgetItem(db, ["JSON Join (join_json)"])
        item.setData(0, Qt.ItemDataRole.UserRole, self._get_db_join())

        # JSON Examples
        js = QTreeWidgetItem(self, ["JSON & POJOs"])
        js.setExpanded(False)

        item = QTreeWidgetItem(js, ["JSON parse/stringify"])
        item.setData(0, Qt.ItemDataRole.UserRole, self._get_json_basic())

        item = QTreeWidgetItem(js, ["POJO mapping (from_json/to_json)"])
        item.setData(0, Qt.ItemDataRole.UserRole, self._get_json_pojo())
        
        # Planner Examples
        planner = QTreeWidgetItem(self, ["HTN Planner"])
        planner.setExpanded(False)
        
        item = QTreeWidgetItem(planner, ["Basic Planning"])
        item.setData(0, Qt.ItemDataRole.UserRole, self._get_planner_basic())
    
    def _on_item_clicked(self, item, column):
        """Handle double-click on example"""
        example = item.data(0, Qt.ItemDataRole.UserRole)
        if example:
            self.example_selected.emit(example, item.text(0))
    
    # Example code snippets
    def _get_simple_query(self):
        return """% Simple unification query
% ?- X = 42.

?- X = 42."""
    
    def _get_list_example(self):
        return """% List append example
% ?- append([1,2], [3,4], X).

?- append([1,2], [3,4], X)."""
    
    def _get_arithmetic_example(self):
        return """% Arithmetic evaluation
% ?- X is 5 + 3.

?- X is 5 + 3."""
    
    def _get_oo_basic(self):
        return """% Object system (prototype OO)
% Initialize, clone an object, set/get slots.

?- oop_init.
?- clone(objectProto, O),
   put(O, name, alice),
   put(O, age, 30),
   get(O, name, Name)."""
    
    def _get_oo_methods(self):
        return """% Define a method that returns a value via unification.
% (No printing built-in; query bindings show results.)

?- oop_init.
?- defmethod(objectProto, name_of(Name), Self,
       get(Self, name, Name)).
?- clone(objectProto, O), put(O, name, bob), send(O, name_of(N))."""
    
    def _get_db_basic(self):
        return """% ColumnDB: create a DB and a table

?- oop_init, columndb_init.
?- clone(dbProto, DB),
   send(DB, create_table(users,
     [col(id,int,[]), col(name,atom,[])],
     UsersT))."""
    
    def _get_db_query(self):
        return """% ColumnDB: insert + select

?- send(UsersT, insert(row([id=1, name=ada]))).
?- send(UsersT, insert(row([id=2, name=bob]))).

% Filter is where(Col, Op, Val). Supported ops: eq, ge.
?- send(UsersT, select(all, where(id, ge, 2), opts(limit(all)), Rows))."""

    def _get_db_join(self):
        return """% ColumnDB: JSON-driven equi-join (join_json)
% See README_JSON_JOINS.md for details.

?- oop_init, columndb_init.
?- clone(dbProto, DB),
   send(DB, create_table(users,  [col(id,int,[]), col(name,atom,[])],  UsersT)),
   send(DB, create_table(orders, [col(id,int,[]), col(user_id,int,[]), col(total,int,[])], OrdersT)).

?- send(UsersT,  insert(row([id=1, name=ada]))),
   send(UsersT,  insert(row([id=2, name=bob]))),
   send(OrdersT, insert(row([id=10, user_id=1, total=120]))),
   send(OrdersT, insert(row([id=11, user_id=1, total=40 ]))),
   send(OrdersT, insert(row([id=12, user_id=3, total=9  ]))).

% Optional, recommended: hash index on the RIGHT join key.
?- send(OrdersT, create_index(user_id, hash)).

?- Json = str('{"type":"left","left":"users","right":"orders","on":{"left":"id","right":"user_id"},"select":{"left":["id","name"],"right":["id","total"]},"where":{"right":{"col":"total","op":"ge","val":50}},"opts":{"qualify":true,"aliases":{"left":"u","right":"o"},"limit":50}}'),
   send(DB, join_json(Json, Rows))."""

    def _get_json_basic(self):
        return """% JSON <-> Term

?- json_parse(str('{"a":1,"b":[2,3],"c":"hi"}'), Term).
?- json_stringify(Term, BackToJson)."""

    def _get_json_pojo(self):
        return """% JSON <-> Java POJO mapping (reflection)
% Allowed class prefixes include com.mycompany.prolog.
% Person.java and Address.java are included in the repo.

?- from_json(str('{"name":"Ada","age":37}'), str('com.mycompany.prolog.Person'), Ref).
?- to_json(Ref, JsonOut).
?- release_ref(Ref)."""
    
    def _get_planner_basic(self):
        return """% Run HTN planner

?- oop_init, planner_param_init.
?- demo_plan(indexed, Plan)."""


class PrologIDE(QMainWindow):
    """Main IDE window"""
    
    def __init__(self):
        super().__init__()
        self.current_file = None
        
        # Try to find the prolog interpreter in common locations
        possible_paths = [
            # If this script lives inside the repo folder, this hits directly.
            os.path.dirname(os.path.abspath(__file__)),
            # Back-compat: if this script lives next to a prolog_real_final/ folder.
            os.path.join(os.path.dirname(os.path.abspath(__file__)), "prolog_real_final"),
            "/home/claude/prolog_real_final",
            os.path.expanduser("~/prolog_real_final"),
            "./prolog_real_final"
        ]
        
        self.prolog_path = None
        for path in possible_paths:
            if os.path.isdir(path):
                self.prolog_path = path
                break
        
        if not self.prolog_path:
            self.prolog_path = possible_paths[0]  # Use first option as default
        
        self.init_ui()
    
    def init_ui(self):
        """Initialize the user interface"""
        self.setWindowTitle("MiniPrologProto IDE")
        self.setGeometry(100, 100, 1400, 900)
        
        # Create central widget and main layout
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        main_layout = QVBoxLayout(central_widget)
        
        # Create main splitter (horizontal)
        main_splitter = QSplitter(Qt.Orientation.Horizontal)
        
        # Left panel: Examples tree
        self.examples_tree = ExampleTreeWidget()
        self.examples_tree.setMaximumWidth(300)
        self.examples_tree.example_selected.connect(self.load_example)
        main_splitter.addWidget(self.examples_tree)
        
        # Middle/Right panel: Code editor and console
        right_splitter = QSplitter(Qt.Orientation.Vertical)
        
        # Editor area with tabs
        self.editor_tabs = QTabWidget()
        self.editor_tabs.setTabsClosable(True)
        self.editor_tabs.tabCloseRequested.connect(self.close_tab)
        
        # Create first editor tab
        self.add_editor_tab("Untitled")
        
        right_splitter.addWidget(self.editor_tabs)
        
        # Template selector
        template_widget = QWidget()
        template_layout = QHBoxLayout(template_widget)
        template_layout.addWidget(QLabel("Java Template:"))
        
        self.template_combo = QComboBox()
        self.template_combo.addItems([
            "Basic Query",
            "Full Stack Init",
            "OO Example",
            "Database Example"
        ])
        template_layout.addWidget(self.template_combo)
        template_layout.addStretch()
        
        # Console output area
        console_container = QWidget()
        console_layout = QVBoxLayout(console_container)
        console_layout.setContentsMargins(0, 0, 0, 0)
        
        console_layout.addWidget(template_widget)
        
        self.console = ConsoleWidget()
        console_layout.addWidget(self.console)

        # REPL controls (interactive)
        repl_bar = QWidget()
        repl_bar_layout = QHBoxLayout(repl_bar)
        repl_bar_layout.setContentsMargins(0, 0, 0, 0)

        self.repl_input = QLineEdit()
        self.repl_input.setPlaceholderText("Type a Prolog statement (end with '.') or a command like :help")
        self.repl_input.returnPressed.connect(self.send_repl_input)

        self.repl_start_btn = QPushButton("Start REPL")
        self.repl_start_btn.clicked.connect(self.start_repl)

        self.repl_stop_btn = QPushButton("Stop REPL")
        self.repl_stop_btn.clicked.connect(self.stop_repl)
        self.repl_stop_btn.setEnabled(False)

        repl_bar_layout.addWidget(QLabel("REPL:"))
        repl_bar_layout.addWidget(self.repl_input)
        repl_bar_layout.addWidget(self.repl_start_btn)
        repl_bar_layout.addWidget(self.repl_stop_btn)

        console_layout.addWidget(repl_bar)

        self.repl_process = None
        
        # Generated Java code area
        java_label = QLabel("Generated Java Code:")
        console_layout.addWidget(java_label)
        
        self.java_code_view = QTextEdit()
        self.java_code_view.setReadOnly(True)
        self.java_code_view.setFont(QFont("Courier New", 10))
        self.java_code_view.setStyleSheet("""
            QTextEdit {
                background-color: #1E1E1E;
                color: #D4D4D4;
                border: 1px solid #3C3C3C;
            }
        """)
        console_layout.addWidget(self.java_code_view)
        
        right_splitter.addWidget(console_container)
        
        # Set splitter sizes
        right_splitter.setSizes([400, 400])
        
        main_splitter.addWidget(right_splitter)
        main_splitter.setSizes([250, 1150])
        
        main_layout.addWidget(main_splitter)
        
        # Status bar
        self.statusBar().showMessage("Ready")
        
        # Create toolbar after all widgets are created
        self.create_toolbar()
        
        # Welcome message
        self.console.append_info("=== MiniPrologProto IDE ===")
        
        if os.path.isdir(self.prolog_path):
            self.console.append_output("Prolog interpreter path: " + self.prolog_path)
        else:
            self.console.append_error(f"⚠ Prolog interpreter not found at: {self.prolog_path}")
            self.console.append_output("Build and Run features may not work.")
            self.console.append_output("You can still use the IDE for code editing and generation.")
        
        self.console.append_output("Ready to code!\n")
    
    def create_toolbar(self):
        """Create the toolbar"""
        toolbar = QToolBar()
        toolbar.setMovable(False)
        self.addToolBar(toolbar)
        
        # New file
        new_action = QAction("New", self)
        new_action.setShortcut(QKeySequence.StandardKey.New)
        new_action.triggered.connect(self.new_file)
        toolbar.addAction(new_action)
        
        # Open file
        open_action = QAction("Open", self)
        open_action.setShortcut(QKeySequence.StandardKey.Open)
        open_action.triggered.connect(self.open_file)
        toolbar.addAction(open_action)
        
        # Save file
        save_action = QAction("Save", self)
        save_action.setShortcut(QKeySequence.StandardKey.Save)
        save_action.triggered.connect(self.save_file)
        toolbar.addAction(save_action)
        
        toolbar.addSeparator()
        
        # Generate Java
        gen_action = QAction("Generate Java", self)
        gen_action.setShortcut("Ctrl+G")
        gen_action.triggered.connect(self.generate_java)
        toolbar.addAction(gen_action)
        
        # Build
        build_action = QAction("Build", self)
        build_action.setShortcut("Ctrl+B")
        build_action.triggered.connect(self.build_prolog)
        toolbar.addAction(build_action)
        
        # Run
        run_action = QAction("Run Demo", self)
        run_action.setShortcut("Ctrl+R")
        run_action.triggered.connect(self.run_demo)
        toolbar.addAction(run_action)

        # REPL
        repl_start_action = QAction("Start REPL", self)
        repl_start_action.setShortcut("Ctrl+E")
        repl_start_action.triggered.connect(self.start_repl)
        toolbar.addAction(repl_start_action)

        repl_stop_action = QAction("Stop REPL", self)
        repl_stop_action.setShortcut("Ctrl+Shift+E")
        repl_stop_action.triggered.connect(self.stop_repl)
        toolbar.addAction(repl_stop_action)
        
        toolbar.addSeparator()
        
        # Settings menu for path configuration
        settings_action = QAction("Settings", self)
        settings_action.triggered.connect(self.open_settings)
        toolbar.addAction(settings_action)
        
        # Clear console
        clear_action = QAction("Clear Console", self)
        clear_action.triggered.connect(self.console.clear)
        toolbar.addAction(clear_action)
    
    def get_current_editor(self):
        """Get the currently active editor"""
        current_widget = self.editor_tabs.currentWidget()
        if current_widget:
            return current_widget.findChild(CodeEditor)
        return None
    
    def add_editor_tab(self, title="Untitled", content=""):
        """Add a new editor tab"""
        container = QWidget()
        layout = QVBoxLayout(container)
        layout.setContentsMargins(0, 0, 0, 0)
        
        editor = CodeEditor()
        highlighter = PrologSyntaxHighlighter(editor.document())
        editor.setPlainText(content)
        
        layout.addWidget(editor)
        
        index = self.editor_tabs.addTab(container, title)
        self.editor_tabs.setCurrentIndex(index)
        
        return editor
    
    def close_tab(self, index):
        """Close an editor tab"""
        if self.editor_tabs.count() > 1:
            self.editor_tabs.removeTab(index)
        else:
            QMessageBox.warning(self, "Cannot Close", "Cannot close the last tab.")
    
    def new_file(self):
        """Create a new file"""
        self.add_editor_tab("Untitled")
        self.current_file = None
        self.statusBar().showMessage("New file created")
    
    def open_file(self):
        """Open a file"""
        filename, _ = QFileDialog.getOpenFileName(
            self, "Open File", "", 
            "Prolog Files (*.pl *.pro);;Java Files (*.java);;All Files (*)"
        )
        if filename:
            try:
                with open(filename, 'r') as f:
                    content = f.read()
                self.add_editor_tab(os.path.basename(filename), content)
                self.current_file = filename
                self.statusBar().showMessage(f"Opened: {filename}")
            except Exception as e:
                QMessageBox.critical(self, "Error", f"Could not open file: {str(e)}")
    
    def save_file(self):
        """Save the current file"""
        editor = self.get_current_editor()
        if not editor:
            return
        
        if not self.current_file:
            filename, _ = QFileDialog.getSaveFileName(
                self, "Save File", "", 
                "Prolog Files (*.pl);;Java Files (*.java);;All Files (*)"
            )
            if filename:
                self.current_file = filename
            else:
                return
        
        try:
            with open(self.current_file, 'w') as f:
                f.write(editor.toPlainText())
            self.statusBar().showMessage(f"Saved: {self.current_file}")
            
            # Update tab title
            current_index = self.editor_tabs.currentIndex()
            self.editor_tabs.setTabText(current_index, os.path.basename(self.current_file))
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Could not save file: {str(e)}")
    
    def generate_java(self):
        """Generate Java code from Prolog-like syntax"""
        editor = self.get_current_editor()
        if not editor:
            return
        
        prolog_code = editor.toPlainText()
        template_map = {
            "Basic Query": "query",
            "Full Stack Init": "full_stack",
            "OO Example": "oo_example",
            "Database Example": "db_example"
        }
        
        template = template_map[self.template_combo.currentText()]
        java_code = CodeGenerator.generate_java_code(prolog_code, template)
        
        self.java_code_view.setPlainText(java_code)
        self.console.append_success("✓ Java code generated successfully!")
        self.statusBar().showMessage("Java code generated")
    
    def build_prolog(self):
        """Build the Prolog interpreter"""
        self.console.append_info("\n=== Building Prolog Interpreter ===")
        
        try:
            # Run build script
            result = subprocess.run(
                ["bash", "build.sh"],
                cwd=self.prolog_path,
                capture_output=True,
                text=True,
                timeout=30
            )
            
            if result.returncode == 0:
                self.console.append_success("✓ Build successful!")
                self.console.append_output(result.stdout)
            else:
                self.console.append_error("✗ Build failed!")
                self.console.append_error(result.stderr)
                
            self.statusBar().showMessage("Build completed")
            
        except subprocess.TimeoutExpired:
            self.console.append_error("✗ Build timed out!")
        except Exception as e:
            self.console.append_error(f"✗ Build error: {str(e)}")
    
    def run_demo(self):
        """Run the demo program"""
        self.console.append_info("\n=== Running Demo ===")
        
        try:
            # Run demo script
            result = subprocess.run(
                ["bash", "demo.sh"],
                cwd=self.prolog_path,
                capture_output=True,
                text=True,
                timeout=30
            )
            
            self.console.append_output(result.stdout)
            if result.stderr:
                self.console.append_error(result.stderr)
            
            if result.returncode == 0:
                self.console.append_success("✓ Demo completed successfully!")
            else:
                self.console.append_error("✗ Demo failed!")
                
            self.statusBar().showMessage("Demo execution completed")
            
        except subprocess.TimeoutExpired:
            self.console.append_error("✗ Demo timed out!")
        except Exception as e:
            self.console.append_error(f"✗ Demo error: {str(e)}")
    

    def start_repl(self):
        """Start the Java REPL process"""
        if self.repl_process is not None and self.repl_process.state() != QProcess.ProcessState.NotRunning:
            self.console.append_info("REPL is already running.")
            return

        if not os.path.isdir(self.prolog_path):
            self.console.append_error("Cannot start REPL: prolog interpreter path not found.")
            return

        # Ensure build exists; if out/ missing, try to build.
        out_dir = os.path.join(self.prolog_path, "out")
        if not os.path.isdir(out_dir):
            self.console.append_info("out/ not found; building first...")
            self.build_prolog()

        self.console.append_info("\n=== Starting REPL ===")
        self.repl_process = QProcess(self)
        self.repl_process.setWorkingDirectory(self.prolog_path)
        self.repl_process.readyReadStandardOutput.connect(self._on_repl_stdout)
        self.repl_process.readyReadStandardError.connect(self._on_repl_stderr)
        self.repl_process.finished.connect(self._on_repl_finished)

        self.repl_process.start("java", ["-cp", "out", "com.mycompany.prolog.PrologReplMain"])
        if not self.repl_process.waitForStarted(3000):
            self.console.append_error("✗ Failed to start REPL (is Java available? did build succeed?)")
            self.repl_process = None
            return

        self.repl_start_btn.setEnabled(False)
        self.repl_stop_btn.setEnabled(True)
        self.repl_input.setFocus()

    def stop_repl(self):
        """Stop the Java REPL process"""
        if self.repl_process is None:
            return
        self.console.append_info("\n=== Stopping REPL ===")
        self.repl_process.terminate()
        if not self.repl_process.waitForFinished(2000):
            self.repl_process.kill()
            self.repl_process.waitForFinished(2000)

    def send_repl_input(self):
        """Send input line to the running REPL"""
        if self.repl_process is None or self.repl_process.state() == QProcess.ProcessState.NotRunning:
            self.console.append_error("REPL is not running. Click Start REPL (Ctrl+E).")
            return

        line = self.repl_input.text()
        if not line.strip():
            return
        self.repl_input.clear()

        # Echo user input for context
        self.console.append_output(f"> {line}")

        self.repl_process.write((line + "\n").encode("utf-8"))

    def _on_repl_stdout(self):
        if self.repl_process is None:
            return
        data = bytes(self.repl_process.readAllStandardOutput()).decode("utf-8", errors="replace")
        if data:
            self.console.append_raw(data)

    def _on_repl_stderr(self):
        if self.repl_process is None:
            return
        data = bytes(self.repl_process.readAllStandardError()).decode("utf-8", errors="replace")
        if data:
            self.console.append_raw(data, "#F48771")

    def _on_repl_finished(self):
        self.console.append_info("\n=== REPL exited ===")
        self.repl_start_btn.setEnabled(True)
        self.repl_stop_btn.setEnabled(False)
        self.repl_process = None

    def open_settings(self):
        """Open settings dialog to configure paths"""
        from PyQt6.QtWidgets import QDialog, QVBoxLayout, QHBoxLayout, QLineEdit, QPushButton, QLabel
        
        dialog = QDialog(self)
        dialog.setWindowTitle("Settings")
        dialog.setModal(True)
        
        layout = QVBoxLayout(dialog)
        
        # Prolog path setting
        path_layout = QHBoxLayout()
        path_layout.addWidget(QLabel("Prolog Interpreter Path:"))
        path_input = QLineEdit(self.prolog_path)
        path_layout.addWidget(path_input)
        
        browse_btn = QPushButton("Browse...")
        browse_btn.clicked.connect(lambda: self.browse_prolog_path(path_input))
        path_layout.addWidget(browse_btn)
        
        layout.addLayout(path_layout)
        
        # Buttons
        btn_layout = QHBoxLayout()
        save_btn = QPushButton("Save")
        cancel_btn = QPushButton("Cancel")
        
        def save_settings():
            new_path = path_input.text()
            if os.path.isdir(new_path):
                self.prolog_path = new_path
                self.console.append_success(f"✓ Prolog path updated: {new_path}")
                dialog.accept()
            else:
                QMessageBox.warning(dialog, "Invalid Path", 
                    f"Directory not found: {new_path}\n\nThe path has been saved anyway.")
                self.prolog_path = new_path
                dialog.accept()
        
        save_btn.clicked.connect(save_settings)
        cancel_btn.clicked.connect(dialog.reject)
        
        btn_layout.addWidget(save_btn)
        btn_layout.addWidget(cancel_btn)
        layout.addLayout(btn_layout)
        
        dialog.exec()
    
    def browse_prolog_path(self, line_edit):
        """Browse for prolog interpreter directory"""
        directory = QFileDialog.getExistingDirectory(
            self, "Select Prolog Interpreter Directory",
            self.prolog_path or os.path.expanduser("~")
        )
        if directory:
            line_edit.setText(directory)
    
    def load_example(self, example_code, title):
        """Load an example into the editor"""
        self.add_editor_tab(f"Example: {title}", example_code)
        self.console.append_info(f"Loaded example: {title}")
        self.statusBar().showMessage(f"Loaded example: {title}")


def main():
    """Main entry point"""
    app = QApplication(sys.argv)
    app.setStyle("Fusion")
    
    # Set dark theme
    app.setStyleSheet("""
        QMainWindow {
            background-color: #252526;
        }
        QToolBar {
            background-color: #333333;
            border: none;
            spacing: 5px;
            padding: 5px;
        }
        QToolBar QToolButton {
            background-color: #0E639C;
            color: white;
            border: none;
            padding: 8px 15px;
            margin: 2px;
            border-radius: 3px;
        }
        QToolBar QToolButton:hover {
            background-color: #1177BB;
        }
        QLabel {
            color: #CCCCCC;
        }
        QStatusBar {
            background-color: #007ACC;
            color: white;
        }
        QTabWidget::pane {
            border: 1px solid #3C3C3C;
            background-color: #1E1E1E;
        }
        QTabBar::tab {
            background-color: #2D2D30;
            color: #CCCCCC;
            padding: 8px 15px;
            border: 1px solid #3C3C3C;
        }
        QTabBar::tab:selected {
            background-color: #1E1E1E;
            color: #FFFFFF;
        }
        QTreeWidget {
            background-color: #252526;
            color: #CCCCCC;
            border: 1px solid #3C3C3C;
        }
        QTreeWidget::item:selected {
            background-color: #094771;
        }
        QComboBox {
            background-color: #3C3C3C;
            color: #CCCCCC;
            border: 1px solid #3C3C3C;
            padding: 5px;
        }
        QSplitter::handle {
            background-color: #3C3C3C;
        }
    """)
    
    ide = PrologIDE()
    ide.show()
    
    sys.exit(app.exec())


if __name__ == '__main__':
    main()
