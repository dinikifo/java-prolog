#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$ROOT"

rm -rf out
mkdir -p out

# UTF-8 is required (some environments default to ASCII).
javac -encoding UTF-8 -d out $(find src -name "*.java")

echo "Built to: $ROOT/out"
