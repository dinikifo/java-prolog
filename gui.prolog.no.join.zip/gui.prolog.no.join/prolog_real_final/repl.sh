#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$ROOT"

# Ensure built
if [ ! -d out ]; then
  echo "out/ not found; running build.sh"
  bash build.sh
fi

# Default: full stack. Use --sample for minimal.
java -cp out com.mycompany.prolog.PrologReplMain "$@"
