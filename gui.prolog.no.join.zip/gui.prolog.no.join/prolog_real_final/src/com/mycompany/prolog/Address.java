package com.mycompany.prolog;

public class Address {
  public String city;
  public String country;
}
