package com.mycompany.prolog;

import java.util.*;
import static com.mycompany.prolog.MiniPrologProto.*;

public final class QuickDefmethodTest {
  static void dumpMethodClauses(Obj prog){
    Obj pred = prog.get(K_PREDICATES).get("method/4");
    if(pred==null){
      System.out.println("method/4 pred missing");
      return;
    }
    List<Obj> cs = pred.get(K_CLAUSES);
    System.out.println("method/4 clauses="+cs.size());
    for(int i=0;i<cs.size();i++){
      Obj c = cs.get(i);
      Obj h = c.get(K_HEAD);
      System.out.println("  #"+i+" head="+pp(h)+" bodylen="+c.get(K_BODY).size());
      if(h.get(K_TAG)==Tag.COMP && h.get(K_ARITY)>=4){
        Obj msg = h.get(K_ARGS).get(1);
        System.out.println("     raw msg tag="+msg.get(K_TAG)+" bind="+(msg.get(K_BIND)==null?"null":pp(msg.get(K_BIND))));
        Obj body = h.get(K_ARGS).get(3);
        System.out.println("     raw body tag="+body.get(K_TAG)+" bind="+(body.get(K_BIND)==null?"null":pp(body.get(K_BIND))));
      }
    }
  }

  public static void main(String[] args){
    Obj prog = MiniPrologProto.buildProgramWithSample();
    OopPrologLib.load(prog);
    System.out.println("oop_init="+query(prog, Comp("oop_init")).size());

    Obj X = Var();
    Obj Self = Var();
    Obj g1 = Comp("defmethod", Atom("testProto"), Comp("foo", X), Self, Atom("true"));
    System.out.println("def foo="+query(prog, g1).size());
    dumpMethodClauses(prog);

    Obj Y = Var();
    Obj g2 = Comp("defmethod", Atom("testProto"), Comp("bar", Y), Self, Atom("true"));
    System.out.println("def bar="+query(prog, g2).size());
    dumpMethodClauses(prog);

    Obj M = Var();
    Obj S = Var();
    Obj B = Var();
    List<Map<Integer,Obj>> ms = query(prog, Comp("method", Atom("testProto"), M, S, B));
    System.out.println("methods(query)="+ms.size());
    if(!ms.isEmpty()){
      Map<Integer,Obj> sol = ms.get(0);
      System.out.println("  M vid="+M.get(K_VID)+" S vid="+S.get(K_VID)+" B vid="+B.get(K_VID));
      for(Map.Entry<Integer,Obj> e: sol.entrySet()){
        System.out.println("  sol["+e.getKey()+"]="+pp(e.getValue()));
      }
    }
  }
}
