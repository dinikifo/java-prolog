package com.mycompany.prolog;

import static com.mycompany.prolog.MiniPrologProto.*;

/**
 * Parametric HTN planner + common strategies (query designer/runner/search).
 *
 * The planner reads the DB via OO messages; it does not mutate the DB during search.
 */
public final class PlannerStrategiesLib {
  private PlannerStrategiesLib(){}

  static Obj conj(Obj... gs){
    if(gs==null || gs.length==0) return Comp("true");
    Obj out = gs[gs.length-1];
    for(int i=gs.length-2;i>=0;i--) out = Comp(",", gs[i], out);
    return out;
  }

  private static void ensurePred(Obj prog, String name, int arity){
    if(getPred(prog.get(K_PREDICATES), name, arity)==null){
      definePred(prog, name, arity, Predicate());
    }
  }

  public static void load(Obj prog){
    // helper preds used here
    ensurePred(prog, "run_query", 3);
    ensurePred(prog, "filter_hash_cols", 2);
    ensurePred(prog, "ensure_hash_indexes", 3);
    ensurePred(prog, "ensure_hash_each", 2);
    ensurePred(prog, "htn_dfs_plan", 3);
    ensurePred(prog, "htn_dfs_", 4);
    ensurePred(prog, "htn_bdfs_plan", 4);
    ensurePred(prog, "htn_bdfs_", 6);
    ensurePred(prog, "need_rows", 3);
    ensurePred(prog, "new_ctx", 3);
    installPlannerCore(prog);
    installStrategiesInit(prog);
  }

  private static void installPlannerCore(Obj prog){
    // run_query(DB, q(Table,Proj,Filter,Opts), Rows)
    {
      Obj DB=Var(), Table=Var(), Proj=Var(), Filter=Var(), Opts=Var(), Rows=Var(), T=Var();
      definePred(prog, "run_query", 3, Predicate(
          Clause(Comp("run_query", DB, Comp("q", Table, Proj, Filter, Opts), Rows),
              Comp("send", DB, Comp("table", Table, T)),
              Comp("send", T, Comp("select", Proj, Filter, Opts, Rows)))
      ));
    }

    // filter_hash_cols/2 extracts eq and in columns (for auto-index)
    {
      Obj C=Var(), Lit=Var(), Lst=Var();
      Obj F1=Var(), F2=Var(), A=Var(), B=Var(), U=Var();
      Obj F=Var(), Cols=Var();
      definePred(prog, "filter_hash_cols", 2, Predicate(
          Clause(Comp("filter_hash_cols", Atom("all"), listNil())),
          Clause(Comp("filter_hash_cols", Comp("where", C, Atom("eq"), Lit), list(C))),
          Clause(Comp("filter_hash_cols", Comp("in", C, Lst), list(C))),
          Clause(Comp("filter_hash_cols", Comp("and", F1, F2), U),
              Comp("filter_hash_cols", F1, A),
              Comp("filter_hash_cols", F2, B),
              Comp("list_union", A, B, U)),
          Clause(Comp("filter_hash_cols", Comp("or", F1, F2), U),
              Comp("filter_hash_cols", F1, A),
              Comp("filter_hash_cols", F2, B),
              Comp("list_union", A, B, U)),
          Clause(Comp("filter_hash_cols", Comp("not", F), Cols),
              Comp("filter_hash_cols", F, Cols)),
          // ignore other where ops
          Clause(Comp("filter_hash_cols", Comp("where", Var(), Var(), Var()), listNil()))
      ));
    }

    // ensure_hash_indexes(DB,Table,Filter)
    {
      Obj DB=Var(), Table=Var(), Filter=Var(), Cols=Var(), T=Var();
      definePred(prog, "ensure_hash_indexes", 3, Predicate(
          Clause(Comp("ensure_hash_indexes", DB, Table, Filter),
              Comp("filter_hash_cols", Filter, Cols),
              Comp("send", DB, Comp("table", Table, T)),
              Comp("ensure_hash_each", T, Cols))
      ));
    }

    // ensure_hash_each(Table,[Col|Cols])
    {
      Obj T=Var();
      Obj C=Var(), Cs=Var(), CObj=Var(), Kind=Var();
      definePred(prog, "ensure_hash_each", 2, Predicate(
          Clause(Comp("ensure_hash_each", T, listNil())),
          Clause(Comp("ensure_hash_each", T, listCons(C, Cs)),
              Comp("table_col", T, C, CObj),
              Comp("get", CObj, Atom("index_kind"), Kind),
              Comp(";",
                  Comp("->", Comp("\\+", Comp("=", Kind, Atom("none"))), Comp("true")),
                  Comp("send", T, Comp("create_index", C, Atom("hash")))
              ),
              Comp("ensure_hash_each", T, Cs))
      ));
    }

    // HTN DFS
    {
      Obj Ctx=Var(), Tasks=Var(), Plan=Var(), Rev=Var();
      definePred(prog, "htn_dfs_plan", 3, Predicate(
          Clause(Comp("htn_dfs_plan", Ctx, Tasks, Plan),
              Comp("htn_dfs_", Ctx, Tasks, listNil(), Rev),
              Comp("rev", Rev, Plan))
      ));

      Obj Acc=Var();
      Obj base = Clause(Comp("htn_dfs_", Var(), listNil(), Acc, Acc), Comp("true"));

      Obj T=Var(), Rest=Var(), Out=Var();
      Obj prim = Clause(Comp("htn_dfs_", Ctx, listCons(T, Rest), Acc, Out),
          Comp("primitive", T),
          Comp("op", Ctx, T),
          Comp("htn_dfs_", Ctx, Rest, listCons(T, Acc), Out));

      Obj Sub=Var(), New=Var();
      Obj comp = Clause(Comp("htn_dfs_", Ctx, listCons(T, Rest), Acc, Out),
          Comp("\\+", Comp("primitive", T)),
          Comp("method", Ctx, T, Sub),
          Comp("append", Sub, Rest, New),
          Comp("htn_dfs_", Ctx, New, Acc, Out));

      definePred(prog, "htn_dfs_", 4, Predicate(base, prim, comp));
    }

    // bounded DFS
    {
      Obj Ctx=Var(), Tasks=Var(), Max=Var(), Plan=Var(), Rev=Var(), Left=Var();
      definePred(prog, "htn_bdfs_plan", 4, Predicate(
          Clause(Comp("htn_bdfs_plan", Ctx, Tasks, Max, Plan),
              Comp("htn_bdfs_", Ctx, Tasks, listNil(), Rev, Max, Left),
              Comp("rev", Rev, Plan))
      ));

      Obj Acc=Var(), Steps=Var();
      Obj base = Clause(Comp("htn_bdfs_", Var(), listNil(), Acc, Acc, Steps, Steps), Comp("true"));

      Obj T=Var(), Rest=Var(), Acc2=Var(), Out=Var(), S0=Var(), S=Var(), S1=Var();
      Obj prim = Clause(Comp("htn_bdfs_", Ctx, listCons(T, Rest), Acc2, Out, S0, S),
          Comp(">", S0, Num(0)),
          Comp("primitive", T),
          Comp("op", Ctx, T),
          Comp("is", S1, Comp("-", S0, Num(1))),
          Comp("htn_bdfs_", Ctx, Rest, listCons(T, Acc2), Out, S1, S));

      Obj Sub=Var(), New=Var();
      Obj comp = Clause(Comp("htn_bdfs_", Ctx, listCons(T, Rest), Acc2, Out, S0, S),
          Comp(">", S0, Num(0)),
          Comp("\\+", Comp("primitive", T)),
          Comp("method", Ctx, T, Sub),
          Comp("append", Sub, Rest, New),
          Comp("is", S1, Comp("-", S0, Num(1))),
          Comp("htn_bdfs_", Ctx, New, Acc2, Out, S1, S));

      definePred(prog, "htn_bdfs_", 6, Predicate(base, prim, comp));
    }

    // need_rows/3
    {
      Obj Ctx=Var(), Need=Var(), Rows=Var(), Q=Var();
      definePred(prog, "need_rows", 3, Predicate(
          Clause(Comp("need_rows", Ctx, Need, Rows),
              Comp("send", Ctx, Comp("design", Need, Q)),
              Comp("send", Ctx, Comp("run", Q, Rows)))
      ));
    }
  }

  private static void installStrategiesInit(Obj prog){
    // planner_param_init/0 installs strategy prototypes and methods
    Obj Self=Var();
    Obj DB=Var(), QD=Var(), Runner=Var(), Search=Var();
    Obj Need=Var(), Q=Var(), QDObj=Var();
    Obj Rows=Var(), RObj=Var();
    Obj Tasks=Var(), Plan=Var(), SObj=Var();

    Obj initBody = conj(
        Comp("oop_ready"),

        // prototypes
        Comp("retract_all", Comp("proto", Atom("ctxProto"), Var())),
        Comp("retract_all", Comp("proto", Atom("qdDomainProto"), Var())),
        Comp("retract_all", Comp("proto", Atom("qdPassthroughProto"), Var())),
        Comp("retract_all", Comp("proto", Atom("runnerPlainProto"), Var())),
        Comp("retract_all", Comp("proto", Atom("runnerCachedProto"), Var())),
        Comp("retract_all", Comp("proto", Atom("runnerAutoIndexEqProto"), Var())),
        Comp("retract_all", Comp("proto", Atom("searchDfsProto"), Var())),
        Comp("retract_all", Comp("proto", Atom("searchBoundedDfsProto"), Var())),

        Comp("assertz", Comp("proto", Atom("ctxProto"), Atom("objectProto"))),
        Comp("assertz", Comp("proto", Atom("qdDomainProto"), Atom("objectProto"))),
        Comp("assertz", Comp("proto", Atom("qdPassthroughProto"), Atom("objectProto"))),
        Comp("assertz", Comp("proto", Atom("runnerPlainProto"), Atom("objectProto"))),
        Comp("assertz", Comp("proto", Atom("runnerCachedProto"), Atom("objectProto"))),
        Comp("assertz", Comp("proto", Atom("runnerAutoIndexEqProto"), Atom("objectProto"))),
        Comp("assertz", Comp("proto", Atom("searchDfsProto"), Atom("objectProto"))),
        Comp("assertz", Comp("proto", Atom("searchBoundedDfsProto"), Atom("objectProto"))),

        // defaults
        Comp("put", Atom("runnerCachedProto"), Atom("cache"), listNil()),
        Comp("put", Atom("searchBoundedDfsProto"), Atom("max_steps"), Num(5000)),

        // ctxProto methods
        Comp("defmethod", Atom("ctxProto"), Comp("init", DB, QD, Runner, Search), Self,
            conj(
                Comp("put", Self, Atom("db"), DB),
                Comp("put", Self, Atom("qd"), QD),
                Comp("put", Self, Atom("runner"), Runner),
                Comp("put", Self, Atom("search"), Search)
            )
        ),

        Comp("defmethod", Atom("ctxProto"), Comp("design", Need, Q), Self,
            conj(
                Comp("get", Self, Atom("qd"), QDObj),
                Comp("send", QDObj, Comp("design", Self, Need, Q))
            )
        ),

        Comp("defmethod", Atom("ctxProto"), Comp("run", Q, Rows), Self,
            conj(
                Comp("get", Self, Atom("runner"), RObj),
                Comp("send", RObj, Comp("run", Self, Q, Rows))
            )
        ),

        Comp("defmethod", Atom("ctxProto"), Comp("plan", Tasks, Plan), Self,
            conj(
                Comp("get", Self, Atom("search"), SObj),
                Comp("send", SObj, Comp("plan", Self, Tasks, Plan))
            )
        ),

        // Query designers
        Comp("defmethod", Atom("qdDomainProto"), Comp("design", Var(), Need, Q), Var(),
            Comp("design_query", Need, Q)
        ),

        Comp("defmethod", Atom("qdPassthroughProto"), Comp("design", Var(), Need, Q), Var(),
            Comp("=", Need, Q)
        )
    );

    // Define runner/search methods with explicit variables.
    Obj ctxV = Var();
    Obj qV = Var();
    Obj rowsV = Var();
    Obj dbV = Var();

    Obj runnerPlainMethod = Comp("defmethod", Atom("runnerPlainProto"), Comp("run", ctxV, qV, rowsV), Var(),
        conj(
            Comp("get", ctxV, Atom("db"), dbV),
            Comp("run_query", dbV, qV, rowsV)
        )
    );

    Obj cacheSelf = Var();
    Obj cache0 = Var();
    Obj cache1 = Var();
    Obj ctxC = Var();
    Obj qC = Var();
    Obj rowsC = Var();
    Obj dbC = Var();

    Obj runnerCachedMethod = Comp("defmethod", Atom("runnerCachedProto"), Comp("run", ctxC, qC, rowsC), cacheSelf,
        conj(
            Comp("get", cacheSelf, Atom("cache"), cache0),
            Comp(";",
                Comp("->", Comp("kv_get", cache0, qC, rowsC), Comp("true")),
                conj(
                    Comp("get", ctxC, Atom("db"), dbC),
                    Comp("run_query", dbC, qC, rowsC),
                    Comp("kv_put", cache0, qC, rowsC, cache1),
                    Comp("put", cacheSelf, Atom("cache"), cache1)
                )
            )
        )
    );

    Obj ctxI = Var();
    Obj qI = Var();
    Obj rowsI = Var();
    Obj dbI = Var();
    Obj tbl = Var(), proj = Var(), flt = Var(), opts = Var();
    Obj runnerAutoMethod = Comp("defmethod", Atom("runnerAutoIndexEqProto"), Comp("run", ctxI, qI, rowsI), Var(),
        conj(
            Comp("=", qI, Comp("q", tbl, proj, flt, opts)),
            Comp("get", ctxI, Atom("db"), dbI),
            Comp("ensure_hash_indexes", dbI, tbl, flt),
            Comp("run_query", dbI, qI, rowsI)
        )
    );

    Obj ctxS = Var(), tasksS = Var(), planS = Var();
    Obj searchDfsMethod = Comp("defmethod", Atom("searchDfsProto"), Comp("plan", ctxS, tasksS, planS), Var(),
        Comp("htn_dfs_plan", ctxS, tasksS, planS)
    );

    Obj selfB = Var(), ctxB = Var(), tasksB = Var(), planB = Var(), max = Var();
    Obj searchBoundedMethod = Comp("defmethod", Atom("searchBoundedDfsProto"), Comp("plan", ctxB, tasksB, planB), selfB,
        conj(
            Comp("get", selfB, Atom("max_steps"), max),
            Comp("htn_bdfs_plan", ctxB, tasksB, max, planB)
        )
    );

    // new_ctx/3 profiles
    Obj CtxOut=Var();
    Obj qd=Var(), runner=Var(), search=Var();
    Obj newSmall = Clause(Comp("new_ctx", DB, Atom("small"), CtxOut),
        Comp("clone", Atom("ctxProto"), CtxOut),
        Comp("clone", Atom("qdDomainProto"), qd),
        Comp("clone", Atom("runnerPlainProto"), runner),
        Comp("clone", Atom("searchDfsProto"), search),
        Comp("send", CtxOut, Comp("init", DB, qd, runner, search))
    );
    Obj newCached = Clause(Comp("new_ctx", DB, Atom("cached"), CtxOut),
        Comp("clone", Atom("ctxProto"), CtxOut),
        Comp("clone", Atom("qdDomainProto"), qd),
        Comp("clone", Atom("runnerCachedProto"), runner),
        Comp("clone", Atom("searchBoundedDfsProto"), search),
        Comp("send", CtxOut, Comp("init", DB, qd, runner, search))
    );
    Obj newIndexed = Clause(Comp("new_ctx", DB, Atom("indexed"), CtxOut),
        Comp("clone", Atom("ctxProto"), CtxOut),
        Comp("clone", Atom("qdDomainProto"), qd),
        Comp("clone", Atom("runnerAutoIndexEqProto"), runner),
        Comp("clone", Atom("searchBoundedDfsProto"), search),
        Comp("send", CtxOut, Comp("init", DB, qd, runner, search))
    );
    definePred(prog, "new_ctx", 3, Predicate(newSmall, newCached, newIndexed));

    // planner_param_init/0
    definePred(prog, "planner_param_init", 0, Predicate(
        Clause(Comp("planner_param_init"), conj(initBody, runnerPlainMethod, runnerCachedMethod, runnerAutoMethod, searchDfsMethod, searchBoundedMethod))
    ));
  }
}
