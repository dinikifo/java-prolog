package com.mycompany.prolog;

import static com.mycompany.prolog.MiniPrologProto.*;

/**
 * Small demo domain for the parametric HTN planner.
 *
 * Domain: fulfill(OrderId) -> pick(OrderId), ship(OrderId)
 *  - pick decomposes into reserve tasks for each line item
 *  - ship decomposes into book/label using the cheapest carrier
 */
public final class HtnDemoLib {
  private HtnDemoLib(){}

  public static void load(Obj prog){
    installDomain(prog);
    installSeeding(prog);
    installDriver(prog);
  }

  private static void installDomain(Obj prog){
    // design_query/2: Need -> q(Table,Proj,Filter,Opts)
    {
      Obj O=Var(), Q=Var();
      Obj Sku=Var(), Min=Var();
      definePred(prog, "design_query", 2, Predicate(
          Clause(Comp("design_query", Comp("order", O),
              Comp("q", Atom("orders"), Atom("all"), Comp("where", Atom("id"), Atom("eq"), O), Comp("opts", Comp("limit", Num(1)))))),
          Clause(Comp("design_query", Comp("order_lines", O),
              Comp("q", Atom("order_lines"), Atom("all"), Comp("where", Atom("order_id"), Atom("eq"), O), Comp("opts", Comp("limit", Atom("all")))))),
          Clause(Comp("design_query", Comp("inventory", Sku, Min),
              Comp("q", Atom("inventory"), Atom("all"),
                  Comp("and",
                      Comp("where", Atom("sku"), Atom("eq"), Sku),
                      Comp("where", Atom("qty"), Atom("ge"), Min)
                  ),
                  Comp("opts", Comp("limit", Atom("all")))
              ))),
          Clause(Comp("design_query", Atom("carriers"),
              Comp("q", Atom("carriers"), Atom("all"), Atom("all"), Comp("opts", Comp("limit", Atom("all"))))))
      ));
    }

    // primitive/1
    {
      Obj O=Var(), S=Var(), Q=Var(), C=Var();
      definePred(prog, "primitive", 1, Predicate(
          Clause(Comp("primitive", Comp("reserve", O, S, Q))),
          Clause(Comp("primitive", Comp("book", O, C))),
          Clause(Comp("primitive", Comp("label", O, C)))
      ));
    }

    // method/3
    {
      Obj Ctx=Var(), O=Var();
      Obj Rows=Var(), Tasks=Var();
      Obj Carrier=Var();
      definePred(prog, "method", 3, Predicate(
          // fulfill
          Clause(Comp("method", Ctx, Comp("fulfill", O),
              list(Comp("pick", O), Comp("ship", O)))),

          // pick: query order lines -> reserve tasks
          Clause(Comp("method", Ctx, Comp("pick", O), Tasks),
              Comp("need_rows", Ctx, Comp("order_lines", O), Rows),
              Comp("lines_to_reserves", O, Rows, Tasks)),

          // ship: choose cheapest carrier
          Clause(Comp("method", Ctx, Comp("ship", O),
              list(Comp("book", O, Carrier), Comp("label", O, Carrier))),
              Comp("need_rows", Ctx, Atom("carriers"), Rows),
              Comp("choose_cheapest_carrier", Rows, Carrier))
      ));
    }

    // lines_to_reserves/3
    {
      Obj O=Var();
      Obj Row=Var(), Rows=Var();
      Obj Tasks=Var(), Rest=Var();
      Obj Sku=Var(), Qty=Var();
      definePred(prog, "lines_to_reserves", 3, Predicate(
          Clause(Comp("lines_to_reserves", O, listNil(), listNil())),
          Clause(Comp("lines_to_reserves", O, listCons(Row, Rows), listCons(Comp("reserve", O, Sku, Qty), Rest)),
              Comp("row_get", Row, Atom("sku"), Sku),
              Comp("row_get", Row, Atom("qty"), Qty),
              Comp("lines_to_reserves", O, Rows, Rest))
      ));
    }

    // choose_cheapest_carrier/2
    {
      Obj Row=Var(), Rows=Var();
      Obj Name=Var(), Cost=Var();
      Obj BestName=Var();
      definePred(prog, "choose_cheapest_carrier", 2, Predicate(
          Clause(Comp("choose_cheapest_carrier", listCons(Row, Rows), BestName),
              Comp("row_get", Row, Atom("name"), Name),
              Comp("row_get", Row, Atom("cost"), Cost),
              Comp("choose_cheapest_loop", Rows, Name, Cost, BestName))
      ));

      Obj R=Var(), Rs=Var(), CurName=Var(), CurCost=Var(), Out=Var();
      Obj N=Var(), C=Var();
      definePred(prog, "choose_cheapest_loop", 4, Predicate(
          Clause(Comp("choose_cheapest_loop", listNil(), CurName, CurCost, CurName)),
          Clause(Comp("choose_cheapest_loop", listCons(R, Rs), CurName, CurCost, Out),
              Comp("row_get", R, Atom("name"), N),
              Comp("row_get", R, Atom("cost"), C),
              Comp("<", C, CurCost),
              Comp("!"),
              Comp("choose_cheapest_loop", Rs, N, C, Out)),
          Clause(Comp("choose_cheapest_loop", listCons(R, Rs), CurName, CurCost, Out),
              Comp("choose_cheapest_loop", Rs, CurName, CurCost, Out))
      ));
    }

    // op/2 : primitive task interpreter (preconditions)
    {
      Obj Ctx=Var(), O=Var(), S=Var(), Q=Var();
      Obj Rows=Var();
      Obj Carrier=Var();
      definePred(prog, "op", 2, Predicate(
          // reserve requires inventory
          Clause(Comp("op", Ctx, Comp("reserve", O, S, Q)),
              Comp("need_rows", Ctx, Comp("inventory", S, Q), Rows),
              Comp("\\+", Comp("=", Rows, listNil()))
          ),
          // book/label are always OK (demo)
          Clause(Comp("op", Ctx, Comp("book", O, Carrier)), Comp("true")),
          Clause(Comp("op", Ctx, Comp("label", O, Carrier)), Comp("true"))
      ));
    }
  }

  private static void installSeeding(Obj prog){
    // demo_seed(DB)
    {
      Obj DB=Var();
      // IMPORTANT: each table variable must be distinct. Reusing a single variable
      // across multiple create_table/table calls would unify different table objects
      // and make seeding fail.
      Obj TOrders=Var();
      Obj TLines=Var();
      Obj TInv=Var();
      Obj TCars=Var();
      Obj SchemaOrders = list(
          Comp("col", Atom("id"), Atom("num"), Atom("opts")),
          Comp("col", Atom("customer"), Atom("atom"), Atom("opts"))
      );
      Obj SchemaLines = list(
          Comp("col", Atom("order_id"), Atom("num"), Atom("opts")),
          Comp("col", Atom("sku"), Atom("atom"), Atom("opts")),
          Comp("col", Atom("qty"), Atom("num"), Atom("opts"))
      );
      Obj SchemaInv = list(
          Comp("col", Atom("sku"), Atom("atom"), Atom("opts")),
          Comp("col", Atom("qty"), Atom("num"), Atom("opts")),
          Comp("col", Atom("loc"), Atom("atom"), Atom("opts"))
      );
      Obj SchemaCar = list(
          Comp("col", Atom("name"), Atom("atom"), Atom("opts")),
          Comp("col", Atom("cost"), Atom("num"), Atom("opts")),
          Comp("col", Atom("mode"), Atom("atom"), Atom("opts"))
      );

      // rows
      Obj Orders = list(
          Comp("row", list(Comp("=", Atom("id"), Num(1)), Comp("=", Atom("customer"), Atom("ada"))))
      );
      Obj Lines = list(
          Comp("row", list(Comp("=", Atom("order_id"), Num(1)), Comp("=", Atom("sku"), Atom("sku1")), Comp("=", Atom("qty"), Num(2)))),
          Comp("row", list(Comp("=", Atom("order_id"), Num(1)), Comp("=", Atom("sku"), Atom("sku2")), Comp("=", Atom("qty"), Num(1))))
      );
      Obj Inv = list(
          Comp("row", list(Comp("=", Atom("sku"), Atom("sku1")), Comp("=", Atom("qty"), Num(10)), Comp("=", Atom("loc"), Atom("a1")))),
          Comp("row", list(Comp("=", Atom("sku"), Atom("sku2")), Comp("=", Atom("qty"), Num(1)), Comp("=", Atom("loc"), Atom("c3"))))
      );
      Obj Cars = list(
          Comp("row", list(Comp("=", Atom("name"), Atom("fastship")), Comp("=", Atom("cost"), Num(15)), Comp("=", Atom("mode"), Atom("air")))),
          Comp("row", list(Comp("=", Atom("name"), Atom("cheapship")), Comp("=", Atom("cost"), Num(7)), Comp("=", Atom("mode"), Atom("ground"))))
      );

      // define demo_seed/1 as a single clause
      definePred(prog, "demo_seed", 1, Predicate(
          Clause(Comp("demo_seed", DB),
              // tables
              Comp("send", DB, Comp("create_table", Atom("orders"), SchemaOrders, TOrders)),
              Comp("send", DB, Comp("create_table", Atom("order_lines"), SchemaLines, TLines)),
              Comp("send", DB, Comp("create_table", Atom("inventory"), SchemaInv, TInv)),
              Comp("send", DB, Comp("create_table", Atom("carriers"), SchemaCar, TCars)),
              // inserts
              Comp("send", TOrders, Comp("insert_many", Orders)),
              Comp("send", TLines,  Comp("insert_many", Lines)),
              Comp("send", TInv,    Comp("insert_many", Inv)),
              Comp("send", TCars,   Comp("insert_many", Cars))
          )
      ));
    }
  }

  private static void installDriver(Obj prog){
    // demo_plan(Profile, Plan)
    {
      Obj Profile=Var(), Plan=Var();
      Obj DB=Var(), Ctx=Var();
      definePred(prog, "demo_plan", 2, Predicate(
          Clause(Comp("demo_plan", Profile, Plan),
              Comp("oop_init"),
              Comp("columndb_init"),
              Comp("planner_param_init"),
              Comp("clone", Atom("dbProto"), DB),
              Comp("demo_seed", DB),
              Comp("new_ctx", DB, Profile, Ctx),
              Comp("send", Ctx, Comp("plan", list(Comp("fulfill", Num(1))), Plan))
          )
      ));
    }
  }
}
