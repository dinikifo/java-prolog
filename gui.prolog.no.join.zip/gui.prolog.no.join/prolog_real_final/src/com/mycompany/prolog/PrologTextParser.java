package com.mycompany.prolog;

import java.util.*;

import static com.mycompany.prolog.MiniPrologProto.*;

/**
 * A small Prolog-ish text parser for MiniPrologProto.
 *
 * Goals vs Terms:
 * - In goal context, "," means conjunction and ";" means disjunction.
 * - In term context (arguments, list elements, clause heads), "," is a separator.
 *
 * Supported (pragmatic) syntax:
 * - Queries:      ?- Goal.
 * - Directives:   :- Goal.
 * - Facts:        Head.
 * - Rules:        Head :- Goal.
 *
 * Goal operators: , ; -> \+  !  and the binary builtins (=, is, =:=, =\=, <, =<, >, >=, ==, \=).
 * Term operators (arithmetic): + - * / // mod, including unary -.
 *
 * Strings:
 * - "..." and '...' are both read as atom payloads (Atom("...")).
 *   (This matches the engine built-ins which generally accept Atom for stringy values.)
 *
 * Notes:
 * - This is not a complete ISO Prolog parser; it's a deliberately small subset,
 *   designed to get a practical REPL over your Java engine.
 */
public final class PrologTextParser {

  public sealed interface Statement permits QueryStmt, ClauseStmt, DirectiveStmt {}

  public static final class QueryStmt implements Statement {
    public final Obj goal;
    public final LinkedHashMap<String, Obj> vars; // insertion-order
    QueryStmt(Obj goal, LinkedHashMap<String, Obj> vars){ this.goal=goal; this.vars=vars; }
  }

  public static final class DirectiveStmt implements Statement {
    public final Obj goal;
    public final LinkedHashMap<String, Obj> vars;
    DirectiveStmt(Obj goal, LinkedHashMap<String, Obj> vars){ this.goal=goal; this.vars=vars; }
  }

  public static final class ClauseStmt implements Statement {
    /** Either Head or ':-'(Head,Body) */
    public final Obj clauseTerm;
    ClauseStmt(Obj clauseTerm){ this.clauseTerm=clauseTerm; }
  }

  /** Thrown when the input looks syntactically incomplete (e.g. missing trailing "."). */
  public static final class IncompleteInput extends RuntimeException {
    public IncompleteInput(String msg){ super(msg); }
  }

  /** Parse a single statement that MUST end with '.' (dot). */
  public static Statement parseStatement(String src){
    Parser p = new Parser(src);
    Statement st = p.parseStatement();
    p.expect(TokenType.DOT, "'.'");
    p.expect(TokenType.EOF, "end of input");
    return st;
  }

  /* =========================
   * Lexer
   * ========================= */

  enum TokenType {
    ATOM, VAR, NUM, DOT,
    LPAREN, RPAREN, LBRACK, RBRACK, BAR,
    COMMA, SEMI,
    OP, // multi/single operators: ?- :- -> \+ etc
    EOF
  }

  static final class Token {
    final TokenType type;
    final String text;
    final int pos;
    Token(TokenType type, String text, int pos){
      this.type=type; this.text=text; this.pos=pos;
    }
    @Override public String toString(){ return type+"("+text+")@"+pos; }
  }

  static final class Lexer {
    final String s;
    int i=0;
    Lexer(String s){ this.s=s; }

    boolean eof(){ return i>=s.length(); }
    char ch(){ return s.charAt(i); }

    void wsAndComments(){
      while(!eof()){
        char c = ch();
        // whitespace
        if(c==' '||c=='\t'||c=='\r'||c=='\n'){ i++; continue; }
        // % comment
        if(c=='%'){
          while(!eof() && ch()!='\n') i++;
          continue;
        }
        // // comment
        if(c=='/' && i+1<s.length() && s.charAt(i+1)=='/'){
          i+=2;
          while(!eof() && ch()!='\n') i++;
          continue;
        }
        break;
      }
    }

    static boolean isIdStart(char c){
      return Character.isLetter(c) || c=='_';
    }
    static boolean isIdPart(char c){
      return Character.isLetterOrDigit(c) || c=='_';
    }

    Token next(){
      wsAndComments();
      if(eof()) return new Token(TokenType.EOF, "", i);
      int pos=i;
      char c=ch();

      // multi-char operators (longest first)
      String[] ops = new String[]{
          ":-", "?-", "->",
          "=:=", "=\\=", "=<", ">=",
          "\\+", "==", "\\=",
          "//"
      };
      for(String op: ops){
        if(i+op.length()<=s.length() && s.startsWith(op, i)){
          i+=op.length();
          return new Token(TokenType.OP, op, pos);
        }
      }

      // single-char punctuation / operators
      switch(c){
        case '.': i++; return new Token(TokenType.DOT, ".", pos);
        case '(': i++; return new Token(TokenType.LPAREN, "(", pos);
        case ')': i++; return new Token(TokenType.RPAREN, ")", pos);
        case '[': i++; return new Token(TokenType.LBRACK, "[", pos);
        case ']': i++; return new Token(TokenType.RBRACK, "]", pos);
        case '|': i++; return new Token(TokenType.BAR, "|", pos);
        case ',': i++; return new Token(TokenType.COMMA, ",", pos);
        case ';': i++; return new Token(TokenType.SEMI, ";", pos);
        case '!': i++; return new Token(TokenType.OP, "!", pos);
        case '+': i++; return new Token(TokenType.OP, "+", pos);
        case '-': i++; return new Token(TokenType.OP, "-", pos);
        case '*': i++; return new Token(TokenType.OP, "*", pos);
        case '/': i++; return new Token(TokenType.OP, "/", pos);
        case '=': i++; return new Token(TokenType.OP, "=", pos);
        case '<': i++; return new Token(TokenType.OP, "<", pos);
        case '>': i++; return new Token(TokenType.OP, ">", pos);
        case '\\': {
          // bare "\" is not valid here; but allow "\+" as op handled above.
          i++;
          return new Token(TokenType.OP, "\\", pos);
        }
        default: break;
      }

      // quoted atom/string with escapes
      if(c=='\'' || c=='"'){
        char quote=c;
        i++;
        StringBuilder sb=new StringBuilder();
        boolean closed=false;
        while(!eof()){
          char d = ch(); i++;
          if(d==quote){ closed=true; break; }
          if(d=='\\'){
            if(eof()) throw new RuntimeException("unterminated escape at "+i);
            char e = ch(); i++;
            switch(e){
              case 'n': sb.append('\n'); break;
              case 'r': sb.append('\r'); break;
              case 't': sb.append('\t'); break;
              case '\\': sb.append('\\'); break;
              case '"': sb.append('"'); break;
              case '\'': sb.append('\''); break;
              default: sb.append(e); break;
            }
          } else sb.append(d);
        }
        if(!closed) throw new IncompleteInput("unterminated string/atom literal");
        return new Token(TokenType.ATOM, sb.toString(), pos);
      }

      // number (int or float)
      if(Character.isDigit(c)){
        int start=i;
        while(!eof() && Character.isDigit(ch())) i++;
        boolean isFloat=false;
        if(!eof() && ch()=='.'){
          // lookahead to decide float: '.' followed by digit => float literal
          if(i+1<s.length() && Character.isDigit(s.charAt(i+1))){
            isFloat=true;
            i++; // consume dot
            while(!eof() && Character.isDigit(ch())) i++;
          }
        }
        // exponent part
        if(!eof()){
          char e = ch();
          if(e=='e' || e=='E'){
            int save=i;
            int j=i+1;
            if(j<s.length() && (s.charAt(j)=='+'||s.charAt(j)=='-')) j++;
            if(j<s.length() && Character.isDigit(s.charAt(j))){
              isFloat=true;
              i=j+1;
              while(!eof() && Character.isDigit(ch())) i++;
            } else {
              // not a real exponent, rollback
              i=save;
            }
          }
        }
        String num = s.substring(start, i);
        return new Token(TokenType.NUM, num + (isFloat? "f": ""), pos);
      }

      // identifier
      if(isIdStart(c)){
        int start=i;
        i++;
        while(!eof() && isIdPart(ch())) i++;
        String id = s.substring(start, i);

        // 'mod' is an atom token, but term parser treats it as an arithmetic operator in infix position.
        if(Character.isUpperCase(id.charAt(0)) || id.charAt(0)=='_'){
          return new Token(TokenType.VAR, id, pos);
        }
        return new Token(TokenType.ATOM, id, pos);
      }

      // fallback: treat as atom-ish single char
      i++;
      return new Token(TokenType.ATOM, Character.toString(c), pos);
    }
  }

  /* =========================
   * Parser
   * ========================= */

  static final class Parser {
    final Lexer lx;
    Token cur;
    final LinkedHashMap<String, Obj> vars = new LinkedHashMap<>();

    Parser(String src){
      this.lx = new Lexer(src);
      this.cur = lx.next();
    }

    void advance(){ cur = lx.next(); }

    boolean accept(TokenType t){
      if(cur.type==t){ advance(); return true; }
      return false;
    }

    boolean acceptOp(String op){
      if(cur.type==TokenType.OP && op.equals(cur.text)){ advance(); return true; }
      return false;
    }

    void expect(TokenType t, String what){
      if(cur.type!=t){
        if(cur.type==TokenType.EOF) throw new IncompleteInput("expected "+what+" but reached end of input");
        throw new RuntimeException("expected "+what+" at "+cur.pos+", got "+cur);
      }
      advance();
    }

    Statement parseStatement(){
      // Query: ?- Goal.
      if(acceptOp("?-")){
        Obj g = parseGoalExpr(0);
        return new QueryStmt(g, vars);
      }
      // Directive: :- Goal.
      if(acceptOp(":-")){
        Obj g = parseGoalExpr(0);
        return new DirectiveStmt(g, vars);
      }

      // Clause: Head.  or  Head :- Goal.
      Obj head = parseCallableTerm();
      if(acceptOp(":-")){
        Obj body = parseGoalExpr(0);
        return new ClauseStmt(Comp(":-", head, body));
      }
      return new ClauseStmt(head);
    }

    /* ---------- Goal parsing ---------- */

    static final class OpInfo {
      final int prec;
      final boolean rightAssoc;
      final boolean goalRhs; // if true, RHS parsed as goal; else as term
      OpInfo(int prec, boolean rightAssoc, boolean goalRhs){
        this.prec=prec; this.rightAssoc=rightAssoc; this.goalRhs=goalRhs;
      }
    }

    static final Map<String, OpInfo> GOAL_OPS = Map.ofEntries(
        Map.entry(";",  new OpInfo(1100, true,  true)),
        Map.entry("->", new OpInfo(1050, true,  true)),
        Map.entry(",",  new OpInfo(1000, true,  true)),

        // binary built-ins / comparisons (RHS is term)
        Map.entry("=",   new OpInfo(700, false, false)),
        Map.entry("is",  new OpInfo(700, false, false)),
        Map.entry("=:= ",new OpInfo(700, false, false)) // dummy; not used (kept for clarity)
    );

    // Comparators / builtin operators at precedence ~700 (RHS is term)
    static final Set<String> GOAL_TERM_BINOPS = Set.of(
        "=", "is", "=:=", "=\\=", "<", "=<", ">", ">=", "==", "\\="
    );

    Obj parseGoalExpr(int minPrec){
      Obj left = parseGoalPrefix();

      while(true){
        // Determine operator at current token
        String op = null;
        int prec = -1;
        boolean rightAssoc = false;
        boolean rhsIsGoal = false;

        if(cur.type==TokenType.COMMA){ op=","; prec=30; rightAssoc=true; rhsIsGoal=true; }
        else if(cur.type==TokenType.SEMI){ op=";"; prec=10; rightAssoc=true; rhsIsGoal=true; }
        else if(cur.type==TokenType.OP){
          String t = cur.text;
          if("->".equals(t)){ op="->"; prec=20; rightAssoc=true; rhsIsGoal=true; }
          else if(GOAL_TERM_BINOPS.contains(t) || "is".equals(t)){ op=t; prec=40; rightAssoc=false; rhsIsGoal=false; }
        } else if(cur.type==TokenType.ATOM){
          // allow 'is' and 'mod' style word operators in goal position
          if("is".equals(cur.text)){ op="is"; prec=40; rightAssoc=false; rhsIsGoal=false; }
        }

        if(op==null || prec < minPrec) break;

        // consume operator token
        if(",".equals(op)) expect(TokenType.COMMA, "','");
        else if(";".equals(op)) expect(TokenType.SEMI, "';'");
        else {
          // op in OP or ATOM('is')
          advance();
        }

        int nextMin = rightAssoc ? prec : prec + 1;
        Obj right = rhsIsGoal ? parseGoalExpr(nextMin) : parseTermExpr(0, /*stopOnGoalOps*/ true);

        left = Comp(op, left, right);
      }

      return left;
    }

    Obj parseGoalPrefix(){
      // prefix \+ Goal
      if(cur.type==TokenType.OP && "\\+".equals(cur.text)){
        advance();
        Obj inner = parseGoalPrefix();
        return Comp("\\+", inner);
      }
      // cut !
      if(cur.type==TokenType.OP && "!".equals(cur.text)){
        advance();
        return Comp("!");
      }
      // parenthesized goal
      if(accept(TokenType.LPAREN)){
        Obj g = parseGoalExpr(0);
        expect(TokenType.RPAREN, "')'");
        return g;
      }

      // otherwise, a goal is a callable term
      return parseCallableTerm();
    }

    /* ---------- Term parsing ---------- */

    Obj parseCallableTerm(){
      Obj t = parseTermExpr(0, /*stopOnGoalOps*/ false);
      return t;
    }

    static final class TermOpInfo {
      final int prec;
      final boolean rightAssoc;
      final boolean unary;
      TermOpInfo(int prec, boolean rightAssoc, boolean unary){
        this.prec=prec; this.rightAssoc=rightAssoc; this.unary=unary;
      }
    }

    static final Map<String, TermOpInfo> TERM_OPS = Map.ofEntries(
        Map.entry("+",   new TermOpInfo(20, false, false)),
        Map.entry("-",   new TermOpInfo(20, false, false)),
        Map.entry("*",   new TermOpInfo(30, false, false)),
        Map.entry("/",   new TermOpInfo(30, false, false)),
        Map.entry("//",  new TermOpInfo(30, false, false)),
        Map.entry("mod", new TermOpInfo(30, false, false))
    );

    Obj parseTermExpr(int minPrec, boolean stopOnGoalOps){
      Obj left = parseTermPrefix(stopOnGoalOps);

      while(true){
        // stop tokens for term context
        if(cur.type==TokenType.COMMA || cur.type==TokenType.RPAREN || cur.type==TokenType.RBRACK || cur.type==TokenType.BAR || cur.type==TokenType.DOT) break;
        if(stopOnGoalOps){
          if(cur.type==TokenType.SEMI) break;
          if(cur.type==TokenType.OP && "->".equals(cur.text)) break;
        }

        String op = null;
        int prec = -1;
        boolean rightAssoc = false;

        // infix arithmetic operators: + - * / // or word 'mod'
        if(cur.type==TokenType.OP){
          TermOpInfo info = TERM_OPS.get(cur.text);
          if(info!=null){
            op = cur.text;
            prec = info.prec;
            rightAssoc = info.rightAssoc;
          }
        } else if(cur.type==TokenType.ATOM){
          TermOpInfo info = TERM_OPS.get(cur.text);
          if(info!=null){
            op = cur.text;
            prec = info.prec;
            rightAssoc = info.rightAssoc;
          }
        }

        if(op==null || prec < minPrec) break;

        advance();
        int nextMin = rightAssoc ? prec : prec + 1;
        Obj right = parseTermExpr(nextMin, stopOnGoalOps);
        left = Comp(op, left, right);
      }

      return left;
    }

    Obj parseTermPrefix(boolean stopOnGoalOps){
      // unary minus
      if(cur.type==TokenType.OP && "-".equals(cur.text)){
        advance();
        Obj inner = parseTermExpr(40, stopOnGoalOps);
        return Comp("-", inner);
      }

      // parenthesized term
      if(accept(TokenType.LPAREN)){
        Obj t = parseTermExpr(0, stopOnGoalOps);
        expect(TokenType.RPAREN, "')'");
        return t;
      }

      // list
      if(accept(TokenType.LBRACK)){
        // empty list []
        if(accept(TokenType.RBRACK)){
          return Atom("[]");
        }
        List<Obj> els = new ArrayList<>();
        Obj tail = Atom("[]");

        els.add(parseTermExpr(0, /*stopOnGoalOps*/ false));
        while(true){
          if(accept(TokenType.BAR)){
            tail = parseTermExpr(0, /*stopOnGoalOps*/ false);
            expect(TokenType.RBRACK, "']'");
            break;
          }
          if(accept(TokenType.COMMA)){
            els.add(parseTermExpr(0, /*stopOnGoalOps*/ false));
            continue;
          }
          expect(TokenType.RBRACK, "']'");
          break;
        }

        // build list cons chain
        Obj acc = tail;
        for(int k=els.size()-1;k>=0;k--){
          acc = listCons(els.get(k), acc);
        }
        return acc;
      }

      // number
      if(cur.type==TokenType.NUM){
        String txt = cur.text;
        advance();
        boolean isFloat = txt.endsWith("f");
        if(isFloat){
          String raw = txt.substring(0, txt.length()-1);
          return Comp("double", Atom(raw));
        }
        return Num(Long.parseLong(txt));
      }

      // variable
      if(cur.type==TokenType.VAR){
        String name = cur.text;
        advance();
        if("_".equals(name)){
          // anonymous variable: unique each occurrence
          return Var();
        }
        return vars.computeIfAbsent(name, k -> Var());
      }

      // atom / functor
      if(cur.type==TokenType.ATOM){
        String name = cur.text;
        advance();

        // compound?
        if(accept(TokenType.LPAREN)){
          List<Obj> args = new ArrayList<>();
          if(!accept(TokenType.RPAREN)){
            args.add(parseTermExpr(0, /*stopOnGoalOps*/ false));
            while(accept(TokenType.COMMA)){
              args.add(parseTermExpr(0, /*stopOnGoalOps*/ false));
            }
            expect(TokenType.RPAREN, "')'");
          }
          return Comp(name, args.toArray(new Obj[0]));
        }

        return Atom(name);
      }

      if(cur.type==TokenType.EOF) throw new IncompleteInput("unexpected end of input");
      throw new RuntimeException("unexpected token at "+cur.pos+": "+cur);
    }
  }

  private PrologTextParser(){}
}
