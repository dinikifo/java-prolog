package com.mycompany.prolog;

import java.util.*;

import static com.mycompany.prolog.MiniPrologProto.*;

/** Runner for the OO + ColumnDB + HTN prototype stack. */
public final class PrototypeStackMain {
  private PrototypeStackMain(){}

  static Obj buildPrototypeProgram(){
    Obj prog = MiniPrologProto.buildProgramWithSample();
    OopPrologLib.load(prog);
    ColumnDbLib.load(prog);
    PlannerStrategiesLib.load(prog);
    HtnDemoLib.load(prog);
    return prog;
  }

  static void runHtnDemo(String profile){
    Obj prog = buildPrototypeProgram();
    Obj Plan = Var();
    Obj goal = Comp("demo_plan", Atom(profile), Plan);
    List<Map<Integer,Obj>> sols = query(prog, goal);
    if(sols.isEmpty()){
      System.out.println("No plan found.");
      return;
    }
    Obj planVal = sols.get(0).get(Plan.get(K_VID));
    System.out.println("Profile: " + profile);
    System.out.println("Plan: " + pp(planVal));
  }

  public static void main(String[] args){
    if(args!=null && args.length>0){
      if("--selftest".equals(args[0])){
        MiniPrologProto.selfTest();
        return;
      }
      if("--htn-demo".equals(args[0])){
        String profile = (args.length>=2)? args[1] : "indexed";
        runHtnDemo(profile);
        return;
      }
    }

    System.out.println("Usage:");
    System.out.println("  java -ea -cp out com.mycompany.prolog.PrototypeStackMain --selftest");
    System.out.println("  java -cp out com.mycompany.prolog.PrototypeStackMain --htn-demo [small|cached|indexed]");
  }
}
