package com.mycompany.prolog;

import static com.mycompany.prolog.MiniPrologProto.*;

/**
 * Prolog-level, JS-like prototype OO substrate.
 *
 * Dynamic storage predicates (Option A): proto/2, slot/3, method/4, obj_counter/1.
 * Minimal readiness flag: oop_ready/0 is asserted by oop_init/0.
 *
 * Objects are represented as obj(Id) terms; prototypes are typically atoms (e.g. objectProto).
 */
public final class OopPrologLib {
  private OopPrologLib(){}

  /** Build a left-associated conjunction term (','/2). */
  static Obj conj(Obj... gs){
    if(gs==null || gs.length==0) return Comp("true");
    Obj out = gs[gs.length-1];
    for(int i=gs.length-2;i>=0;i--) out = Comp(",", gs[i], out);
    return out;
  }

  private static void ensurePred(Obj prog, String name, int arity){
    if(getPred(prog.get(K_PREDICATES), name, arity)==null){
      definePred(prog, name, arity, Predicate());
    }
  }

  /** Install OO predicates into {@code prog}. */
  public static void load(Obj prog){
    // Option A stubs (plus readiness flag)
    ensurePred(prog, "proto", 2);
    ensurePred(prog, "slot", 3);
    ensurePred(prog, "method", 4);
    ensurePred(prog, "obj_counter", 1);
    ensurePred(prog, "oop_ready", 0);

    // retract_all/1
    {
      Obj T = Var();
      // Failure-driven loop: retract all solutions to T.
      // This is important once retract/1 correctly binds variables in the caller.
      definePred(prog, "retract_all", 1, Predicate(
          Clause(Comp("retract_all", T),
              Comp("retract", T),
              Comp("fail")),
          Clause(Comp("retract_all", Var()), Comp("true"))
      ));
    }

    // oop_init/0
    {
      Obj Any = Var();
      definePred(prog, "oop_init", 0, Predicate(
          Clause(Comp("oop_init"),
              Comp("retract_all", Comp("oop_ready")),
              Comp("retract_all", Comp("proto", Any, Any)),
              Comp("retract_all", Comp("slot", Any, Any, Any)),
              Comp("retract_all", Comp("method", Any, Any, Any, Any)),
              Comp("retract_all", Comp("obj_counter", Any)),
              Comp("assertz", Comp("obj_counter", Num(0))),
              Comp("assertz", Comp("proto", Atom("objectProto"), Atom("null"))),
              Comp("assertz", Comp("oop_ready"))
          )
      ));
    }

    // next_id/1
    {
      Obj N = Var();
      Obj Id = Var();
      Obj N1 = Var();
      definePred(prog, "next_id", 1, Predicate(
          Clause(Comp("next_id", Id),
              Comp("oop_ready"),
              Comp(";",
                  Comp("->", Comp("retract", Comp("obj_counter", N)), Comp("true")),
                  Comp("=", N, Num(0))
              ),
              Comp("is", N1, Comp("+", N, Num(1))),
              Comp("assertz", Comp("obj_counter", N1)),
              Comp("=", Id, N1)
          )
      ));
    }

    // clone/2
    {
      Obj Proto = Var();
      Obj ObjT = Var();
      Obj Id = Var();
      definePred(prog, "clone", 2, Predicate(
          Clause(Comp("clone", Proto, ObjT),
              Comp("oop_ready"),
              Comp("next_id", Id),
              Comp("=", ObjT, Comp("obj", Id)),
              Comp("assertz", Comp("proto", ObjT, Proto))
          )
      ));
    }

    // get/3
    {
      Obj O = Var(), K = Var(), V = Var(), P = Var();
      definePred(prog, "get", 3, Predicate(
          Clause(Comp("get", O, K, V),
              Comp("oop_ready"),
              Comp(";",
                  Comp("->", Comp("slot", O, K, V), Comp("true")),
                  conj(
                      Comp("proto", O, P),
                      Comp("\\+", Comp("=", P, Atom("null"))),
                      Comp("get", P, K, V)
                  )
              )
          )
      ));
    }

    // put/3
    {
      Obj O = Var(), K = Var(), V = Var(), Any = Var();
      definePred(prog, "put", 3, Predicate(
          Clause(Comp("put", O, K, V),
              Comp("oop_ready"),
              Comp("retract_all", Comp("slot", O, K, Any)),
              Comp("assertz", Comp("slot", O, K, V))
          )
      ));
    }

    // defmethod/4
    {
      Obj P = Var(), Msg = Var(), Self = Var(), Body = Var();
      Obj AnySelf = Var();
      Obj AnyBody = Var();
      definePred(prog, "defmethod", 4, Predicate(
          Clause(Comp("defmethod", P, Msg, Self, Body),
              Comp("oop_ready"),
              // Remove any existing implementation of the same method on the same prototype.
              // IMPORTANT: keep the "self" and "body" positions distinct; using a single
              // shared variable here would accidentally match (and retract) unrelated methods.
              Comp("retract_all", Comp("method", P, Msg, AnySelf, AnyBody)),
              Comp("assertz", Comp("method", P, Msg, Self, Body))
          )
      ));
    }

    // send/2 and send_proto/3
    {
      Obj O = Var(), Msg = Var(), P = Var(), Body = Var();
      definePred(prog, "send", 2, Predicate(
          Clause(Comp("send", O, Msg),
              Comp("oop_ready"),
              Comp(";",
                  Comp("->", Comp("method", O, Msg, O, Body), Comp("call", Body)),
                  conj(
                      Comp("proto", O, P),
                      Comp("\\+", Comp("=", P, Atom("null"))),
                      Comp("send_proto", P, O, Msg)
                  )
              )
          )
      ));

      Obj Proto = Var(), Self = Var(), Msg2 = Var(), PP = Var(), Body2 = Var();
      definePred(prog, "send_proto", 3, Predicate(
          Clause(Comp("send_proto", Proto, Self, Msg2),
              Comp("oop_ready"),
              Comp(";",
                  Comp("->", Comp("method", Proto, Msg2, Self, Body2), Comp("call", Body2)),
                  conj(
                      Comp("proto", Proto, PP),
                      Comp("\\+", Comp("=", PP, Atom("null"))),
                      Comp("send_proto", PP, Self, Msg2)
                  )
              )
          )
      ));
    }
  }
}
