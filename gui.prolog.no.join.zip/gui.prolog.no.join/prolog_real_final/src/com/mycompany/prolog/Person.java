package com.mycompany.prolog;

public class Person {
  public String name;
  public int age;
  public Address address;
  public String[] tags;
}
