#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$ROOT"

./build.sh

java -ea -cp out com.mycompany.prolog.MiniPrologProto --selftest
